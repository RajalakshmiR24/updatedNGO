import React, { useEffect, useState } from 'react';
import './LineCharts.css';
import { Line } from 'react-chartjs-2';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import { Chart as ChartJS, LineElement, PointElement, LinearScale, CategoryScale, Title, Tooltip, Legend } from 'chart.js';
import dayjs from 'dayjs'; // For formatting dates

ChartJS.register(LineElement, PointElement, LinearScale, CategoryScale, Title, Tooltip, Legend);

const LineChart = () => {
    const [chartData, setChartData] = useState({
        labels: [],
        datasets: [
            {
                label: 'Contributions',
                data: [],
                borderColor: 'blue',
                backgroundColor: 'rgba(173, 216, 230, 0.2)',
                fill: true,
            },
            {
                label: 'Expenses',
                data: [],
                borderColor: 'lightgreen',
                backgroundColor: 'rgba(144, 238, 144, 0.2)',
                fill: true,
            }
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Contributions and Expenses Over Time',
            },
        },
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Months'
                }
            },
            y: {
                title: {
                    display: true,
                    text: 'Amount (in currency)'
                }
            }
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const contributionResponse = await axiosInstance.get('/admin/alltransactions');
                const expenseResponse = await axiosInstance.get('/admin/totalexpense');

                if (contributionResponse.data.code === 200 && expenseResponse.data.code === 200) {
                    const contributionData = contributionResponse.data.data;
                    const expenseData = expenseResponse.data.data;

                    // Create a set of unique labels (months)
                    const labels = Array.from(new Set([
                        ...contributionData.map(contribution => dayjs(contribution.time).format('MMM')),
                        ...expenseData.map(expense => dayjs(expense.time).format('MMM'))
                    ]));

                    const contributions = labels.map(label => {
                        const total = contributionData
                            .filter(contribution => dayjs(contribution.time).format('MMM') === label)
                            .reduce((acc, contribution) => acc + parseFloat(contribution.amount), 0);
                        return total;
                    });

                    const expenses = labels.map(label => {
                        const total = expenseData
                            .filter(expense => dayjs(expense.time).format('MMM') === label)
                            .reduce((acc, expense) => acc + parseFloat(expense.claiming_amount), 0);
                        return total;
                    });

                    setChartData({
                        labels: labels,
                        datasets: [
                            {
                                label: 'Contributions',
                                data: contributions,
                                borderColor: 'blue',
                                backgroundColor: 'rgba(173, 216, 230, 0.2)',
                                fill: true,
                            },
                            {
                                label: 'Expenses',
                                data: expenses,
                                borderColor: 'lightgreen',
                                backgroundColor: 'rgba(144, 238, 144, 0.2)',
                                fill: true,
                            }
                        ],
                    });
                } else {
                    console.error('No data received from one or more APIs');
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div style={{ height: "40vh", width: "800px" }} className='line_chart'>
            <Line data={chartData} options={options} />
        </div>
    );
};

export default LineChart;
