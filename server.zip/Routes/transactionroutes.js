const express = require("express");
const { saveTransaction, getAllTransactionDetails, pushCampaignDetailsIntoTransactionForm } = require("../Controller/transactioncontroller");
const transactionRouter = express.Router();


transactionRouter.post("/save", saveTransaction);
transactionRouter.get("/all", getAllTransactionDetails);
transactionRouter.post("/campaigndata", pushCampaignDetailsIntoTransactionForm);



module.exports = { transactionRouter }