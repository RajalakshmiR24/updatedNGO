const express = require("express");
const { registerAdmin, adminLogin, findAllUsers, findAdminByEmail, updateApprovedCampaignsToLive,adminLogout,getCompletedCampaings, deleteAdminByEmail, findAdminByEmailHash, updateAdminDetailsByEmailHash, campaignCountPerUserByEmailHash, getBudgetPerUserForCampaignByEmailHash, getTotalRegisteredUsers, getTotalGeneralUsers, getAllTransactions, getUserDetailsToVerify, rejectUserRegistration, getCampaignDetailRequestToVerify, getTransactionDataPerCampaigns, getTransactionDetailsPerCampaignType, findUserByEmailHash, rejectCampaignRequest, getCampaignDetailsPerUserByEmailHash, getRegisteredUsersBillsToVerify, rejectBillsByBillID, getTotalDonation, insertCampaignDataByEmailHash, getAllAdminCampaignDetails, getAllUserCampaignDetails, uploadImage, fetchImage, getCampaignDetailsByCampaignId , getCampaignCountByMonth, getCampaignCountByYear, getLiveCampaings, getCancelledCampaings, getUpcomingCampaings,  totalCampaignCount} = require("../Controller/admincontroller.js");
const { verifyToken, verifyJWT } = require("../Middlewares/auth");
const { getAllQueries } = require("../Controller/querycontroller.js");

const adminRouter = express.Router();

adminRouter.post("/register", registerAdmin);
adminRouter.post("/login", adminLogin)

adminRouter.get("/allusers", findAllUsers);
//admin profile routes
adminRouter.post("/finduserbyhash", findUserByEmailHash); //user
adminRouter.post("/findadminbyhash",  findAdminByEmailHash);
adminRouter.post("/findbyemail", verifyToken, findAdminByEmail);
adminRouter.put("/update", verifyToken, updateAdminDetailsByEmailHash);
adminRouter.delete("/delete", verifyToken, deleteAdminByEmail);
adminRouter.post("/logout", adminLogout);

//dashboard routes
adminRouter.get("/alllivecampaigns", updateApprovedCampaignsToLive)
adminRouter.get("/admincampaigndetails", getAllAdminCampaignDetails)
adminRouter.get("/usercampaigndetails", getAllUserCampaignDetails)
adminRouter.get("/totalcampaigncount", totalCampaignCount);

adminRouter.get("/monthcount",getCampaignCountByMonth)
adminRouter.get("/yearcount",getCampaignCountByYear)
adminRouter.get("/live",getLiveCampaings)
adminRouter.get("/cancel",getCancelledCampaings)
adminRouter.get("/upcoming",getUpcomingCampaings)
adminRouter.get("/complete",getCompletedCampaings)

adminRouter.get("/totaldonation", getTotalDonation)
adminRouter.post("/usercampaigncount", campaignCountPerUserByEmailHash);
adminRouter.post("/userbudget", getBudgetPerUserForCampaignByEmailHash);
adminRouter.get("/registeredusers", getTotalRegisteredUsers);
adminRouter.get("/totalgeneralusers", getTotalGeneralUsers);
adminRouter.get("/alltransactions", getAllTransactions);
adminRouter.post("/campaigndataperuser", getCampaignDetailsPerUserByEmailHash)
adminRouter.post("/campaignbyid",getCampaignDetailsByCampaignId)

adminRouter.post('/campaigndata', insertCampaignDataByEmailHash);

//registeredusers
adminRouter.post("/transactionpercampaign", getTransactionDetailsPerCampaignType)

//requests
adminRouter.get("/verifyuserdetails", getUserDetailsToVerify);
adminRouter.post("/rejectuser", rejectUserRegistration);
adminRouter.get("/campaignstatustoverify", getCampaignDetailRequestToVerify)
adminRouter.put("/rejectcampreq", rejectCampaignRequest);
adminRouter.put("/rejectbills", rejectBillsByBillID);
adminRouter.get("/getbills", getRegisteredUsersBillsToVerify);


//queries
adminRouter.get("/allqueries", getAllQueries);


adminRouter.post("/bannerimage", uploadImage);
adminRouter.post("/fetchbannerimage", fetchImage);

module.exports = adminRouter;