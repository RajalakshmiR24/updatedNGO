// const User = require("../Model/user")

// const jwt = require("jsonwebtoken")

// const verifyJWT = async (req, res, next) => {
//     try {
//         const token = req.cookies?.accessToken || req.header("Authorization")?.replace("Bearer ", "");

//         // console.log(token);
//         if (!token) {
//             return res.status(200).json({ code: 400, message: "Token not found" })
//         }

//         const decodedToken = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET_KEY);
//         // console.log(decodedToken);

//         const user = await User.findById(decodedToken?._id).select("-password -refreshToken -mobile_number")
//         // console.log(user);

//         if (!user) {
//             return res.status(200).json({ code: 400, message: "User not found" })
//         }
//         req.user = user;
//         // console.log(req.user);
//         next();

//     } catch (error) {
//         return res.status(200).json({ code: 400, message: error.message })
//     }
// }

// const verifyToken = async (req, res, next) => {
//     const token = req?.body?.token || req?.cookies?.access_token;
//     if (!token) {
//         return res.status(200).json({ code: 400, message: "Token not found" });
//     }

//     await jwt.verify(token, process.env.ACCESS_TOKEN_SECRET_KEY, (err, user) => {
//         if (err) {
//             return res.status(200).json({ code: 401, errorMessage: err.message });
//         }
//         req.user = user;
//         console.log(req.user, "jwt verify ");
//         next();
//     })
// }
const jwt = require('jsonwebtoken');
const { User } = require('../Model/user');
const { Admin } = require('../Model/admin');

const verifyJWT = async (req, res, next) => {
    console.log("Verifying JWT");
    // console.log(req.header("Authorization"));
    try {
        const token = req.cookies?.accessToken || req.header("Authorization")?.replace("Bearer ", "");

        if (!token) {
            return res.status(401).json({ code: 401, message: "Authorization token not found" });
        }

        // Verify token
        const decodedToken = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET_KEY);
        // console.log("Decoded Token:", decodedToken);

        // Fetch user or admin using decoded token information
        let userOrAdmin;
        if (decodedToken.role === 'admin') {
            userOrAdmin = await Admin.findOne({ email_hash: decodedToken.email_hash })
                .select("-password -refreshToken -mobile_number");
        } else {
            userOrAdmin = await User.findById(decodedToken._id)
                .select("-password -refreshToken -mobile_number");
        }

        // console.log("User or Admin:", userOrAdmin);
        if (!userOrAdmin) {
            return res.status(401).json({ code: 401, message: "User/Admin not found" });
        }

        req.userOrAdmin = userOrAdmin; // Changed to userOrAdmin for clarity
        next();
    } catch (error) {
        console.error("JWT Verification Error:", error);
        const isTokenExpired = error.message === "jwt expired";
        return res.status(401).json({
            code: 401,
            message: isTokenExpired ? "Token has expired. Please log in again." : "Invalid token."
        });
    }
};



const verifyToken = async (req, res, next) => {
    const token = req.body.token || req.cookies.accessToken;
    // const token = req.header("Authorization")?.replace("Bearer ", "");
    // console.log(req.header("Authorization"));

    if (!token) {
        return res.status(401).json({ code: 400, message: "Token not found" });
    }

    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET_KEY, (err, user) => {
        if (err) {
            return res.status(401).json({ code: 401, errorMessage: err.message });
        }
        req.user = user;
        // console.log(req.user);
        next();
    });
};


const verifyUser = async (req, res, next) => {
    await verifyToken(req, res, next, (err, user) => {
        if (req.user.isAdmin) {
            next();
        } else {
            return res.status(200).json({ code: 400, message: "User is not authorized" })
        }
    })
}

// app.post('/logout', (req, res) => {
//     const token = req.headers['authorization'];
//     if (token) {
//         blacklistedTokens.push(token);
//         res.send('Logged out');
//     } else {
//         res.status(400).send('No token provided');
//     }

// app.post('/logout', (req, res) => {
//     // Clear the cookie
//     res.clearCookie('userId');
//     res.send('Logged out');
// });

module.exports = { verifyJWT, verifyToken, verifyUser }