const { Transaction } = require("../Model/transaction");

const saveTransaction = async (req, res) => {
    // console.log(req.body);

    const { name, email, amount, mobilenumber, user_hash, campaignname } = req.body;
    try {
        // const user = await Transaction.findOne({mobilenumber:mobilenumber})
        // if(!user){
        if (!campaignname) {

            const transaction = await Transaction.create({ name: name, email: email, campaign_name: campaignname, amount: amount, mobilenumber: mobilenumber });
            transaction.save();
        }
        const transaction = await Transaction.create({ name: name, email: email, amount: amount, mobilenumber: mobilenumber });
        transaction.save();
        // }
        return res.status(200).json({ code: 200, message: "Transaction saved" })

    } catch (error) {
        return res.status(200).json({ code: 400, errorMessage: error.message })
    }
}
const getTransactionDocumentCount = async (req, res) => {
    const totalTransactionDocuments = await Transaction.countDocuments();
    if (totalTransactionDocuments === 0) {

        return res.status(200).json({ code: 400, message: "No transactions found" })
    }
    return res.status(200).json({ code: 200, data: totalTransactionDocuments });
}

const getAllTransactionDetails = async (req, res) => {

    const totalTransactionDocuments = await Transaction.countDocuments();
    if (totalTransactionDocuments === 0) {
        return res.status(200).json({ code: 400, message: "No transactions found" })
    }
    const transactionDocuments = await Transaction.find({});
    return res.status(200).json({ code: 200, data: transactionDocuments });
}

const pushCampaignDetailsIntoTransactionForm = async (req, res) => {
    const { email, info } = req.body;
    // console.log(req.body);
    try {

        const result = await Transaction.updateOne({ email: email }, { $push: { campaignDetails: info } }, { new: true })
        // console.log(result);
        if (result.modifiedCount > 0) {
            return res.status(200).json({ code: 200, message: "Object added into array successfully" })
        }
        else {
            return res.status(200).json({ code: 400, message: "Unsuccessfull" })
        }
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}


module.exports = { saveTransaction, getAllTransactionDetails, pushCampaignDetailsIntoTransactionForm };