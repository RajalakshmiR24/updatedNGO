const { Transaction } = require("../Model/transaction");
const { User } = require("../Model/user");


const registerUser = async (req, res) => {

    // console.log("register", req.body);
    const { email, password, mobilenumber, address, fullname } = req.body;

    if (!email || !password) {
        return res.status(200).json({ code: 400, message: "Email and password required" })
    }

    try {
        const existedUserEmail = await User.findOne({ email: email });
        const existedMobileNumber = await User.findOne({ mobile_number: mobilenumber })

        if (existedUserEmail) {
            return res.status(200).json({ code: 400, message: "Email already registered" })
        }

        if (existedMobileNumber) {
            return res.status(200).json({ code: 400, message: "Mobilenumber exists" })
        }

        const user = await User.create({ fullname: fullname, email: email, password: password, current_address: address, mobile_number: mobilenumber });

        // console.log(user);
        const createdUser = await User.findById(user._id).select("-password -refreshToken -mobile_number");
        // console.log(createdUser);


        if (!createdUser) {
            return res.status(200).json({ code: 500, message: "Something went wrong" })
        }

        return res.status(200).json({ code: 200, message: "User created successfully" })

    } catch (error) {

        return res.status(200).json({ code: 500, message: error.message })

    }
}

const generateAccessAndRefreshTokens = async (userId, req, res) => {
    try {
        const user = await User.findById(userId);
        const accessToken = user.generateAccessToken();
        const refreshToken = user.generateRefreshToken();

        // console.log(refreshToken,"reff1");
        user.refreshToken = refreshToken;

        await user.save({ validateBeforeSave: false });

        // console.log(user, "refresh token");

        return { accessToken, refreshToken }

    } catch (error) {
        return res.status(200).json({ code: 500, ErrorMessage: error.message })

    }
}

const userLogin = async (req, res) => {
    const { email, password } = req.body;

    // console.log(userSchema);
    if (!email || !password) {
        return res.status(200).json({ code: 400, message: "Email and password required" })
    }

    try {
        const user = await User.findOne({ email })

        // console.log(user.password);
        if (!user) {
            return res.status(200).json({ code: 400, message: "User not found" })
        }

        const isPasswordValid = await user.isPasswordCorrect(password);
        // console.log(isPasswordValid);


        if (!isPasswordValid) {
            return res.status(200).json({ code: 400, message: "Incorrect password" })
        }
        // console.log(isPasswordValid);

        const { refreshToken, accessToken } = await generateAccessAndRefreshTokens(user._id);
        // console.log(refreshToken);

        const loggedUser = await User.findById(user._id).select("-password -refreshToken");
        // console.log(loggedUser, "loggg");

        const options = {
            httpOnly: true,
            secure: true,
        }

        return res.status(200).cookie('accessToken', accessToken, options).setHeader('Authorization', `Bearer ${accessToken}`).json({
            code: 200,
            user: loggedUser,
            accessToken,
            refreshToken,
            message: "Logged in successfully"
        })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const userRefreshToken = async (req, res) => {

    const incomingRefreshToken = req.cookies.refreshToken || req.body.refreshToken;

    if (!incomingRefreshToken) {
        return res.status(200).json({ code: 400, message: "Refresh token not found" })

    }

    // console.log(incomingRefreshToken);
    try {
        const decodedToken = jwt.verify(incomingRefreshToken, process.env.REFRESH_TOKEN_SECRET_KEY);

        // console.log(decodedToken);
        const user = await User.findById(decodedToken?.id);
        // console.log(user?.refreshToken, "user");

        if (!user) {
            return res.status(200).json({ code: 400, message: "user not found" })
        }

        if (!user?.refreshToken === incomingRefreshToken) {
            return res.status(200).json({ code: 400, message: "Refresh token is incorrect" })
        }

        const { accessToken, refreshToken } = await generateAccessAndRefreshTokens(user._id);

        return res.status(200).cookie("accessToken", accessToken).cookie("refreshToken", refreshToken)
            .json({ refreshToken, accessToken, message: "Access token refreshed" })
    } catch (error) {

        return res.status(200).json({ message: error.message })
    }
}

const userData = async (req, res) => {
    res.send("data");
}

const getUsersCount = async (req, res) => {

    const userCount = await User.countTotalUsers();
    if (userCount === 0) {
        return res.status(200).json({ code: 400, message: "No users" })
    }
    return res.status(200).json({ code: 200, data: userCount })

}

const userLogout = async (req, res) => {

    if (!req.cookies) {
        res.status(200).json({ code: 400, message: "User not logged in" })
    }
    // Clear the cookie
    res.clearCookie("accessToken");
    res.clearCookie("refreshToken");
    res.status(200).json({ code: 200, message: "User logged out successfully" })
}

const insertCampaignDataByEmailHash = async (req, res) => {
    // const { fullName, companyRole } = req.body;
    // console.log(req.body);
    const bannerImage = req.file ? req.file.path : null;
    // const user = new User();
    // console.log(bannerImage);
    // try {
    //   await user.save();
    //   res.send("Data successfully inserted");
    // } catch (error) {
    //   res.status(500).send("There was an error inserting the data");
    // }
    const { hash, info } = req.body;
    if (!info) {

        return res.status(200).json({ code: 400, message: "No data received" })
    }
    try {
        const result = await User.updateOne({ email_hash: hash }, { $push: { campaigndetails: info } }, { new: true })
        if (result.modifiedCount > 0) {
            return res.status(200).json({ code: 200, message: "Object added into array successfully" })
        }
        else {
            return res.status(200).json({ code: 400, message: "Unsuccessfull" })
        }
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}


const getAllCampaignDetails = async (req, res) => {
    try {
        const campaignDetails = await User.getAllCampaignDetails();
        if (campaignDetails.length === 0) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaignDetails })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const totalCampaignCount = async (req, res) => {
    try {
        const count = await User.getTotalCampaignCount();
        if (count === 0) {
            return res.status(200).json({ code: 400, message: "No campaign found" })
        }
        return res.status(200).json({ code: 200, data: count })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const campaignCountPerUserByEmailHash = async (req, res) => {
    const { hash } = req.body;
    try {
        const user = await User.findOne({ email_hash: hash });
        const campaignCountPerUser = await user.getUserCampaignCount();
        if (campaignCountPerUser === 0) {
            return res.status(200).json({ code: 200, data: "NA" })
        }
        return res.status(200).json({ code: 200, data: campaignCountPerUser })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }


}

const updateApprovedCampaignsToLive = async (req, res) => {
    try {
        const currentDate = new Date();

        // Retrieve all user campaign details
        const allCampaignDetails = await User.getAllUserCampaignDetails();

        // Find and update approved campaigns to live
        const campaignsToUpdate = [];
        allCampaignDetails.forEach(user => {
            user.campaigndetails.forEach(campaign => {
                if (campaign.status === "APPROVED" &&
                    campaign.start_date <= currentDate &&
                    campaign.end_date >= currentDate) {
                    campaignsToUpdate.push(campaign._id); // Collecting IDs of campaigns to update
                }
            });
        });

        // If there are campaigns to update, change their status to "LIVE"
        if (campaignsToUpdate.length > 0) {
            await User.updateMany(
                {
                    "campaigndetails._id": { $in: campaignsToUpdate }
                },
                {
                    $set: {
                        "campaigndetails.$[elem].status": "LIVE"
                    }
                },
                {
                    arrayFilters: [{ "elem._id": { $in: campaignsToUpdate } }] // Update only those specific campaigns
                }
            );

            return res.status(200).json({ code: 200, message: `${campaignsToUpdate.length} campaigns updated to live.` });
        } else {
            return res.status(200).json({ code: 400, message: "No approved campaigns found to update." });
        }
    } catch (error) {
        console.error(error.message);
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};


const getCampaignCountByMonth = async (req, res) => {

}

const getCampaignCountByYear = async (req, res) => {

}
const getLiveCampaings = async (req, res) => {

}
const getCancelledCampaings = async (req, res) => {

}
const getCompletedCampaings = async (req, res) => {

}
const getUpcomingCampaings = async (req, res) => {

}
const getApprovedCampaings = async (req, res) => {

}
const getNotApprovedCampaings = async (req, res) => {

}


const getBudgetPerUserForCampaignByEmailHash = async (req, res) => {

    const { hash } = req.body;
    try {
        const user = await User.findOne({ email_hash: hash });
        const result = user.map((item, index) => {

        })


        return res.status(200).json({ code: 200, data: user });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}



const getTotalDonationForCampaignByType = async (req, res) => {

}

const expensesPerCampaign = async (req, res) => {

}







async function findAllUsers(req, res) {
    try {
        const users = await User.find({}).select("-refreshToken -password -_id -email_hash");
        // console.log(users);
        return res.status(200).json({ code: 200, data: users })
    } catch (error) {
        // console.error("Error finding users:", error);
        return res.status(200).json({ code: 400, message: "No users found" })
    }
}

// const findUserByEmailHash = async (req, res) => {
//     const { hash } = req.body;
//     // const id = req.params.id;

//     try {
//         const user = await User.findOne({ email_hash: hash });
//         if (!user) {
//             return res.status(200).json({ code: 400, message: "No user found" });
//         }
//         return res.status(200).json({ code: 200, data: user });

//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message })
//     }
// }

const getTotalRegisteredUsers = async (req, res) => {
    try {
        const count = await User.countDocuments();
        if (count === 0) {
            return res.status(200).json({ code: 400, message: "No users found" })
        }
        return res.status(200).json({ code: 200, data: count });
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getAllTransactions = async (req, res) => {

    try {
        const result = await Transaction.find({}).select("-_id")
        return res.status(200).json({ code: 200, data: result });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })


    }

}

const getTransactionDetailsPerCampaignType = async (req, res) => {
    const { campaigntype } = req.body;
    try {
        const transaction = await Transaction.aggregate([
            {
                $match: {
                    campaigndetails: {
                        $elemMatch: { "campaign_type": campaigntype } // Match documents with an address in the specified city
                    }
                }
            }
        ]);
        if (transaction.length > 0) {
            return res.status(200).json({ code: 200, data: transaction })
        }
        return res.status(200).json({ code: 400, message: "no transactions found" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getTransactionDetailsPerDay = async (req, res) => {
    try {
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);

        const endOfDay = new Date();
        endOfDay.setHours(23, 59, 59, 999);

        const transactions = await Transaction.find({
            createdAt: {
                $gte: startOfDay,
                $lte: endOfDay
            }
        }).sort({ createdAt: -1 });

        if (transactions.length > 0) {
            return res.status(200).json({ code: 200, data: transactions });
        }

        return res.status(200).json({ code: 400, message: "No transactions found for today" });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
}

const getTransactionDetailsPerMonth = async (req, res) => {
    try {
        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);

        const endOfMonth = new Date();
        endOfMonth.setMonth(endOfMonth.getMonth() + 1);
        endOfMonth.setDate(0);
        endOfMonth.setHours(23, 59, 59, 999);

        const transactions = await Transaction.find({
            createdAt: {
                $gte: startOfMonth,
                $lte: endOfMonth
            }
        }).sort({ createdAt: -1 });

        if (transactions.length > 0) {
            return res.status(200).json({ code: 200, data: transactions });
        }

        return res.status(200).json({ code: 400, message: "No transactions found for this month" });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }

}
const getTransactionDetailsPerYear = async (req, res) => {
    try {
        const startOfYear = new Date();
        startOfYear.setMonth(0);
        startOfYear.setDate(1);
        startOfYear.setHours(0, 0, 0, 0);

        const endOfYear = new Date();
        endOfYear.setMonth(11);
        endOfYear.setDate(31);
        endOfYear.setHours(23, 59, 59, 999);

        const transactions = await Transaction.find({
            createdAt: {
                $gte: startOfYear,
                $lte: endOfYear
            }
        }).sort({ createdAt: -1 });

        if (transactions.length > 0) {
            return res.status(200).json({ code: 200, data: transactions });
        }

        return res.status(200).json({ code: 400, message: "No transactions found for this year" });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }

}

const getRegisteredUserTransactionDetails = async (req, res) => {


}

const getGeneralUserTransactionDetails = async (req, res) => {

}
const generalUserDonatedAmount = async (req, res) => {

}
const registeredUserDonatedAmount = async (req, res) => {

}
const getRegisteredUserBills = async (req, res) => {

}

const getRegisteredUserClaimingAmount = async (req, res) => {

}
const getRegisteredUserClaimAmountBillDetails = async (req, res) => {

}
const approveRegisteredUserClaimingAmount = async (req, res) => {

}
const getRegisteredUserExpenseAmount = async (req, res) => {

}

const getCancelRequest = () => {

}











//general user management
const getTotalGeneralUsers = async (req, res) => {
    try {
        const total = await Transaction.countDocuments();
        return res.status(200).json({ code: 200, data: total })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getTransactionDataPerCampaigns = async (req, res) => {


}

//request

// const getUserDetailsToVerify = async (req, res) => {

//     try {
//         const users = await User.find({ status: "NOT_ACTIVE" }, { _id: 0, email_hash: 0, refresh_token: 0, password: 0, campaigndetails: 0 });
//         if (!users) {
//             return res.status(200).json({ code: 400, message: "No users found" })

//         }
//         return res.status(200).json({ code: 200, data: users })

//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message })
//     }


// }

const rejectUserRegistration = async (req, res) => {

    const { hash } = req.body;
    try {
        const user = await User.findOne({ email_hash: hash })
        if (!user) {
            return res.status(200).json({ code: 400, message: "No user to reject" })
        }
        user.status = "REJECTED";
        return res.status(200).json({ code: 200, message: "User registration rejected" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }


}

// const getCampaignDetailRequestToVerify = async (req, res) => {

//     //update array in user db
//     const { hash } = req.body;
//     try {
//         const user = await User.find({ email_hash: hash }, { campaigndetails: 1, _id: 0 });
//         return res.status(200).json({ code: 200, data: user })

//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message });

//     }

// }

const rejectCampaignRequest = async (req, res) => {
    const { hash } = req.body;
    try {

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }

}

// const saveVerifiedCampaignDetails = async (req, res) => {

//     //update array in user db
// }

const getCampaignRequestedRegisteredUserDetails = async (req, res) => {

}

// const getRegisteredBillsToVerify = async (req, res) => {
//     const { hash } = req.body;

//     try {
//         const user = await User.find({ email_hash: hash });
//         const bills = user.campaigndetails




//     } catch (error) {

//     }
// }

// const rejectBills = () => {

// }



//Queries

const getAllQueries = async (req, res) => {

}



//RegisteredUser Queries


// const getAllRegisteredUserQueries = async (req, res) => {

// }
// const getRegisteredUserQueriesByEmailHash = async (req, res) => {

// }
// const getRegisteredUserQueriesByCampaign = async (req, res) => {

// }
// const getRegisteredUserQueriesByCampaignType = async (req, res) => {

// }
// const getRegisteredUserQueriesByLocation = async (req, res) => {

// }



//GeneralUser Queries



// const getAllGeneralUserQueries = async (req, res) => {

// }
// const getGeneralUserQueriesByCampaign = async (req, res) => {

// }
// const getGeneralUserQueriesByCampaignType = async (req, res) => {

// }
// const getGeneralUserQueriesByLocation = async (req, res) => {

// }



module.exports = { registerUser, userLogout, generateAccessAndRefreshTokens, userLogin, userData, userRefreshToken, insertCampaignDataByEmailHash, getUsersCount, getTransactionDetailsPerDay, getAllTransactions, getTransactionDetailsPerMonth, getTransactionDetailsPerYear, totalCampaignCount }