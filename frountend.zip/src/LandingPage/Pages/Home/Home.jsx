import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.css';
import Footer from '../../Common/Footer/Footer';
import axiosInstance from '../../../Utils/axiosInstance';

export const HomePage = () => {
  const navigate = useNavigate();
  const [campaigns, setCampaign] = useState([]);
  const [campaignModalDetail, setCampaignModalDetail] = useState({}); // Changed to object
  const [remainingAmount, setRemainingAmount] = useState();
  const [isUserCampaignDetailModalOpen, setUserCampaignDetailModalOpen] = useState(false);
  const [transactionDetails, setTransactionDetails] = useState([]);

  const handleDonate = (camp) => {
    navigate('/transaction', {
      state: {
        camp,
        date: new Date().toLocaleString(),
      },
    });
  };

  const fetchCampaigns = async () => {
    try {
      const res = await axiosInstance.get('/general/getallca');
      console.log(res.data.data);
      if (res.data.code === 200) {
        setCampaign(res.data.data);
      }
    } catch (error) {
      console.error("Error fetching campaigns:", error);
    }
  };

  useEffect(() => {
    fetchCampaigns();
  }, []);

  const remainingAmountCal = (campId) => {
    const matchingCampaign = campaigns.find(camp => camp.campaign_id === campId);

    if (!matchingCampaign) {
      console.error("No matching campaign found for ID:", campId);
      return;
    }

    const collected_amount = matchingCampaign.collected_amount;
    const estimated_budget = matchingCampaign.estimated_budget;

    console.log("Estimated Budget:", estimated_budget, "Type:", typeof estimated_budget);
    console.log("Collected Amount:", collected_amount, "Type:", typeof collected_amount);

    const budget = parseFloat(estimated_budget);
    const collected = parseFloat(collected_amount);

    if (isNaN(budget) || isNaN(collected)) {
      console.error("Estimated budget or collected amount is not a valid number.");
      return;
    }

    console.log(budget, collected, "Parsed values");

    if (collected >= budget) {
      return "Funds collected! Thank you";
    } else {
      const total = budget - collected;
      setRemainingAmount(total);
      return total;
    }
  };


  // console.log(remainingAmount, "amount");

  const handleViewButton = async (campId) => {
    setUserCampaignDetailModalOpen(true);

    const matchingCampaigns = campaigns.filter(camp => camp.campaign_id === campId);
    console.log(matchingCampaigns, "matching campaigns");

    if (matchingCampaigns.length > 0) {
      setCampaignModalDetail(matchingCampaigns[0]);
      remainingAmountCal(campId);

      try {
        const res = await axiosInstance.post(`/general/gettransactiondetails`, { campId });
        if (res.data.code === 200) {
          setTransactionDetails(res.data.data);
        }
      } catch (error) {
        console.log(error, "error in fetching transaction data");
      }
    } else {
      console.error("No matching campaign found for ID:", campId);
      setCampaignModalDetail({});
    }
  };
  const formatDate1 = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };


  return (
    <div>
      <header>
        <div className='header_home'>
        </div>
        <div className='header_content'>
          <h1>You Can Help The Poor</h1>
          <p>Providing education, healthcare, and support to underprivileged communities</p>
        </div>
      </header>

      {campaigns.length > 0 ? (
        <div className='container'>
          <h1>Campaigns</h1>
          <div className='donate_1stcolumn'>
            {campaigns.map((campaign, index) => (
              <div className='campaign' key={index}>
                <h3>{campaign.campaign_title}</h3>
                <h4>
                  {campaign.status === "LIVE" ? <p>Status: LIVE</p> : null}
                </h4>
                <img src={campaign.banner} alt="Campaign Banner" />
                {campaign.status === 'ONGOING' && (
                  <button
                    className='campaign_donate_button'
                    onClick={() => handleDonate(campaign.campaign_id)}
                  >
                    Donate
                  </button>
                )}
                <button className='campaign_donate_button' onClick={() => handleViewButton(campaign.campaign_id)}>
                  View
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <h2 className='no-campaings'> No campaigns available.</h2>
      )}

      {isUserCampaignDetailModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2 className="modal-title">Campaign Details</h2>
            {campaignModalDetail.campaign_title ? (
              <div className="campaign-detail">
                <div>
                  <img src={campaignModalDetail.banner} alt="Campaign Banner" style={{ maxWidth: '150px', marginRight: '20px' }} />
                  <div>
                    <p><strong>Title:</strong> {campaignModalDetail.campaign_title}</p>
                    <p style={{ display: "none" }}><strong>ID:</strong> {campaignModalDetail.campaign_id}</p>
                    <p><strong>Type:</strong> {campaignModalDetail.campaign_type}</p>
                    <p><strong>Description:</strong> {campaignModalDetail.campaign_description}</p>
                    <p><strong>Address:</strong> {campaignModalDetail.campaign_address}</p>
                    <p><strong>Budget:</strong> {campaignModalDetail.estimated_budget}</p>
                    <p><strong>Start Date:</strong> {formatDate1(campaignModalDetail.campaign_start_date)}</p>
                    <p><strong>End Date:</strong> {formatDate1(campaignModalDetail.campaign_end_date)}</p>
                    <p><strong>Collected Amount:</strong> {campaignModalDetail.collected_amount}</p>
                    <p><strong>Remaining Amount:</strong> {remainingAmount}</p>
                    {/* <p><strong>Status:</strong> {campaign.status}</p> */}


                  </div>
                </div>
              </div>
            ) : (
              <p>No campaign details available.</p>
            )}

            {/* Transaction details */}
            <h3 style={{ marginTop: '20px' }}>Transaction Details</h3>
            <table className="transaction-table" style={{ width: '100%', marginTop: '10px', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={{ borderBottom: '2px solid #ddd', padding: '10px' }}>Name</th>
                  <th style={{ borderBottom: '2px solid #ddd', padding: '10px' }}>Amount</th>
                  <th style={{ borderBottom: '2px solid #ddd', padding: '10px' }}>Mobile Number</th>
                  {/* <th style={{ borderBottom: '2px solid #ddd', padding: '10px' }}>Date</th> */}
                  {/* <th>Status</th> */}
                </tr>
              </thead>
              <tbody>
                {transactionDetails.length > 0 ? (
                  transactionDetails.map((transaction, index) => (
                    <tr key={index}>
                      <td style={{ borderBottom: '1px solid #ddd', padding: '10px' }}>{transaction.name}</td>
                      <td style={{ borderBottom: '1px solid #ddd', padding: '10px' }}>{transaction.amount}</td>
                      <td style={{ borderBottom: '1px solid #ddd', padding: '10px' }}>
                        {transaction.mobilenumber.slice(0, -4).replace(/\d/g, '*') + transaction.mobilenumber.slice(-4)}
                      </td>                      {/* <td style={{ borderBottom: '1px solid #ddd', padding: '10px' }}>{transaction.date}</td> */}
                      {/* <td>{transaction.status}</td> */}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="3" style={{ textAlign: 'center', padding: '10px' }}>No transaction details available.</td>
                  </tr>
                )}
              </tbody>
            </table>
            <div>
              <button onClick={() => setUserCampaignDetailModalOpen(false)} className="close-button">Close</button>
            </div>
          </div>
        </div>
      )}

      <footer>
        <Footer />
      </footer>
    </div >
  );
};
