export const Contact =()=>{
    return(
      <div>
        Contect
      </div>
    )
}