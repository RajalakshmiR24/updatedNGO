import React, { useState } from 'react';
import './Navbar.css';
import { Link } from 'react-router-dom';

const Navbar = () => {
    return (
        <div>
            <nav className="navbar">
                <div className="logo">
                    <div className='ngo'><li><Link to="/">NGO</Link></li></div>
                </div>
                <div className='nav-links'>
                    {/* <div><Link to="/about" className="about">About</Link></div> */}
                    <div><Link to="/signup" className="signup">Login/SignUp</Link></div>
                </div>
            </nav>
        </div>
    );
}

export default Navbar;

