// import { Link, Outlet } from "react-router-dom"

// export const Homeeee = () => {
//     return (
//         <>
//             <nav>
//                 <ul>
//                     <div className="homenav">
//                         <li><Link to='/Home'>Home Page</Link></li>
//                         <li><Link to='/About'>About</Link></li>
//                         <li><Link to='/'>What we do</Link></li>
//                     </div>
//                     <div className="homenav">
//                         <li><Link to='/profile'>Profile</Link></li>
//                     </div>
//                 </ul>
//             </nav>
//             <Outlet />
//         </>
//     )
// }