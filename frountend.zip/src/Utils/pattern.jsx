export const usernamePattern = "^[A-Za-z0-9 ]{3,20}$";
export const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
export const mobilePattern = "^[6-9][0-9]{9}$";
export const accountNumberPattern = "^[0-9]{9,16}$";
export const ifscCodePattern = "^[A-Z]{4}0[A-Z0-9]{6}$";
export const passwordPattern ="^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,20}$";
export const amountPattern = "^[0-9]+(\\.[0-9]{1,2})?$"
export const fourDigits = "^\d{4}$"