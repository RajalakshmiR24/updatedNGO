import { createBrowserRouter } from "react-router-dom";

// User Components
import UserSignIn from "../Components/User/UserLogin/UserSignIn.jsx";
import UserSignUp from "../Components/User/UserLogin/UserSignUp.jsx";
import CampaignDashboard from "../Components/User/Pages/1.Dashboard/Dashboard";
import CampaignLayout from "../Components/User/Layout/UserLayout";
import GeneralUsersList from "../Components/User/Pages/3.General/List/GeneralUsersList";

// ?Landing
import NotFound from "../Components/Common/NotFound/notFound";
import UserCampaigns from "../Components/User/Pages/2.Campaigns/UserCampaigns.jsx";
import PaymentForm from "../Utils/PaymentForm";
import { Layout } from "./../LandingPage/Layout/Layout";
import { HomePage } from "./../LandingPage/Pages/Home/Home";
import { Payments } from "../Utils/Payments.jsx";

export const router = createBrowserRouter([
  {
    path: "/", //landing page
    element: <Layout />,
    children: [{ index: true, element: <HomePage /> }],
  },
  {
    path: "/register-user",
    element: <CampaignLayout />,
    children: [
      { index: true, element: <CampaignDashboard /> },
      {
        path: "new-campaign",
        element: <UserCampaigns />,
      },
      { path: "general-users", element: <GeneralUsersList /> },
    ],
  },
  {
    path: "/signin",
    element: <UserSignIn />,
  },
  {
    path: "/signup",
    element: <UserSignUp />,
  },
  {
    path: "/transaction",
    element: <PaymentForm />,
  },
  {
    path: "/logout",
    element: <UserSignIn />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
  {
    path:"/payments",
    element:<Payments/>
  },
]);
