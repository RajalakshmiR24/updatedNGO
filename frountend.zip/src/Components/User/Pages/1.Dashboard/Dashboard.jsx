import React from 'react'
import './Dashboard.css'

import LineChart from './CHARTS/LineChart/LineCharts'
import StatusCounts from './CHARTS/BARCHART/Barchart'

const CampaignDashboard = () => {

  

  return (
    <div>
      <div className='charts_dashboard'>
        <div className='chart_line'>< LineChart /></div>
        <div className='chart_count'><StatusCounts /></div>
      </div>
    </div>


  )
}

export default CampaignDashboard
