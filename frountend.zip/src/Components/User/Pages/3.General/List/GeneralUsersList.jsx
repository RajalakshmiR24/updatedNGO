import React, { useContext, useEffect, useState } from "react";
import axiosInstance from "../../../../../Utils/axiosInstance";
import "./GeneralUsersList.css";
import { CampaignContext } from "../../../../../Context/CampaignContext.jsx";

const GeneralUsersList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isUserTransactionsModelPopUpOpen, setUserTransactionsModelPopUpOpen] =
    useState(false);
  const [campaigns, setCampaigns] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [isUserBillsModelPopUpOpen, setUserBillsModelPopUpOpen] =
    useState(false);
  const [bills, setBills] = useState([]);
  const [campId, setCampId] = useState("");

  const email = localStorage.getItem("hash");

  const fetchUsers = async () => {
    try {
      const response = await axiosInstance.post(
        "/user/transactionpercampaign",
        {
          email,
        }
      );
      if (response.data.code === 200) {
        // console.log(response.data, "reeeeeeeessssssssssssssss");

        setUsers([response.data.data]);
        setCampaigns(response.data.data.campaigns);
        setBills(response.data.data.bills);
      }
    } catch (err) {
      console.error(err, "error in fetching data");
    }
  };

  const fetchTransactionData = (campId) => {
    try {
      axiosInstance
        .post(`user/transactiondatabycampid`, { campId })
        .then((res) => {
          console.log(res, "traaaaaaaaaaans data");

          if (res.data.code === 200) {
            setTransactions(res.data.data);
          }
        })
        .catch((err) => {
          console.log(err, "error in fetching data");
        });
    } catch (error) {
      console.log(error, "error in fetching data");
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // const handleAction = (userId) => {
  //   const user = users.find((u) => u._id === userId);
  //   setSelectedUser(user);
  // };

  // const closeModal = () => {
  //   setSelectedUser(null);
  // };

  // if (loading) return <div>Loading...</div>;
  // if (error) return <div>Error: {error}</div>;

  return (
    <div className="listform">
      <h2>General User List</h2>
      <table>
        <thead>
          <tr>
            <th>Campaign Title</th>
            <th>Budget</th>
            <th>Collected Amount</th>
            <th>Transactions</th>
            <th>Bills</th>
          </tr>
        </thead>
        <tbody>
          {campaigns.map((campaign) => (
            <tr key={campaign.campaign_id}>
              <td>{campaign.campaign_title}</td>
              <td>{campaign.estimated_budget}</td>
              <td>{campaign.collected_amount}</td>
              <td>
                {
                  <button
                    onClick={() => {
                      setUserTransactionsModelPopUpOpen(true);
                      fetchTransactionData(campaign.campaign_id);
                      setCampId(campaign.campaign_id);
                    }}
                    className="view-button"
                  >
                    View
                  </button>
                }
              </td>
              <td>
                {
                  <button
                    onClick={() => {
                      setUserBillsModelPopUpOpen(true);
                      // console.log(transactions.length);
                      setCampId(campaign.campaign_id);
                    }}
                    className="view-button"
                  >
                    View
                  </button>
                }
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {/* <UserModal user={selectedUser} onClose={closeModal} /> */}

      {isUserTransactionsModelPopUpOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2 className="modal-title">Transaction Details</h2>

            {/* Filter transactions for the selected campaign */}
            {(() => {
              const filteredTransactions = transactions.filter(
                (transaction) => transaction.campaign_id === campId
              );

              return filteredTransactions.length > 0 ? (
                filteredTransactions.map((transaction, index) => (
                  <div key={index} className="transaction-detail">
                    <div className="modal-background" />
                    <p>{index + 1}.</p>
                    <p>
                      <strong>Name:</strong> {transaction.name}
                    </p>
                    <p>
                      <strong>Amount:</strong> {transaction.amount}
                    </p>
                    <hr></hr>
                  </div>
                ))
              ) : (
                <p>No transaction details available for this campaign.</p>
              );
            })()}

            <button
              onClick={() => setUserTransactionsModelPopUpOpen(false)}
              className="close-button"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* UserBills modal */}
      {isUserBillsModelPopUpOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2 className="modal-title">Bills</h2>

            {/* Filter bills for the selected campaign */}
            {(() => {
              const filteredBills = bills.filter(
                (bill) => bill.campaign_id === campId
              );

              if (filteredBills.length > 0) {
                return filteredBills.map((bill, index) => (
                  <div key={index} className="bill-detail">
                    <div className="modal-background" />
                    <p>{index + 1}.</p>
                    <img src={bill.bills} />
                    <p>
                      <strong>Amount:</strong> {bill.claiming_amount}
                    </p>
                    <p>
                      <strong>Status:</strong> {bill.status}
                    </p>
                    <hr></hr>
                  </div>
                ));
              } else {
                return <p>No bills available.</p>;
              }
            })()}

            <button
              onClick={() => setUserBillsModelPopUpOpen(false)}
              className="close-button"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// const UserModal = ({ user, onClose }) => {
//   if (!user) return null;

//   return (
//     <div className="modal-overlay" onClick={onClose}>
//       <div className="modal-content" onClick={(e) => e.stopPropagation()}>
//         <h2>User Details</h2>
//         <p><strong>Name:</strong> {user.name}</p>
//         <p><strong>Email:</strong> {user.email}</p>
//         <p><strong>Mobile Number:</strong> {user.mobilenumber}</p>
//         <p><strong>Total Amount:</strong> {user.amount}</p>
//         <p><strong>No. of Campaigns:</strong> {user.campaigndetails.length}</p>
//         <button onClick={onClose}>Close</button>
//       </div>
//     </div>
//   );
// };

export default GeneralUsersList;
