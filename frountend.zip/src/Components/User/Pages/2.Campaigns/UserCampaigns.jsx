import { useContext, useEffect, useState } from "react";
import { CampaignContext } from "../../../../Context/CampaignContext";
import "./Campaigns.css"; // Ensure this CSS file is linked
import axiosInstance from "../../../../Utils/axiosInstance";
import { toast, ToastContainer } from "react-toastify";

const UserCampaigns = () => {
  const [isClaimBillsPopupOpen, setIsClaimBillsPopupOpen] = useState(false);
  const [isCampaignFormModalOpen, setCampaignFormModalOpen] = useState(false);
  const email = localStorage.getItem("hash");
  const [claimBillsData, setClaimBillsData] = useState({});
  const [formData, setFormData] = useState({});
  const [userCampaigns, setUserCampaigns] = useState([]);
  const [isUserCampaignDetailModalOpen, setUserCampaignDetailModalOpen] =
    useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState([]);
  const [cancelReasonModalPopUpOpen, setCancelReasonModalPopUpOpen] =
    useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [campaignId, setCampaignId] = useState("");

  const fetchUserCampaignsDatas = async () => {
    try {
      const res = await axiosInstance.post("/user/campaignperuser", { email });
      if (res.data.code === 200) {
        setUserCampaigns(res.data.data);
      }
    } catch (error) {
      console.error("Error fetching campaign data:", error.message);
    }
  };
  const [updatedData, setUpdatedData] = useState({});

  const handleCampaignUpdate = (e) => {
    const { name, value } = e.target;
    setUpdatedData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };
  const validateDates = (campaign) => {
    const today = new Date();
    const startDate = new Date(campaign.start_date);
    const endDate = new Date(campaign.end_date);

    // Start date must be at least one week from today
    const oneWeekFromNow = new Date();
    oneWeekFromNow.setDate(today.getDate() + 7);

    if (startDate < oneWeekFromNow) return false;
    if (endDate <= startDate) return false; // End date must be after start date
    if (startDate.toDateString() === endDate.toDateString()) return false; // Start and end dates should not be the same

    return true;
  };

  const updateValidateDates = (campaign) => {
    const today = new Date();
    const startDate = new Date(campaign.campaign_start_date);
    const endDate = new Date(campaign.campaign_end_date);

    // Start date must be at least one week from today
    const oneWeekFromNow = new Date();
    oneWeekFromNow.setDate(today.getDate() + 7);

    if (startDate < oneWeekFromNow) return false;
    if (endDate <= startDate) return false; // End date must be after start date
    if (startDate.toDateString() === endDate.toDateString()) return false; // Start and end dates should not be the same

    return true;
  };
  const handleSubmitUpdateCampaign = async (e) => {
    e.preventDefault();

    if (!updateValidateDates(updatedData)) {
      alert("Please ensure the dates are valid.");
      return;
    }
    if (updatedData.estimated_budget < 0) {
      alert("Estimated budget must be a non-negative value.");
      return;
    }

    try {
      const res = await axiosInstance.post(`/user/updatecampaign`, updatedData);
      if (res.data.code === 200) {
        fetchUserCampaignsDatas();
        setUserCampaignDetailModalOpen(false);
      }
    } catch (error) {
      console.error("Error updating campaign:", error);
    }
  };

  const convertIntoBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);
      fileReader.onload = () => resolve(fileReader.result);
      fileReader.onerror = (error) => reject(error);
    });
  };

  const handleFormDataChange = async (e) => {
    const { name, value } = e.target;
    const file = e.target.files ? e.target.files[0] : null;

    if (file) {
      const base64 = await convertIntoBase64(file);
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
        banner: base64,
        user_email: email,
      }));
    } else {
      setFormData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    }
  };

  useEffect(() => {
    fetchUserCampaignsDatas();
  }, []);

  const handleClaimBillChange = async (e) => {
    const { name, value } = e.target;
    const file = e.target.files ? e.target.files[0] : null;

    if (file) {
      try {
        const billsBase64 = await convertIntoBase64(file);
        setClaimBillsData((prevState) => ({
          ...prevState,
          [name]: value,
          bills: billsBase64, // Set bills as Base64
          campId: campaignId,
          email: email,
        }));
      } catch (error) {
        console.error("Error converting file to Base64:", error);
      }
    } else {
      setClaimBillsData((prevState) => ({
        ...prevState,
        [name]: value,
      }));
    }
  };
  // console.log(claimBillsData, "sstttttttaaaaaaaaaattttteeeeeeeeeeeeee");

  const handleClaimBillsSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axiosInstance.post("/user/savebills", claimBillsData);
      if (res.data.code === 200) {
        setClaimBillsData({});
        setIsClaimBillsPopupOpen(false);
      }
    } catch (error) {
      console.error("Error submitting fund request:", error);
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    if (!validateDates(formData)) {
      alert("Please ensure the dates are valid.");
      return;
    }
    if (formData.estimated_budget < 0) {
      alert("Estimated budget must be a non-negative value.");
      return;
    }
    try {
      const res = await axiosInstance.post("/user/savecampaigndata", formData);
      if (res.data.code === 200) {
        setCampaignFormModalOpen(false);
        fetchUserCampaignsDatas();
      }
    } catch (error) {
      console.error("Error creating campaign:", error.message);
    }
  };

  const handleCancelReasonSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axiosInstance.post("/user/campaigncancel", {
        campaign_id: campaignId,
        cancel_reason: cancelReason,
      });
      if (res.data.code === 200) {
        setCancelReasonModalPopUpOpen(false);
        fetchUserCampaignsDatas();
      }
    } catch (error) {
      console.error("Error cancelling campaign:", error);
    }
  };

  const fetchUserCampDetails = (campId) => {
    setUserCampaignDetailModalOpen(true);
    const data = userCampaigns.filter((item) => item.campaign_id === campId);
    setSelectedCampaign(data);
  };

  const formatDate = (dateString) => {
    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "short",
    }).format(new Date(dateString));
  };

  const formatDate1 = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  return (
    <div className="campaignform">
      <h1 className="campaign-title">Campaigns</h1>
      <button
        onClick={() => setCampaignFormModalOpen(true)}
        className="create-camp-button"
      >
        Create Campaign
      </button>

      <table className="campaign-table">
        <thead>
          <tr>
            <th>Campaign Name</th>
            <th>Type</th>
            {/* <th>Est Budget</th> */}
            <th>Timeline</th>
            <th>Location</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {userCampaigns.length > 0 ? (
            userCampaigns.map((campaign, index) => (
              <tr key={index}>
                <td>{campaign.campaign_title || "N/A"}</td>
                <td>{campaign.campaign_type || "N/A"}</td>
                {/* <td>{campaign.estimated_budget}</td> */}
                <td>{`${formatDate(
                  campaign.campaign_start_date
                )} - ${formatDate(campaign.campaign_end_date)}`}</td>
                <td>{campaign.campaign_address || "N/A"}</td>
                <td>{campaign.status || "N/A"}</td>
                <td>
                  <div className="reg_user_campaign">
                    <button
                      onClick={() => {
                        fetchUserCampDetails(campaign.campaign_id);
                        const matchingCampaigns = userCampaigns.filter(
                          (camp) => camp.campaign_id === campaign.campaign_id
                        );
                        console.log(matchingCampaigns, "matching campaigns");

                        if (matchingCampaigns.length > 0) {
                          setUpdatedData(matchingCampaigns[0]);
                        }
                      }}
                      className="view-button"
                    >
                      View
                    </button>
                    {campaign.status === "COMPLETED" ? (
                      <button
                        onClick={() => {
                          setIsClaimBillsPopupOpen(true);
                          setCampaignId(campaign.campaign_id);
                        }}
                        className="claim-button"
                      >
                        Claim
                      </button>
                    ) : campaign.status !== "CANCELLED" ? (
                      <button
                        className="cancel_button"
                        onClick={() => {
                          setCampaignId(campaign.campaign_id);
                          setCancelReasonModalPopUpOpen(true);
                        }}
                      >
                        Cancel
                      </button>
                    ) : null}
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7">No campaigns found.</td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Campaign Detail Modal */}
      {isUserCampaignDetailModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2 className="modal-title">Campaign Details</h2>
            {selectedCampaign.length > 0 ? (
              selectedCampaign.map((campaign, index) => (
                <div key={index} className="campaign-detail">
                  <div>
                    <img src={campaign.banner} alt="Campaign Banner" />
                  </div>
                  <form onSubmit={handleSubmitUpdateCampaign}>
                    <div>
                      <p>
                        <strong>Title:</strong>
                      </p>
                      <input
                        type="text"
                        className="no-border"
                        name="campaign_title"
                        value={updatedData.campaign_title || ""}
                        onChange={handleCampaignUpdate}
                      />
                    </div>
                    <div>
                      <input
                        style={{ display: "none" }}
                        type="text"
                        className="no-border"
                        name="campaign_id"
                        value={updatedData.campaign_id}
                        onChange={handleCampaignUpdate}
                        disabled
                      />
                    </div>
                    <div>
                      <p>
                        <strong>Type:</strong>
                      </p>
                      <input
                        type="text"
                        className="no-border"
                        name="campaign_type"
                        value={updatedData.campaign_type}
                        onChange={handleCampaignUpdate}
                      />
                    </div>
                    <div>
                      <p>
                        <strong>Description:</strong>
                      </p>
                      <textarea
                        rows="4"
                        name="campaign_description"
                        value={updatedData.campaign_description}
                        className="no-border"
                        onChange={handleCampaignUpdate}
                      />
                    </div>
                    <div>
                      <p>
                        <strong>Start Date:</strong>
                      </p>
                      <input
                        type="date"
                        className="no-border"
                        name="campaign_start_date"
                        value={formatDate1(updatedData.campaign_start_date)}
                        onChange={handleCampaignUpdate}
                      />
                    </div>
                    <div>
                      <p>
                        <strong>End Date:</strong>
                      </p>
                      <input
                        type="date"
                        className="no-border"
                        name="campaign_end_date"
                        value={formatDate1(updatedData.campaign_end_date)}
                        onChange={handleCampaignUpdate}
                      />
                    </div>
                    <div>
                      <p>
                        <strong>Address:</strong>
                      </p>
                      <input
                        type="text"
                        className="no-border"
                        name="campaign_address"
                        value={updatedData.campaign_address}
                        onChange={handleCampaignUpdate}
                      />
                    </div>
                    <div>
                      <p>
                        <strong>Budget:</strong>
                      </p>
                      <input
                        type="number"
                        className="no-border"
                        name="estimated_budget"
                        value={updatedData.estimated_budget}
                        onChange={handleCampaignUpdate}
                      />
                    </div>
                    <div>
                      <p>
                        <strong>Collected Amount:</strong>{" "}
                        {campaign.collected_amount}
                      </p>
                    </div>
                    <div>
                      <button type="submit" className="update-button">
                        Update
                      </button>
                      <button
                        type="button"
                        onClick={() => setUserCampaignDetailModalOpen(false)}
                        className="close-button"
                      >
                        Close
                      </button>
                    </div>
                  </form>
                </div>
              ))
            ) : (
              <p>No campaign details available.</p>
            )}
          </div>
        </div>
      )}

      {/* Cancel Reason Modal */}
      {cancelReasonModalPopUpOpen && (
        <div className="modal">
          <div className="modal-content">
            <span
              className="close"
              onClick={() => setCancelReasonModalPopUpOpen(false)}
            >
              &times;
            </span>
            <h2>Cancel Campaign</h2>
            <form onSubmit={handleCancelReasonSubmit}>
              <label htmlFor="cancelReason">Reason for Cancellation:</label>
              <textarea
                id="cancelReason"
                name="cancelReason"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                required
              />
              <button type="submit">Submit</button>
              <button
                type="button"
                onClick={() => setCancelReasonModalPopUpOpen(false)}
              >
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Claim Bills Modal */}
      {isClaimBillsPopupOpen && (
        <div className="modal">
          <div className="modal-content">
            <span
              className="close"
              onClick={() => setIsClaimBillsPopupOpen(false)}
            >
              &times;
            </span>
            <h2>Claim Bills</h2>
            <form onSubmit={handleClaimBillsSubmit}>
              <label htmlFor="bills">Upload Bills:</label>
              <input
                type="file"
                name="bills"
                onChange={handleClaimBillChange}
                required
              />
              <label htmlFor="amountt">Claiming Amount</label>

              <input
                type="text"
                id="amountt"
                name="amount"
                value={claimBillsData.amount || ""}
                onChange={handleClaimBillChange}
                required
              />
              <button type="submit">Submit</button>
              <button
                type="button"
                onClick={() => setIsClaimBillsPopupOpen(false)}
              >
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Campaign Form Modal */}
      {isCampaignFormModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <span
              className="close"
              onClick={() => setCampaignFormModalOpen(false)}
            >
              x
            </span>
            <h2>Create Campaign</h2>
            <form onSubmit={handleFormSubmit}>
              <label htmlFor="campaign_title">Campaign Title:</label>
              <input
                type="text"
                id="campaign_title"
                name="title"
                value={formData.title || ""}
                onChange={handleFormDataChange}
                required
              />
              <label htmlFor="campaign_type">Campaign Type:</label>
              <input
                type="text"
                id="campaign_type"
                name="type"
                value={formData.type || ""}
                onChange={handleFormDataChange}
                required
              />
              <label htmlFor="campaign_description">Description:</label>
              <textarea
                id="campaign_description"
                name="description"
                value={formData.description || ""}
                onChange={handleFormDataChange}
                required
              />
              <label htmlFor="campaign_start_date">Start Date:</label>
              <input
                type="date"
                id="campaign_start_date"
                name="start_date"
                value={formData.start_date || ""}
                onChange={handleFormDataChange}
                required
              />
              <label htmlFor="campaign_end_date">End Date:</label>
              <input
                type="date"
                id="campaign_end_date"
                name="end_date"
                value={formData.end_date || ""}
                onChange={handleFormDataChange}
                required
              />
              <label htmlFor="campaign_address">Address:</label>
              <input
                type="text"
                id="campaign_address"
                name="address"
                value={formData.address || ""}
                onChange={handleFormDataChange}
                required
              />
              <label htmlFor="budget">Estimated Budget:</label>
              <input
                type="number"
                id="estimated_budget"
                name="budget"
                value={formData.budget || ""}
                onChange={handleFormDataChange}
                required
              />
              <label htmlFor="banner">Upload Banner:</label>
              <input
                type="file"
                id="banner"
                name="banner"
                // value={formData.banner || ""}
                onChange={handleFormDataChange}
                required
              />
      
              <button className="create-camp-button" type="submit">
                Create Campaign
              </button>
              <button
                type="button"
                className="camp-cancel-button"
                onClick={() => setCampaignFormModalOpen(false)}
              >
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserCampaigns;
