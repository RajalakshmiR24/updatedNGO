import React, { useState } from "react";
import { Link, unstable_HistoryRouter, useNavigate } from "react-router-dom";
import "./Sidebar.css";
// import { FaTachometerAlt, FaUsers, FaEnvelope, FaClipboardList, FaUserFriends } from 'react-icons/fa'; // Add icons from react-icons

const Sidebar = () => {

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("hash");
    window.location.href = "/";
    
    
  };

  return (
    <div className="sidebar" aria-label="campaign Panel Navigation">
      <h2>NGO Campaign Panel</h2>
      <ul>
        <li>
          <Link to="/register-user">Dashboard</Link>
        </li>
        <li>
          <Link to="/register-user/new-campaign">Campaign</Link>
        </li>
        <li>
          <Link to="/register-user/general-users">Transaction</Link>
        </li>
        {/* <li><Link to="/register-user/active campaign">Active campaign</Link></li>
        <li><Link to="/register-user/announcement">Announcement</Link></li>
        <li><Link to="/register-user/queries">Queries</Link></li> */}
        <li>
          <button className="user_logout" onClick={handleLogout}>
            Logout
          </button>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
