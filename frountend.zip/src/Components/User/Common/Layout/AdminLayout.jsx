import React from 'react';
import Sidebar from '../Sidebar/Sidebar'; 
import { Outlet } from 'react-router-dom';
import Breadcrumb from '../Breadcrumb/Breadcrumb';

const AdminLayout = () => {
  return (

    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div style={{ marginLeft: '250px', padding: '20px', flex: 1 }}>
        <Breadcrumb />
        <Outlet />
      </div>
    </div>
  );
}

export default AdminLayout;
