import React from 'react';
import './notFound.css'; // Import the CSS file

const NotFound = () => {
  return (
    <div className="not-found">
      <div className="card">
        <h1>404</h1>
        <p>Oops! The page you are looking for does not exist.</p>
        <a href="/">Go back to homepage</a>
      </div>
    </div>
  );
};

export default NotFound;
