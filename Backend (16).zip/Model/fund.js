const mongoose = require("mongoose");

const fundModel = new mongoose.Schema({
    title: {
        type: String,
    },
    description: {
        type: String
    },
    amount: {
        type: String,
    },
    email_hash: {
        type: String
    },
    campaign_id: { type: String }

}, {
    timestamps: true
})



const FundRequestModel = mongoose.model("FundRequest", fundModel);

module.exports = { FundRequestModel }