const { Admin } = require("../Model/admin.js");
const { BillModel } = require("../Model/bills.js");
const { Campaign } = require("../Model/campaign.js");
const { User } = require("../Model/user.js");


const getAllCampaignDetails = async (req, res) => {
    try {
        const campaignDetails = await Campaign.find();
        if (!campaignDetails) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaignDetails, count: campaignDetails.length })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const gettotalCampaignCount = async (req, res) => {
    try {
        const count = await Campaign.countDocuments();
        if (count === 0) {
            return res.status(200).json({ code: 400, message: "No campaign found" })
        }
        return res.status(200).json({ code: 200, data: count })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}


//count live upcoming rejected cancelled 
const totalCampaignCountByEmail = async (req, res) => {
    const { email } = req.body;
    if (!email) {
        return res.status(200).json({ code: 400, message: "Email is missing" })
    }
    try {
        const adminCampaignCountPerEmail = (await Campaign.find({ admin_email: email })).length;
        if (!adminCampaignCountPerEmail) {
            return res.status(200).json({ code: 400, message: "Admin campaigns not found" })
        }
        const userCampaignCountPerEmail = (await Campaign.find({ user_email: email })).length;
        if (!userCampaignCountPerEmail) {
            return res.status(200).json({ code: 400, message: "User campaigns not found" })
        }
        const totalCampaignCount = await Campaign.countDocuments();

        if (adminCampaignCountPerEmail === 0 && userCampaignCountPerEmail === 0) {
            return res.status(200).json({ code: 400, message: "NA" })

        }
        if (adminCampaignCountPerEmail === 0 && userCampaignCountPerEmail > 0) {
            return res.status(200).json({ code: 200, totalcount: totalCampaignCount, data: userCampaignCountPerEmail })
        }
        if (adminCampaignCountPerEmail > 0 && userCampaignCountPerEmail === 0) {
            return res.status(200).json({ code: 200, totalcount: totalCampaignCount, data: adminCampaignCountPerEmail })
        }

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }


}



////
const getAllUpcomingCampaigns = async (req, res) => {
    try {
        const campaigns = await Campaign.find(
            { status: { $in: ["ONGOING", "LIVE"] } },
            { _id: 0, bills: 0 }
        );


        // console.log(campaigns);


        // const images = await ImageModel.findOne({ campaign_id: campaigns.campaign_id })
        // const data = { campaigns, images }
        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}


const getCampaignCountByMonth = async (req, res) => {
    try {
        const date = new Date();
        // startOfMonth.setDate(1);
        // startOfMonth.setHours(0, 0, 0, 0);

        // const endOfMonth = new Date();
        console.log(date.getFullYear());
        console.log(date.getMonth() + 1);
        // endOfMonth.setMonth(endOfMonth.getMonth() + 1);
        // endOfMonth.setDate(0);
        // endOfMonth.setHours(23, 59, 59, 999);

        const startDate = new Date(date.getFullYear(), date.getMonth(), 1);
        const endDate = new Date(year, month, 0); // Last day of the month

        const campaignCount = await Campaign.countDocuments({
            campaign_start_date: {
                $gte: startDate,
                $lt: endDate
            }
        });

        return res.status(200).json({
            code: 200,
            // data: {
            //     campaignCount: campaignCount.length > 0 ? campaignCount[0].totalCampaigns : 0
            // }
            data: campaignCount
        });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }


};

const getCampaignCountPerDay = async (req, res) => {
    try {
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);

        const endOfDay = new Date();
        endOfDay.setHours(23, 59, 59, 999);

        const campaignCountday = await User.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: startOfDay,
                        $lte: endOfDay
                    }
                }
            },
            {
                $count: "totalCampaigns"
            }
        ]);

        return res.status(200).json({
            code: 200,
            data: {
                campaignCountday: campaignCountday.length > 0 ? campaignCountday[0].totalCampaigns : 0
            }
        });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }

}

const getCampaignCountByweek = async (req, res) => {
    try {
        const startOfWeek = new Date();
        startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
        startOfWeek.setHours(0, 0, 0, 0);

        const endOfWeek = new Date();
        endOfWeek.setDate(endOfWeek.getDate() + (6 - endOfWeek.getDay()));
        endOfWeek.setHours(23, 59, 59, 999);

        const campaignCountWeek = await User.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: startOfWeek,
                        $lte: endOfWeek
                    }
                }
            },
            {
                $count: "totalCampaigns"
            }
        ]);

        return res.status(200).json({
            code: 200,
            data: {
                campaignCountWeek: campaignCountWeek.length > 0 ? campaignCountWeek[0].totalCampaigns : 0
            }
        });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }


}

const getCampaignCountByYear = async (req, res) => {
    try {
        const startOfYear = new Date();
        startOfYear.setMonth(0);
        startOfYear.setDate(1);
        startOfYear.setHours(0, 0, 0, 0);

        const endOfYear = new Date();
        endOfYear.setMonth(11);
        endOfYear.setDate(31);
        endOfYear.setHours(23, 59, 59, 999);

        const campaignCount = await User.getTotalCampaignCount({
            createdAt: {
                $gte: startOfYear,
                $lte: endOfYear
            }
        });
        return res.status(200).json({ code: 200, data: { campaignCount } });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
}




module.exports = {
    getAllUpcomingCampaigns,
    getAllCampaignDetails,
    gettotalCampaignCount,
    totalCampaignCountByEmail,
    getCampaignCountByMonth,
    getCampaignCountPerDay,
    getCampaignCountByweek,

}
