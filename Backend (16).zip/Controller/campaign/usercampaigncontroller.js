const { Campaign } = require("../../Model/campaign");
const { User } = require("../../Model/user");
const { isBefore, isAfter, isEqual, subDays } = require('date-fns')


//user
const saveUserCampaignDetails = async (req, res) => {
    try {
        const { title, type, description, start_date, end_date, banner, user_email, address, budget } = req.body;
        // const missingFields = [];

        // if (!title) missingFields.push('title');
        // if (!type) missingFields.push('type');
        // if (!description) missingFields.push('description');
        // if (!start_date) missingFields.push('start_date');
        // if (!end_date) missingFields.push('end_date');
        // if (!banner) missingFields.push('banner');
        // if (!user_email) missingFields.push('user_email');
        // if (!address) missingFields.push('address');
        // if (!budget) missingFields.push('budget');

        // if (missingFields.length > 0) {
        //     return res.status(200).json({ code: 400, message: "Bad request", missingFields });
        // }
        // console.log(req.body);


        const campaign = await Campaign.create({
            campaign_title: title,
            campaign_address: address,
            estimated_budget: budget,
            banner: banner,
            campaign_type: type,
            campaign_description: description,
            campaign_start_date: start_date,
            campaign_end_date: end_date,
            user_email: user_email,
        });
        await campaign.save();


        const user = await User.findOne({ email_hash: user_email });
        if (!user) {
            return res.status(404).json({ code: 404, message: "User not found" });
        }
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Campaign not saved" })
        }
        console.log(user);

        user.campaigns.push(campaign._id);
        await user.save();
        console.log(user);


        campaign.user.push(user._id);
        campaign.save();

        return res.status(200).json({ code: 200, message: "Campaign data created successfully" });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};

const updateCampaignDetails = async (req, res) => {
    // console.log(req.body);
    try {
        const { campaign_title, campaign_type, campaign_description, campaign_start_date, campaign_end_date, banner, campaign_address, campaign_id, estimated_budget } = req.body;
        const campaign = await Campaign.findOne({ campaign_id: campaign_id })
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        const updateCampaign = await Campaign.updateOne({ campaign_id: campaign_id }, {
            $set: {
                campaign_title,
                campaign_address,
                estimated_budget,
                banner,
                campaign_type,
                campaign_description,
                campaign_start_date,
                campaign_end_date,
            }
        })
        if (!updateCampaign.modifiedCount > 0) {
            return res.status(200).json({ code: 400, message: "Campaign not updated" })
        }
        return res.status(200).json({ code: 200, message: "Updated successfully" })
    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });

    }
}

const findAllCampaignDetailsByCampaignId = async (req, res) => {
    try {
        const { campaign_id } = req.body;
        if (!campaign_id) {
            return res.status(200).json({ code: 400, message: "campId is missing" })
        }
        const campaigns = await Campaign.findOne({ campaign_id }, { _id: 0 })
            .populate({
                path: 'user',
                select: '-_id fullname mobile_number email'
            })
            .populate({
                path: 'admin',
                select: '- _id fullname mobile_number email'
            })
            .populate({
                path: 'bills',
                select: '-_id -email_hash -campaign_id'
            })
            .exec();

        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getAllUserCampaignDetails = async (req, res) => {
    try {
        const userCampaigns = await Campaign.find({ user_email: { $exists: true }, status: { $ne: "NOT_APPROVED" } }, { _id: 0 })
            .populate({
                path: 'user',
                select: '-_id fullname mobile_number email email_hash'
            })
        if (!userCampaigns) {
            return res.status(200).json({ code: 400, message: "No user campaigns found" })
        }
        // console.log(userCampaigns.user_email);
        // const user = await User.find({ email_hash: userCampaigns.user_email })
        return res.status(200).json({ code: 200, count: userCampaigns.length, data: userCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}

const getUserCampaignDetailsByCampaignId = async (req, res) => {
    const { campaign_id } = req.body;
    if (!campaign_id) {
        return res.status(200).json({ code: 400, message: "Campaign Id  is missing" })
    }
    try {
        const campaignData = await Campaign.find({ campaign_id, status: { $ne: "NOT_APPROVED" } }, { _id: 0 })
            .populate(
                {
                    path: 'user',
                    select: " -_id fullname email mobile_number"

                }
            ).exec();
        if (!campaignData) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, count: campaignData.length, data: campaignData })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const saveReasonForCampaignCancellation = async (req, res) => {
    try {
        const { campaign_id, cancel_reason } = req.body;
        if (!campaign_id) {
            return res.status(200).json({ code: 400, message: "Campaign ID is missing" })
        }
        if (!cancel_reason) {
            return res.status(200).json({ code: 400, messag: "Reason is missing" })
        }
        const campaign = await Campaign.findOne({ campaign_id });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "no campaigns found" })
        }
        if (campaign.status === "CANCELLED") {
            return res.status(200).json({ code: 400, message: "campaign cancelled already" })
        }
        const updateCampaign = await Campaign.updateOne({ campaign_id }, { $set: { status: "CANCELLED", reason_for_cancellation: cancel_reason } })
        // campaign.status = "CANCELLED";
        // campaign.reason_for_cancellation = cancel_reason;
        // campaign.save();
        if (updateCampaign.modifiedCount === 0) {
            return res.status(200).json({ code: 400, message: "campaign not updated" })
        }
        return res.status(200).json({ code: 200, message: "Reason saved successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}
const getUserCampaignDetailsByEmail = async (req, res) => {
    try {
        const { email } = req.body;
        const campaignData = await Campaign.find({ user_email: email, status: { $ne: "NOT_APPROVED" } }, { _id: 0 })
            .populate(
                {
                    path: 'user',
                    select: " -_id fullname email mobile_number"

                }
            )
            .exec();
        if (!campaignData) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, count: campaignData.length, data: campaignData })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}


const getAllCampaingsStatusCountPerUser = async (req, res) => {
    console.log(req.body);
    try {
        const currentDate = new Date();
        const { email } = req.body;
        if (!email) {
            return res.status(200).json({ code: 400, message: "Email is required" })
        }
        const campaigns = await Campaign.find({
            user_email: email,
            status: { $in: ["APPROVED", "UPCOMING", "LIVE", "ONGOING"] }
        });

        const statusCount = {
            LIVE: 0,
            ONGOING: 0,
            UPCOMING: 0,
            COMPLETED: 0,
            CANCELLED: 0,
            REJECTED: 0,
            NOT_APPROVED: 0,
            APPROVED: 0,
        };

        const updates = campaigns.map(campaign => {
            const campaignStartDate = new Date(campaign.campaign_start_date);
            const campaignEndDate = new Date(campaign.campaign_end_date);
            const ongoingStartDate = subDays(campaignStartDate, 4);
            let newStatus = campaign.status;

            if (isAfter(currentDate, campaignEndDate)) {
                newStatus = 'COMPLETED';
            } else if (isEqual(currentDate, campaignStartDate) ||
                (isAfter(currentDate, campaignStartDate) && isBefore(currentDate, campaignEndDate))) {
                newStatus = 'LIVE';
            } else if (isAfter(currentDate, ongoingStartDate) && isBefore(currentDate, campaignStartDate)) {
                newStatus = 'ONGOING';
            } else if (isBefore(currentDate, ongoingStartDate)) {
                newStatus = 'UPCOMING';
            }

            if (newStatus !== campaign.status && campaign.status !== 'NOT_APPROVED') {
                return { updateOne: { filter: { _id: campaign._id }, update: { status: newStatus } } };
            }
            return null;
        }).filter(Boolean);

        if (updates.length > 0) {
            await Campaign.bulkWrite(updates);
        }

        const allCampaigns = await Campaign.find();
        allCampaigns.forEach(campaign => {
            if (statusCount[campaign.status] !== undefined) {
                statusCount[campaign.status]++;
            }
        });

        return res.status(200).json({ code: 200, data: statusCount });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};

// const getCampaignCountByDWMYPerUser = async (req, res) => {
//     try {
//         const { email } = req.body;

//         if (!email) {
//             return res.status(400).json({ code: 400, message: "Email is required" });
//         }

//         const currentDate = new Date();

//         const counts = await Campaign.aggregate([
//             {
//                 $match: {
//                     user_email: email,
//                     status: { $in: ["APPROVED", "LIVE", "UPCOMING", "COMPLETED"] } // Filter for approved campaigns
//                 }
//             },
//             {
//                 $project: {
//                     day: { $dateToString: { format: "%Y-%m-%d", date: "$campaign_start_date" } },
//                     month: { $dateToString: { format: "%Y-%m", date: "$campaign_start_date" } },
//                     year: { $year: "$campaign_start_date" },
//                     status: {
//                         $switch: {
//                             branches: [
//                                 {
//                                     case: { $gte: ["$campaign_start_date", currentDate] },
//                                     then: "UPCOMING"
//                                 },
//                                 {
//                                     case: {
//                                         $and: [
//                                             { $lte: ["$campaign_start_date", currentDate] },
//                                             { $gte: ["$campaign_end_date", currentDate] }
//                                         ]
//                                     },
//                                     then: "LIVE"
//                                 },
//                                 {
//                                     case: { $lt: ["$campaign_end_date", currentDate] },
//                                     then: "COMPLETED"
//                                 }
//                             ],
//                             default: "UNKNOWN"
//                         }
//                     }
//                 }
//             },
//             {
//                 $group: {
//                     _id: {
//                         year: "$year",
//                         month: "$month",
//                         day: "$day",
//                         status: "$status"
//                     },
//                     count: { $sum: 1 }
//                 }
//             },
//             {
//                 $group: {
//                     _id: {
//                         year: "$_id.year",
//                         month: "$_id.month",
//                     },
//                     dailyCounts: {
//                         $push: {
//                             day: "$_id.day",
//                             upcomingCount: { $sum: { $cond: [{ $eq: ["$_id.status", "UPCOMING"] }, "$count", 0] } },
//                             liveCount: { $sum: { $cond: [{ $eq: ["$_id.status", "LIVE"] }, "$count", 0] } },
//                             completedCount: { $sum: { $cond: [{ $eq: ["$_id.status", "COMPLETED"] }, "$count", 0] } }
//                         }
//                     },
//                     totalCount: { $sum: "$count" } // Total count for the month
//                 }
//             },
//             {
//                 $sort: { "_id.year": 1, "_id.month": 1 } // Sort by year and month
//             }
//         ]);

//         // Count cancelled campaigns separately
//         const cancelledCounts = await Campaign.countDocuments({
//             user_email: email,
//             status: "CANCELLED"
//         });

//         // Count not approved campaigns separately
//         const notApprovedCounts = await Campaign.countDocuments({
//             user_email: email,
//             status: "NOT_APPROVED"
//         });

//         const resultData = {
//             counts: counts.map(monthData => ({
//                 year: monthData._id.year,
//                 month: monthData._id.month,
//                 dailyCounts: monthData.dailyCounts,
//                 totalCount: monthData.totalCount,
//                 cancelledCount: cancelledCounts, // Include cancelled count
//                 notApprovedCount: notApprovedCounts // Include not approved count
//             }))
//         };

//         return res.status(200).json({ code: 200, data: resultData });

//     } catch (error) {
//         return res.status(500).json({ code: 500, errorMessage: error.message });
//     }
// }


// const getAllCampaingsStatusCountPerUser = async (req, res) => {
//     console.log(req.body);
//     try {
//         const currentDate = new Date();
//         const { email } = req.body;
//         if (!email) {
//             return res.status(200).json({ code: 400, message: "Email is required" });
//         }

//         const campaigns = await Campaign.find({
//             user_email: email,
//             status: { $in: ["APPROVED", "UPCOMING", "LIVE", "ONGOING"] }
//         });

//         const statusCount = {
//             LIVE: 0,
//             ONGOING: 0,
//             UPCOMING: 0,
//             COMPLETED: 0,
//             CANCELLED: 0,
//             REJECTED: 0,
//             NOT_APPROVED: 0,
//             APPROVED: 0,
//         };

//         const updates = [];

//         campaigns.forEach(campaign => {
//             const campaignStartDate = new Date(campaign.campaign_start_date);
//             const campaignEndDate = new Date(campaign.campaign_end_date);
//             const ongoingStartDate = subDays(campaignStartDate, 4);
//             let newStatus = campaign.status;

//             console.log(`Current Date: ${currentDate}`);
//             console.log(`Campaign Start Date: ${campaignStartDate}`);
//             console.log(`Ongoing Start Date: ${ongoingStartDate}`);
//             console.log(`Campaign End Date: ${campaignEndDate}`);
            
//             if (isAfter(currentDate, campaignEndDate)) {
//                 newStatus = 'COMPLETED';
//             } else if (isEqual(currentDate, campaignStartDate) || (isAfter(currentDate, campaignStartDate) && isBefore(currentDate, campaignEndDate))) {
//                 newStatus = 'LIVE';
//             } else if (isAfter(currentDate, ongoingStartDate) && isBefore(currentDate, campaignStartDate)) {
//                 newStatus = 'ONGOING';
//             } else if (isBefore(currentDate, ongoingStartDate)) {
//                 newStatus = 'UPCOMING';
//             }

//             console.log(`Determined Status: ${newStatus}`);

//             // Update the status if it has changed
//             if (newStatus !== campaign.status && campaign.status !== 'NOT_APPROVED') {
//                 updates.push({ updateOne: { filter: { _id: campaign._id }, update: { status: newStatus } } });
//             }

//             // Increment the status count
//             if (statusCount[newStatus] !== undefined) {
//                 statusCount[newStatus]++;
//             }
//         });

//         // Perform bulk updates if necessary
//         if (updates.length > 0) {
//             await Campaign.bulkWrite(updates);
//         }

//         return res.status(200).json({ code: 200, data: statusCount });

//     } catch (error) {
//         return res.status(500).json({ code: 500, errorMessage: error.message });
//     }
// };



const getCampaignCountByDWMYPerUser = async (req, res) => {
    console.log(req.body);
    try {
        const currentDate = new Date();
        const { email } = req.body;
        if (!email) {
            return res.status(200).json({ code: 400, message: "Email is required" });
        }

        // Fetch campaigns for the user
        const campaigns = await Campaign.find({
            user_email: email,
            status: { $in: ["APPROVED", "UPCOMING", "LIVE", "ONGOING"] }
        });

        const statusCount = {
            LIVE: 0,
            ONGOING: 0,
            UPCOMING: 0,
            COMPLETED: 0,
            CANCELLED: 0,
            REJECTED: 0,
            NOT_APPROVED: 0,
            APPROVED: 0,
        };

        const updates = [];

        campaigns.forEach(campaign => {
            const campaignStartDate = new Date(campaign.campaign_start_date);
            const campaignEndDate = new Date(campaign.campaign_end_date);
            const ongoingStartDate = subDays(campaignStartDate, 4);
            let newStatus = campaign.status;

            console.log(`Current Date: ${currentDate}`);
            console.log(`Campaign Start Date: ${campaignStartDate}`);
            console.log(`Ongoing Start Date: ${ongoingStartDate}`);
            console.log(`Campaign End Date: ${campaignEndDate}`);
            
            if (isAfter(currentDate, campaignEndDate)) {
                newStatus = 'COMPLETED';
            } else if (isEqual(currentDate, campaignStartDate) || (isAfter(currentDate, campaignStartDate) && isBefore(currentDate, campaignEndDate))) {
                newStatus = 'LIVE';
            } else if (isAfter(currentDate, ongoingStartDate) && isBefore(currentDate, campaignStartDate)) {
                newStatus = 'ONGOING';
            } else if (isBefore(currentDate, ongoingStartDate)) {
                newStatus = 'UPCOMING';
            }

            console.log(`Determined Status: ${newStatus}`);

            // Update the status if it has changed
            if (newStatus !== campaign.status && campaign.status !== 'NOT_APPROVED') {
                updates.push({ updateOne: { filter: { _id: campaign._id }, update: { status: newStatus } } });
            }

            // Increment the status count
            if (statusCount[newStatus] !== undefined) {
                statusCount[newStatus]++;
            }
        });

        // Perform bulk updates if necessary
        if (updates.length > 0) {
            await Campaign.bulkWrite(updates);
        }

        // Fetch total counts of all campaigns
        const totalCampaigns = await Campaign.find({});
        totalCampaigns.forEach(campaign => {
            if (statusCount[campaign.status] !== undefined) {
                statusCount[campaign.status]++;
            }
        });

        return res.status(200).json({ code: 200, data: statusCount });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};








module.exports = {
    saveUserCampaignDetails,
    findAllCampaignDetailsByCampaignId,
    getAllUserCampaignDetails,
    getUserCampaignDetailsByCampaignId,
    saveReasonForCampaignCancellation,
    getAllCampaingsStatusCountPerUser,
    getCampaignCountByDWMYPerUser,
    getUserCampaignDetailsByEmail,
    updateCampaignDetails
}