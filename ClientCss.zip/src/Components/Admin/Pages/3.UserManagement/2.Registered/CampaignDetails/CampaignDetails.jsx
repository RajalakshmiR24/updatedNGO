import React, { useState } from "react";
import "./CampaignDetails.css";

const CampaignDetails = ({ campaigns = [], noCampaignMessage, onClose }) => {
  const [bannerImage, setBannerImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const getStatusClass = (status) => {
    switch (status.toLowerCase()) {
      case "live":
        return "status-red";
      case "upcoming":
        return "status-yellow";
      case "completed":
        return "status-green";
      default:
        return "";
    }
  };

  return (
    <div className="modal campaign-details-modal">
      <button className="button close-modal-button" onClick={onClose}>
        X
      </button>
      <h3 className="modal-title">Campaigns for User</h3>
      <div className="campaigns-list">
        {noCampaignMessage ? (
          <p className="message no-campaign-message">{noCampaignMessage}</p>
        ) : campaigns.length > 0 ? (
          campaigns.map((campaign) => (
            <div
              className="card campaign-card"
              key={campaign.id}
              onClick={() => handleCardClick(campaign)}
            >
              {campaign.banner && (
                <img
                  src={campaign.banner}
                  alt={campaign.campaign_title}
                  className="image campaign-image"
                />
              )}
              <div className="info campaign-info">
                <h4 className="info-title">{campaign.campaign_title}</h4>
                <p className="info-description">
                  {campaign.campaign_description}
                </p>
                <p className="info-start-date">
                  <strong>Start Date:</strong>{" "}
                  {new Date(campaign.start_date).toLocaleDateString()}
                </p>
                <p className="info-end-date">
                  <strong>End Date:</strong>{" "}
                  {new Date(campaign.end_date).toLocaleDateString()}
                </p>
                <p className="info-budget">
                  <strong>Budget:</strong>{" "}
                  {campaign.budget ? campaign.budget : "Not specified"}
                </p>
                <p className="info-address">
                  <strong>Address:</strong> {campaign.campaign_address}
                </p>
                <p
                  className={`info-status status ${getStatusClass(
                    campaign.status
                  )}`}
                >
                  <strong>Status:</strong> {campaign.status}
                </p>
              </div>
            </div>
          ))
        ) : (
          <p className="message no-campaigns-available">
            No campaigns available.
          </p>
        )}
      </div>
      {loading && <p className="loading-indicator">Loading image...</p>}{" "}
      {/* Loading indicator */}
      {bannerImage && (
        <div className="modal banner-image-modal">
          <button
            className="button close-image-button"
            onClick={() => setBannerImage(null)}
          >
            X
          </button>
          <img
            src={bannerImage}
            alt="Banner"
            className="image full-banner-image"
          />
        </div>
      )}
    </div>
  );
};

export default CampaignDetails;
