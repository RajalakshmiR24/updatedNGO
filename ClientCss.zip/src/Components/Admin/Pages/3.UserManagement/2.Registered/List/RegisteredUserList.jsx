import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../../../Utils/axiosInstance";
import CampaignDetails from "../CampaignDetails/CampaignDetails";
import UserDetails from "../UserDetails/UserDetails"; // Import UserDetails component
import "./RegisteredUserList.css";

const RegisteredUserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCampaigns, setSelectedCampaigns] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [showCampaignDetails, setShowCampaignDetails] = useState(false);
  const [showUserDetails, setShowUserDetails] = useState(false); // State to control UserDetails modal
  const [noCampaignMessage, setNoCampaignMessage] = useState("");
  const [noUserMessage, setNoUserMessage] = useState(""); // State for no user message

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get("/admin/allusers");
        setUsers(response.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleViewCampDetails = async (email) => {
    setNoCampaignMessage("");
    try {
      const response = await axiosInstance.post("/admin/campaignperuser", { email });
      const campaignsData = response.data.data;

      if (campaignsData && campaignsData.length > 0) {
        setSelectedCampaigns(campaignsData);
        setShowCampaignDetails(true);
      } else {
        setNoCampaignMessage("No campaigns found for this user.");
        setShowCampaignDetails(true);
      }
    } catch (err) {
      console.error("Error fetching campaigns:", err);
      setNoCampaignMessage("Failed to fetch campaigns: " + err.message);
      setShowCampaignDetails(true);
    }
  };

  const handleViewUserDetails = async (email) => {
    setNoUserMessage(""); // Resetting the message
    try {
      const response = await axiosInstance.get("/admin/allusers", { email }); // Assume a correct endpoint
      const userData = response.data.data;

      if (userData && userData.length > 0) {
        setSelectedUsers(userData);
        setShowUserDetails(true); // Show UserDetails modal
      } else {
        setNoUserMessage("No users found for this user.");
        setShowUserDetails(true);
      }
    } catch (err) {
      console.error("Error fetching users:", err);
      setNoUserMessage("Failed to fetch users: " + err.message);
      setShowUserDetails(true);
    }
  };

  const closeDetails = () => {
    setShowCampaignDetails(false);
    setShowUserDetails(false); // Close UserDetails modal
    setSelectedCampaigns([]);
    setSelectedUsers([]); // Reset selected users
    setNoCampaignMessage("");
    setNoUserMessage(""); // Reset no user message
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
<div className="container">
  {showCampaignDetails ? (
    <CampaignDetails
      campaigns={selectedCampaigns}
      noCampaignMessage={noCampaignMessage}
      onClose={closeDetails}
      className="campaign-details"
    />
  ) : showUserDetails ? (
    <UserDetails
      users={selectedUsers}
      noUserMessage={noUserMessage}
      onClose={closeDetails}
      className="user-details"
    />
  ) : (
    <div className="user-list-section">
      <h2 className="user-list-title">Registered User List</h2>
      <table className="user-list-table">
        <thead className="table-header">
          <tr className="header-row">
            <th className="header-cell">S.No</th>
            <th className="header-cell">Full Name</th>
            <th className="header-cell">Email</th>
            <th className="header-cell">Mobile Number</th>
            <th className="header-cell">No. of Camp</th>
          </tr>
        </thead>
        <tbody className="table-body">
          {users.map((user, index) => (
            <tr key={user._id} className="body-row">
              <td className="body-cell">{index + 1}</td>
              <td className="body-cell">
                <button
                  onClick={() => handleViewUserDetails(user.email_hash)}
                  className="view-user-button"
                >
                  {user.fullname}
                </button>
              </td>
              <td className="body-cell">{user.email}</td>
              <td className="body-cell">{user.mobile_number}</td>
              <td className="body-cell">
                <button
                  onClick={() => handleViewCampDetails(user.email_hash)}
                  className="view-camp-button"
                >
                  {user.campaigns ? user.campaigns.length : 0}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )}
</div>

  );
};

export default RegisteredUserList;
