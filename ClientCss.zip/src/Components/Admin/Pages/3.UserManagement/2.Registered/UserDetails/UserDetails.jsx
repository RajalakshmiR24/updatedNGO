import React, { useState } from "react";
import "./UserDetails.css";

const UserDetails = ({ users = [], noUserMessage, onClose }) => {
  const [bannerImage, setBannerImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const getStatusClass = (status) => {
    switch (status.toLowerCase()) {
      case "active":
        return "status-green";
      case "inactive":
        return "status-red";
      default:
        return "";
    }
  };

  return (
    <div className="user-details-modal">
      <button className="close-button" onClick={onClose}>
        X
      </button>
      <h3 className="modal-title">User Details</h3>

      <div className="user-list">
        {noUserMessage ? (
          <p className="no-user-message">{noUserMessage}</p>
        ) : users.length > 0 ? (
          users.map((user) => (
            <div className="user-card" key={user.email}>
              <div className="user-info">
                <h4 className="user-fullname">{user.fullname}</h4>
                <p className="user-email">
                  <strong>Email:</strong> {user.email}
                </p>
                <p className="user-mobile-number">
                  <strong>Mobile Number:</strong> {user.mobile_number}
                </p>
                <p className="user-address">
                  <strong>Address:</strong> {user.current_address}
                </p>
                <p className={`status ${getStatusClass(user.status)}`}>
                  <strong>Status:</strong> {user.status}
                </p>
                <p className="account-created-date">
                  <strong>Account Created:</strong>{" "}
                  {new Date(user.account_created_date).toLocaleDateString()}
                </p>
                <p className="bank-account-number">
                  <strong>Bank Account Number:</strong>
                  {user.bank_account_details &&
                  user.bank_account_details.length > 0
                    ? user.bank_account_details[0]?.account_number
                    : "Not specified"}
                </p>
                <p className="ifsc-code">
                  <strong>IFSC Code:</strong>
                  {user.bank_account_details &&
                  user.bank_account_details.length > 0
                    ? user.bank_account_details[0]?.IFSC_Code
                    : "Not specified"}
                </p>
              </div>
            </div>
          ))
        ) : (
          <p className="no-users-message">No users available.</p>
        )}
      </div>

      {loading && <p className="loading-message">Loading image...</p>}

      {bannerImage && (
        <div className="banner-image-modal">
          <button
            className="close-image-button"
            onClick={() => setBannerImage(null)}
          >
            X
          </button>
          <img src={bannerImage} alt="Banner" className="full-banner-image" />
        </div>
      )}
    </div>
  );
};

export default UserDetails;
