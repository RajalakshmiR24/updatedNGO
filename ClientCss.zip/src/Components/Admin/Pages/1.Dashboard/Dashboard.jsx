import React from "react";
import "./Dashboard.css";
import LineChart from "./CHARTS/LineChart/LineCharts";
import { PieChart } from "./CHARTS/PieCharts/PieCharts";
import Barchart from "./CHARTS/BARCHART/Barchart";

const Dashboard = () => {
  return (
    <div className="chart-container">
            <h1 className="dashboaed-heading">DASHBOARD</h1>

        <div className="linechart">
          <LineChart />
        </div>
     
        <div className="piechart">
          <PieChart />
        </div>
        <div className="barchart">
          <Barchart/>
        </div>
    </div>
  );
};

export default Dashboard;
