import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
// import Logo from "./Logo"; // Assuming you have a Logo component
import "./Sidebar.css"; // Assuming you have a CSS file for custom styling

const Sidebar = () => {
  const [openSubMenu, setOpenSubMenu] = useState({});
  const navigate = useNavigate();
  let location = useLocation();

  const navigation = [
    {
      title: "Dashboard",
      href: "/admin",
      icon: "bi bi-speedometer2",
    },
    {
      title: "Campaign",
      href: "/admin/campaigns",
      icon: "bi bi-flag-fill",
    },
    {
      title: "User Management",
      icon: "bi bi-people-fill",
      children: [
        {
          title: "Registered Users",
          href: "/admin/registered-users",
          icon: "bi bi-person-lines-fill",
        },
        {
          title: "General Users",
          href: "/admin/general-users",
          icon: "bi bi-person",
        },
      ],
    },
    {
      title: "Requests",
      href: "/admin/requests",
      icon: "bi bi-clipboard-list",
    },
    {
      title: "Queries",
      href: "/admin/queries",
      icon: "bi bi-envelope-fill",
    },
  ];

  const toggleSubMenu = (index) => {
    setOpenSubMenu((prevState) => ({
      ...prevState,
      [index]: !prevState[index],
    }));
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("hash");
    navigate("/admin/signin");
  };

  return (
    <div className="sidebar p-3">
      <div className="sidebar-header">
        {/* <Logo /> */}
        <h3>NGO ADMIN PANEL</h3>
        <button
          className="close-sidebar-button"
          onClick={() => document.getElementById("sidebarArea").classList.toggle("showSidebar")}
        ></button>
      </div>
      <div className="sidebar-navigation">
        <nav className="sidebarNav">
          {navigation.map((navi, index) => (
            <div key={index} className="nav-item">
              <div className="nav-link-container">
                <Link
                  to={navi.href || "#"}
                  className={`nav-link ${
                    location.pathname === navi.href ? "active" : "text-secondary"
                  }`}
                  onClick={() => navi.children && toggleSubMenu(index)}
                >
                  <i className={navi.icon}></i>
                  <span className="nav-title">{navi.title}</span>
                </Link>
                {navi.children && (
                  <i
                    className={`submenu-toggle ${openSubMenu[index] ? "up" : "down"}`}
                    onClick={() => toggleSubMenu(index)}
                  ></i>
                )}
              </div>
              {navi.children && openSubMenu[index] && (
                <div className="sub-menu">
                  {navi.children.map((child, childIndex) => (
                    <div key={childIndex} className="nav-item ms-4">
                      <Link
                        to={child.href}
                        className={`nav-link ${
                          location.pathname === child.href ? "active" : "text-secondary"
                        }`}
                      >
                        <i className={child.icon}></i>
                        <span className="nav-title">{child.title}</span>
                      </Link>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
          <div className="nav-item">
            <button onClick={handleLogout} className="logout-button nav-link">
              <i className="bi bi-box-arrow-right"></i> Logout
            </button>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
