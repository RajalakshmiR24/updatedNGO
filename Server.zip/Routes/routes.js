const express = require("express");
const { uploadImage, fetchImage } = require("../Controller/admincontroller");
const { getTransactionResponse } = require("../Controller/transactioncontroller");
const { getAllUpcomingCampaigns } = require("../Controller/campaigncontroller");
const { saveQueries } = require("../Controller/querycontroller");

const router = express.Router();


router.post("/savequeries", saveQueries);
// router.post("/redirect", (req, res) => {
//    console.log(req.body, "redirect apiiiiiiiiiiiiiiiiiii");
//    return res.redirect("http://192.168.1.29:3000", 200)
// })

// router.post("/bannerimage", uploadImage);
// router.post("/fetchbannerimage", fetchImage);

// router.post("/tran", getTransactionResponse)


router.get("/getallca", getAllUpcomingCampaigns)


module.exports = { router };
