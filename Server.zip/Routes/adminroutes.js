const express = require("express");
const { registerAdmin, adminLogin, findAllUsers, findAdminByEmail, adminLogout, deleteAdminByEmail, findAdminByEmailHash, updateAdminDetailsByEmailHash, totalCampaignCount, campaignCountPerUserByEmailHash, getBudgetPerUserForCampaignByEmailHash, getTotalRegisteredUsers, getTotalGeneralUsers, getAllTransactions, getUserDetailsToVerify, rejectUserRegistration, getCampaignDetailRequestToVerify, getTransactionDataPerCampaigns, getTransactionDetailsPerCampaignType, findUserByEmailHash, rejectCampaignRequest, getCampaignDetailsPerUserByEmailHash, rejectBillsByBillID, getTotalDonation, insertCampaignDataByEmailHash, uploadImage, fetchImage, getCampaignDetailsByCampaignId, getCampaignRequestToVerify, verifyOrApproveCampaignRequest, rejectOrApproveUserRegistration, getUserFundRequest, makeAdmin, makeUser, approveOrRejectCampaignRequest } = require("../Controller/admincontroller.js");
const { verifyToken, verifyJWT } = require("../Middlewares/auth");
const { getAllQueries } = require("../Controller/querycontroller.js");
const { gettotalCampaignCount, totalCampaignCountByEmail } = require("../Controller/campaigncontroller.js");
const { saveAdminCampaignBills, rejectOrVerifyBillsByCampaignId, getRegisteredUsersBillsToVerify, getTotalExpense, findBillById, getTotalApprovedExpense, getTotalPendingExpense } = require("../Controller/billscontroller.js");
const { getTotalContributionInAmount, getTotalGeneralUsersCount, getAllTransactionDetails, getTransactionByCampaignId, getAllTransactionDetailsByCampaignId, getAllTransactionDetailsForUser } = require("../Controller/transactioncontroller.js");
const { getTotalRegisteredUsersCount } = require("../Controller/usercontroller.js");
const { saveAdminCampaignDetails, getAllAdminCampaignDetails, getAllUpcomingCampaings, getAllCampaingsStatusCount, getCampaignCountByDWMY, getAdminCampaignByCampaignId, createCampaignForUser } = require("../Controller/campaign/admincampaigncontroller.js");
const { getAllUserCampaignDetails, saveReasonForCampaignCancellation, getUserCampaignDetailsByCampaignId, getUserCampaignDetailsByEmail } = require("../Controller/campaign/usercampaigncontroller.js");

const adminRouter = express.Router();

//admin profile routes
adminRouter.post("/register", registerAdmin);
adminRouter.post("/login", adminLogin)
adminRouter.post("/createadmin", makeAdmin);
adminRouter.post("/changeuser", makeUser);
adminRouter.get("/allusers", findAllUsers);
adminRouter.post("/findadminbyemail", findAdminByEmailHash);
adminRouter.post("/findbyemail", findAdminByEmail);
adminRouter.put("/update", updateAdminDetailsByEmailHash);
adminRouter.delete("/delete", deleteAdminByEmail);
adminRouter.post("/logout", adminLogout);

//user
adminRouter.post("/finduserbyemail", findUserByEmailHash);
adminRouter.get("/r_userscount", getTotalRegisteredUsersCount);
adminRouter.get("/g_users", getTotalGeneralUsersCount);

//dashboard routes

//total contribution expense
adminRouter.get("/totalcontribution", getTotalContributionInAmount);
adminRouter.get("/totalapprovedexpense", getTotalApprovedExpense)
adminRouter.get("/totalpendingexpense", getTotalPendingExpense)

//upcoming .. live cancel completed
adminRouter.get("/statuscount", getAllCampaingsStatusCount)
adminRouter.get("/statuscount1", getCampaignCountByDWMY)


//transaction


adminRouter.post("/campaigndataperuser", getCampaignDetailsPerUserByEmailHash);
adminRouter.post("/campaignbyid", getCampaignDetailsByCampaignId)

//campaign
adminRouter.get("/totalcampaigncount", gettotalCampaignCount);
adminRouter.post("/campaigncountbyid", totalCampaignCountByEmail)

//admin
adminRouter.post('/savecampaigndata', saveAdminCampaignDetails);
adminRouter.post("/getadmincampaignbyid", getAdminCampaignByCampaignId)
adminRouter.get("/alladmincampaigns", getAllAdminCampaignDetails);
adminRouter.post("/campaigncancel", saveReasonForCampaignCancellation);
adminRouter.post("/campaignforuser", createCampaignForUser)


//user
adminRouter.post("/getusercampaigns", getUserCampaignDetailsByCampaignId)
// adminRouter.post("/getusercampaignbyid", findUsersByCampaignId)
adminRouter.post("/campaignperuser", getUserCampaignDetailsByEmail)
adminRouter.get("/allusercampaigns", getAllUserCampaignDetails)



//registeredusers
adminRouter.post("/transactionpercampaign", getTransactionDetailsPerCampaignType)

//generalusers
adminRouter.get("/alltransactions", getAllTransactionDetails);
adminRouter.post("/transactionpercampaign", getAllTransactionDetailsForUser)


//getverify requests
adminRouter.get("/verifyuserdetails", getUserDetailsToVerify);
adminRouter.get("/campaignstatustoverify", getCampaignRequestToVerify)

//verify/reject request
adminRouter.post("/rejectuser", rejectOrApproveUserRegistration);
adminRouter.post("/rejectcampreq", approveOrRejectCampaignRequest);
adminRouter.put("/verifyrejectbills", rejectOrVerifyBillsByCampaignId);


//bills
adminRouter.post("/findbillbyid", findBillById)
adminRouter.post("/savebills", saveAdminCampaignBills)
adminRouter.get("/verifybills", getRegisteredUsersBillsToVerify)

//queries
adminRouter.get("/allqueries", getAllQueries);


// adminRouter.post("/bannerimage", uploadImage);
// adminRouter.post("/fetchbannerimage", fetchImage);

module.exports = adminRouter