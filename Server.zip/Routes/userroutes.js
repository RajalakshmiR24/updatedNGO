const express = require("express");
const { userLogin, userData, registerUser, getUsersCount, insertCampaignDataByEmailHash, userLogout, getLiveCampaings, getCancelledCampaings, getUpcomingCampaings, getApprovedCampaings, getNotApprovedCampaings, getLiveWithDetails, getCompleteCampaignWithDetails, getLiveCampaignWithDetails, getAllCampaignDetails, getCampaignDetailsPerUserByEmailHash, getUserCampaignImages, getTotalTransactionAmount, getTotalExpense, getCompletedCampaings, updateUser, getCampaignCountByYear } = require("../Controller/usercontroller");
const { verifyJWT } = require("../Middlewares/auth");
const { saveTransaction, getAllTransactionDetails, payForCampaign, getTransactionUsingHash, getAllTransactionDetailsByCampaignId, getAllTransactionDetailsForUser } = require("../Controller/transactioncontroller");
const { insertBillDetailsIntoCampaign } = require("../Controller/admincontroller");
const { fetchCampaignsWithUsers, findUsersByCampaignId, totalCampaignCountByEmail, getCampaignCountByMonth, getCampaignCountPerDay, getCampaignCountByweek } = require("../Controller/campaigncontroller.js");
const { saveUserCampaignBills, getUserTotalExpense, getUserTotalApprovedExpense, getUserTotalPendingExpense } = require("../Controller/billscontroller.js");
const { saveUserCampaignDetails, getUserCampaignDetailsById, saveReasonForCampaignCancellatin, saveReasonForCampaignCancellation, getAllCampaingsStatusCountPerUser, getCampaignCountByDWMYPerUser, getUserCampaignDetailsByCampaignId, getUserCampaignDetailsByEmail, updateCampaignDetails } = require("../Controller/campaign/usercampaigncontroller.js");
const userRouter = express.Router();


//user control
userRouter.post("/register", registerUser);
userRouter.post("/login", userLogin)
userRouter.put("/update", updateUser);
userRouter.post("/logout", userLogout);


//dashboard
//user's total contribution/expense

userRouter.post("/contribution", getTotalTransactionAmount)
userRouter.post("/getapprovedexpense", getUserTotalApprovedExpense);
userRouter.post("/getpendingexpense", getUserTotalPendingExpense)

userRouter.post("/statuscount", getAllCampaingsStatusCountPerUser)
userRouter.post("/statuscount1", getCampaignCountByDWMYPerUser)


//campaign

userRouter.get("/totalcampaigncount", totalCampaignCountByEmail)
userRouter.get("/count", getUsersCount);
userRouter.post("/updatecampaign", updateCampaignDetails)

// userRouter.get("/monthcount", getCampaignCountByMonth)
// userRouter.get("/daycount", getCampaignCountPerDay)
// userRouter.get("/weekcount", getCampaignCountByweek)
// userRouter.get("/yearcount", getCampaignCountByYear)


// userRouter.get("/complete", getCompletedCampaings)
// userRouter.get("/expense", getTotalExpense)
// userRouter.get("/live", getLiveCampaings)
// userRouter.get("/cancel", getCancelledCampaings)
// userRouter.get("/upcoming", getUpcomingCampaings)
userRouter.get("/approve", getApprovedCampaings)
userRouter.get("/notapprove", getNotApprovedCampaings)
userRouter.get("/livedetails", getLiveCampaignWithDetails)
userRouter.get("/completecampaigndetails", getCompleteCampaignWithDetails)


//campaign

userRouter.post("/savecampaigndata", saveUserCampaignDetails);
userRouter.post("/campaigndataperuser", getUserCampaignDetailsByCampaignId);
userRouter.post("/campaigncancel", saveReasonForCampaignCancellation)
userRouter.post("/campaignperuser", getUserCampaignDetailsByEmail)

// userRouter.post("/usercampaigndata", findUsersByCampaignId)

// userRouter.post("/getbannerpercampaign", getUserCampaignImages);
// userRouter.post('/campaigndata', insertCampaignDataByEmailHash);
// userRouter.post("/funds", fundRequest);

//bills
userRouter.post("/savebills", saveUserCampaignBills);



//transaction
// userRouter.post("/savetr", saveTransaction);
userRouter.get("/gettr", getAllTransactionDetails);

userRouter.post("/transactionpercampaign", getAllTransactionDetailsForUser)




userRouter.post("/savebills", insertBillDetailsIntoCampaign);


// userRouter.post("/image", uploadImage);
// userRouter.post("/fetchimage", fetchImage);


module.exports = userRouter;