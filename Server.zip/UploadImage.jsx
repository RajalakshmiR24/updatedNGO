import React, { useState } from "react";
import axios from "axios";

const UploadImage = () => {
  const [file, setFile] = useState(null);
  const [imageSrcs, setImageSrcs] = useState([]);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64Image = reader.result.split(",")[1];
      await axios.post("http://localhost:5000/general/bannerimage", {
        campId: "7837385f-32e4-42f9-89ce-6f91347532b9",
        email_hash:
          "02ee7bdc4ccf5c94808a0118eb531822f13e7e38e3810ab29ebefb2c2feb8e58",
        base64Image,
      });
      alert("Image uploaded successfully");
    };
    reader.readAsDataURL(file);
  };

  const fetchImages = async () => {
    try {
      const res = await axios.post(
        `http://localhost:5000/api/user/usercampaigndata`,
        {
          campId: "a5ba3d99-bbf8-404c-b681-c796be863ddb",
        }
      );

      console.log(res.data.data.banner);
      if (res.data.code === 200) {
        const banner = res.data.data.banner; // Access the banner string

        // Create the image source
        if (banner) {
          setImageSrcs(banner);
        }
      }
    } catch (error) {
      console.error("Error fetching images:", error);
    }
  };

  return (
    <div>
      <h1>Upload Image</h1>
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} accept="image/*" />
        <button type="submit">Upload</button>
      </form>
      <button onClick={fetchImages}>Download</button>

      <div>
        {/* {imageSrcs.map((src, index) => (
          <img key={index} src={src} alt={`Image ${index}`} />
        ))} */}
        <img src={imageSrcs} alt="Campaign Banner" />
      </div>
    </div>
  );
};

export default UploadImage;
