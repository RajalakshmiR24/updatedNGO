const { campaignSchema } = require("../Model/campaign.js");
const mongoose = require("mongoose");

const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URL, {
            serverSelectionTimeoutMS: 30000,
            socketTimeoutMS: 45000
        });
        mongoose.set('strictPopulate', false); // This will allow populating undefined paths

        console.log("MongoDB Connected");
    } catch (error) {
        console.log("MongoDB not connected", error);
    }
}

module.exports = connectDB;