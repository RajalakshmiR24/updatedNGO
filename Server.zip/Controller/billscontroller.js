const { BillModel } = require("../Model/bills.js");

const saveUserCampaignBills = async (req, res) => {
    const { bills, amount, campId } = req.body;
    try {
        const bill = await BillModel.create({ bills: bills, claiming_amount: amount, campaign_id: campId });
        if (!bill) {
            return res.status(200).json({ code: 400, message: "Bills not uploaded" })
        }
        return res.status(200).json({ code: 200, message: "Bills uploaded successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const saveAdminCampaignBills = async (req, res) => {
    const { bills, amount, campId } = req.body;
    try {
        const bill = await BillModel.create({ bills: bills, claiming_amount: amount, campaign_id: campId });
        if (!bill) {
            return res.status(200).json({ code: 400, message: "Bills not uploaded" })
        }
        bill.status = "APPROVED";
        bill.save();
        return res.status(200).json({ code: 200, message: "Bills uploaded successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

module.exports = {
    saveAdminCampaignBills,
    saveUserCampaignBills
}