const { Admin } = require("../Model/admin.js");
const { BillModel } = require("../Model/bills.js");
const { Campaign } = require("../Model/campaign.js");
const { User } = require("../Model/user.js");

const saveUserCampaignBills = async (req, res) => {
    console.log(req.body);
    
    try {
        const { bills, amount, campId, email } = req.body;
        if (!bills || !amount || !campId || !email) {
            return res.status(400).json({ code: 400, message: "All fields are required." });
        }
        const campaign = await Campaign.findOne({ campaign_id: campId });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "No campaign found to save bills" })
        }
        if (campaign.status === "NOT_APPROVED") {
            return res.status(200).json({ code: 400, message: "Campaign not approved to post bills" })
        }
        const bill = await BillModel.create({ bills, claiming_amount: amount, campaign_id: campId, user_email: email });

        if (!bill) {
            return res.status(200).json({ code: 400, message: "Bills not uploaded" })
        }

        campaign.bills.push(bill._id);
        campaign.save();

        const user = await User.findOne({ email_hash: email });

        if (!user) {
            return res.status(200).json({ code: 400, message: "cannot push user id" })
        }

        bill.campaign.push(campaign._id);
        bill.user.push(user._id);
        await bill.save();

        user.bills.push(bill._id);
        await user.save();
        return res.status(200).json({ code: 200, message: "Bills uploaded successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const saveAdminCampaignBills = async (req, res) => {
    try {
        const { bills, amount, campId, email } = req.body;
        if (!bills || !amount || !campId || !email) {
            return res.status(400).json({ code: 400, message: "All fields are required." });
        }
        const campaign = await Campaign.findOne({ admin_email: email });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "No campaign found to save bills" })
        }
        if (campaign.status === "NOT_APPROVED") {
            return res.status(200).json({ code: 400, message: "Campaign not approved to post bills" })
        }
        const bill = await BillModel.create({ bills, claiming_amount: amount, campaign_id: campId, admin_email: email_hash });
        if (!bill) {
            return res.status(200).json({ code: 400, message: "Bills not uploaded" })
        }
        const admin = await Admin.findOne({ email_hash: email });
        if (!admin) {
            return res.status(200).json({ code: 400, message: "Cannot find admin details" })
        }
        admin.bills.push(bill._id);
        await admin.save();

        campaign.bills.push(bill._id);
        await campaign.save();
        bill.status = "APPROVED";
        await bill.save();
        return res.status(200).json({ code: 200, message: "Bills uploaded successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const findBillById = async (req, res) => {
    try {
        const { id } = req.body;
        if (!id) {
            return res.status(200).json({ code: 400, message: "ID is required" })
        }
        const bill = await BillModel.findById(id).select("-_id")
            .populate({
                path: 'user',
                

            })
            .populate({
                path: 'campaign'
            })
            .exec();
        if (!bill) {
            return res.status(200).json({ code: 400, messag: "No bills found" })
        }
        return res.status(200).json({ code: 200, data: bill })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getRegisteredUsersBillsToVerify = async (req, res) => {
    // const { campId } = req.body;

    try {
        const bills = await BillModel.find({ status: "PENDING" })
            .populate({
                path: 'user',
                select: '-_id fullname email mobile_number'
            })
            .populate({
                path: 'campaign',
                select: '-_id -bills -status -reason_for_cancellation -user_email'
            })
            .exec();

        if (!bills) {
            return res.status(200).json({ code: 400, message: "No bills found" })
        } else {
            return res.status(200).json({ code: 200, count: bills.length, data: bills })
        }

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }
}

const rejectOrVerifyBillsByCampaignId = async (req, res) => {

    const { billID, status, reason } = req.body;
    if (!billID) {
        return res.status(200).json({ code: 400, message: "Bill ID is missing" })
    }
    if (status !== "APPROVED" && status !== "REJECTED") {
        return res.status(200).json({ code: 400, message: "status is wrong" })
    }
    try {
        const billToReject = await BillModel.findById(billID);
        if (!billToReject) {
            return res.status(200).json({ code: 400, message: "Bill not found" })
        }
        if (billToReject && status === "APPROVED") {
            billToReject.status = status;
            await billToReject.save();
            return res.status(200).json({ code: 200, message: "Approved successfully" })
        }
        if (billToReject && status === "REJECTED") {
            billToReject.status = status
            billToReject.reason_for_cancellation = reason;
            await billToReject.save();
            return res.status(200).json({ code: 200, message: "Rejected successfully" })
        }

        return res.status(200).json({ code: 400, message: "status update Unsuccessfull" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })


    }

}

const getTotalApprovedExpense = async (req, res) => {
    try {
        const bills = await BillModel.countDocuments();
        if (bills === 0) {
            return res.status(200).json({ code: 400, message: "No bills found" })
        }
        const expense = await BillModel.find({ status: "APPROVED" }).populate({
            path: 'campaign',
            select: '-_id campaign_title campaign_description'
        })
        if (!expense) {
            return res.status(200).json({ code: 400, message: "No bills found" })
        }
        let totalExpense = 0;
        let totalApprovedBills = 0;
        expense.forEach((item) => {
            totalExpense += Number(item.claiming_amount);
            // console.log(item.claiming_amount);
            totalApprovedBills++
        }
        );
        return res.status(200).json({ code: 200, data: expense, expense: totalExpense, count: totalApprovedBills })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getTotalPendingExpense = async (req, res) => {
    try {
        const bills = await BillModel.countDocuments();
        if (bills === 0) {
            return res.status(200).json({ code: 400, message: "No bills found" })
        }
        const expense = await BillModel.find({ status: "PENDING" }).populate({
            path: 'campaign',
            select: '-_id campaign_title campaign_description'
        })
        if (!expense) {
            return res.status(200).json({ code: 400, message: "No bills found" })
        }
        let totalExpense = 0;
        let totalApprovedBills = 0;
        expense.forEach((item) => {
            totalExpense += Number(item.claiming_amount);
            // console.log(item.claiming_amount);
            totalApprovedBills++
        }
        );
        return res.status(200).json({ code: 200, data: expense, expense: totalExpense, count: totalApprovedBills })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}



const getUserTotalApprovedExpense = async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(200).json({ code: 400, message: "Email is missing" })
        }
        const bills = await BillModel.find({ email_hash: email, status: "APPROVED" });
        if (!bills) {
            return res.status(200).json({ code: 400, message: "No bill data found" })
        }
        if (bills.length === 0) {
            return res.status(200).json({ code: 200, count: 0, message: "No bills found" })
        }
        let totalExpense = 0;
        let totalBills = 0;
        bills.forEach((item, index) => {
            totalExpense += Number(item.claiming_amount);
            totalBills++;
        })
        return res.status(200).json({ code: 500, expense: totalExpense, count: totalBills, data: bills })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}
const getUserTotalPendingExpense = async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(200).json({ code: 400, message: "Email is missing" })
        }
        const bills = await BillModel.find({ email_hash: email, status: "PENDING" });
        if (!bills) {
            return res.status(200).json({ code: 400, message: "No bill data found" })
        }
        if (bills.length === 0) {
            return res.status(200).json({ code: 200, count: 0, message: "No bills found" })
        }
        let totalExpense = 0;
        let totalBills = 0;
        bills.forEach((item, index) => {
            totalExpense += Number(item.claiming_amount);
            totalBills++;
        })
        return res.status(200).json({ code: 500, expense: totalExpense, count: totalBills, data: bills })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const deleteBillsByCampaignId = async (req, res) => {
    try {
        const { campaign_id, email, billId } = req.body;
        if (!campaign_id) {
            return res.status(200).json({ code: 400, message: "Campaign ID is missing" })
        }
        const bills = await BillModel.find({ campaign_id, status: "PENDING" });
        if (!bills) {
            return res.status(200).json({ code: 400, messsage: "No bills found" })
        }
        const deleteBills = await BillModel.deleteMany({ campaign_id, status: "PENDING" });
        if (!deleteBills) {
            return res.status(200).json({ code: 400, message: "Deletion failed" })
        }
        return res.status(200).json({ code: 200, message: "Bills deleted successfully" })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

module.exports = {
    saveAdminCampaignBills,
    saveUserCampaignBills,
    getRegisteredUsersBillsToVerify,
    rejectOrVerifyBillsByCampaignId,
    getTotalPendingExpense,
    getTotalApprovedExpense,
    deleteBillsByCampaignId,
    getUserTotalPendingExpense,
    getUserTotalApprovedExpense,
    findBillById
}