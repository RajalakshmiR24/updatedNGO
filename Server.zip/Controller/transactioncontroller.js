const { default: axios } = require("axios");
const { Transaction } = require("../Model/transaction");
const { User } = require("../Model/user");
const { Campaign } = require("../Model/campaign");

const saveGeneralTransaction = async (req, res) => {
    try {
        const { name, email, amount, mobilenumber } = req.body;
        const transaction = await Transaction.create({
            name: name,
            email: email,
            amount: amount,
            mobilenumber: mobilenumber,
        });
        if (!transaction) {
            return res.status(200).json({ code: 400, message: "Transaction not saved" })
        }
        return res.status(200).json({ code: 200, message: "Transaction saved successfully" });

    } catch (error) {
        console.error("Error saving transaction:", error);
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};

const saveCampaignTransactionData = async (req, res) => {
    try {
        const { name, email, amount, mobilenumber, campId } = req.body;
        if (!campId || !amount) {
            return res.status(200).json({ code: 400, message: "Campaign ID or Amount is required" })
        }
        const transaction = await Transaction.create({
            name: name,
            email: email,
            amount: amount,
            mobilenumber: mobilenumber,
            campaign_id: campId,
        });
        const user = await User.findOne({ mobile_number: mobilenumber });
        console.log(user);

        user.transaction.push(transaction._id);
        await transaction.save();

        transaction.campaign.push(transaction._id);
        await transaction.save();
        const campaign = await Campaign.findOne({ campaign_id: campId });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        campaign.transactions.push(transaction._id);
        await campaign.save();

        if (campaign.estimated_budget < campaign.collected_amount || campaign.estimated_budget === campaign.collected_amount) {
            return res.status(200).json({ code: 400, message: "Requested Funds collected! Thank you." })
        }

        campaign.collected_amount += Number(amount);
        await campaign.save();
        if (!transaction) {
            return res.status(200).json({ code: 400, message: "Transaction not saved" })
        }
        return res.status(200).json({ code: 200, message: "Transaction saved successfully" });

    } catch (error) {
        console.error("Error saving transaction:", error);
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};


const getTotalContributionInAmount = async (req, res) => {

    try {
        const total = await Transaction.aggregate([
            {
                $group: {
                    _id: null,
                    totalAmount: { $sum: { $toDouble: "$amount" } }
                }
            }
        ]);
        if (!total) {
            return res.status(200).json({ code: 400, message: "No transactions found" })
        }
        const transactions = await Transaction.find().select("-_id");
        return res.status(200).json({ code: 200, data: total, users: transactions })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }


}

const getTransactionDocumentCount = async (req, res) => {
    const totalTransactionDocuments = await Transaction.countDocuments();
    if (totalTransactionDocuments === 0) {

        return res.status(200).json({ code: 400, message: "No transactions found" })
    }
    return res.status(200).json({ code: 200, data: totalTransactionDocuments });
}

const getTotalGeneralUsersCount = async (req, res) => {
    try {
        const total = await Transaction.countDocuments();
        if (!total) {
            return res.status(200).json({ code: 400, message: "No transactions found" });
        }
        return res.status(200).json({ code: 200, data: total })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getAllTransactionDetails = async (req, res) => {
    try {
        const totalTransactionDocuments = await Transaction.countDocuments();
        if (!totalTransactionDocuments) {
            return res.status(200).json({ code: 400, message: "No transaction documents found" })
        }
        if (totalTransactionDocuments === 0) {
            return res.status(200).json({ code: 400, message: "No transactions found" })
        }
        const transactionDocuments = await Transaction.find({}, { _id: 0 });
        return res.status(200).json({ code: 200, data: transactionDocuments });
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getAllTransactionDetailsForUser = async (req, res) => {

    try {
        const { email } = req.body;
        if (!email) {
            return res.status(200).json({ code: 400, message: "Email is required" });
        }
        const user = await User.findOne({ email_hash: email })
            .populate(
                {
                    path: 'campaigns',
                    match: { status: { $ne: "NOT_APPROVED" } },
                    select: "-_id  "
                }
            )
            .populate(
                {
                    path: 'transaction',
                    select: '_id '
                }
            )
            .populate(
                {
                    path: "bills"
                }
            )
            .exec();
        if (!user) {
            return res.status(200).json({ code: 400, message: "No transactions found" })
        }
        return res.status(200).json({ code: 200, data: user })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })


    }
}



const getTransactionResponse = async (req, res) => {
    // const { merchantName, platform, billerName, category, merchantNumber, last4Digits, mobileNumber } = req.body;

    console.log('Payment Request Received:', req.body);
    const customerParams = { "Last 4 digits of Credit Card Number": req.body.creditcardnumber, "Registered Mobile Number": req.body.registeredmobilenumber }

    const obj = {
        // "MerchantName": req.body.Name,
        "MerchantName": "Kapil",

        "Platform": req.body.platform,
        "amount": req.body.amount,
        "billerName": process.env.biller_name,
        "category": process.env.category,
        "MerchantNumber": req.body.mobilenumber,
        customerParams
    }
    console.log(obj, "Line 79");

    await axios.post(`http://192.168.1.28:6012/api/pg/billfetch`, obj)
        .then((response) => {
            console.log(response, 'LIne kjsdfksflksdflksjflksajflksjflksjflksjfsalkjfsalkjfsalkj')
            console.log(response.data.code, "line 8555555555555555555555555");
            console.log(response.data, "Liuerfijsdfjsdlfjdlskjfksdjfsjfslkfjslk");
            if (response.data.code === 200) {
                return res.status(200).json({ code: 200, value: response.data.value })
            } else {
                return res.status(200).json({ code: 400, msg: "Try Again" })
            }
        })
        .catch((err) => {
            console.log(err.message, "error messagaeeeeeeeeeeeeeeeeeeeeeeeeee");
        })
}


const getTransResponse = async (req, res) => {
    try {
        console.log(req.body);
        const transaction = await Transaction.create(req.body);
        transaction.pg_response.push(req.body);
        transaction.save();
        // if (transaction)
        console.log("enter    ---------------");
        // return res.status(301).redirect("http://192.168.1.29:3000")

        await axios.post(`http://192.168.1.29:5000/api/general/redirect`, { msg: 'success' })
            .then((response) => {
                console.log(response);
                return res.status(200).json({ msg: "success" })

            })
            .catch((err) => {
                console.log(err);
            })
        // return res.status(200).json({ code: 200, data: transaction })

        // return res.status(200).json({ code: 200 })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getTranseData = async (req, res) => {
    try {
        const { id } = req.body
        if (!id) {
            return res.status(200).json({ code: 400, message: "no id found" })
        }
        const transData = await Transaction.findOne({
            transactionid: id
        })
        return res.status(200).json({ code: 200, data: transData });

    } catch (err) {
        return res.status(200).json({ code: 500, errorMessage: err.message })

    }
}


module.exports = {
    saveCampaignTransactionData,
    saveGeneralTransaction, getAllTransactionDetailsForUser, getTotalGeneralUsersCount, getTotalContributionInAmount,
    getTransResponse, getTransactionResponse,
    getAllTransactionDetails
};