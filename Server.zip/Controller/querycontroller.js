const { Query } = require("../Model/queries");

const saveQueries = async (req, res) => {
    const { name, message, mobilenumber, email } = req.body;
    try {
        const q = await Query.create({ name: name, email: email, mobile_number: mobilenumber, message: message })
        if (!q) {
            return res.status(200).json({ code: 400, message: "Query not saved" })
        }
        return res.status(200).json({ code: 200, message: "Query saved!" })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getAllQueries = async (req, res) => {
    try {
        const query = await Query.find({}).select("-_id");
        if (!query) {
            return res.status(200).json({ code: 400, message: "Query not saved" })

        }
        return res.status(200).json({ code: 200, data: query })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

module.exports = { getAllQueries, saveQueries }