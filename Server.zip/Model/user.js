const mongoose = require("mongoose")

const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const crypto = require("crypto");

const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

const userSchema = new mongoose.Schema({
    fullname: { type: String },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    current_address: { type: String },
    id_proof: {
        type: String,
    },
    password: {
        type: String,
        required: true,
        // validate: {
        //     validator: function (value) {
        //         return passwordRegex.test(value);
        //     },
        //     message: 'Password must be at least 8 characters long, include at least one letter, one digit, and one special character.'
        // }
    },
    mobile_number: {
        type: String,
        unique: true,
        // match: [/^([6-9][0-9]{9})$/, 'Please enter a valid mobile number']
    },
    account_created_date: { type: Date, default: Date.now },
    campaigns: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Campaign' }],
    bills: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Bills' }],
    transaction: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Transaction' }],
    email_hash: { type: String },
    bank_account_details: [{ type: Object }],
    refreshToken: { type: String },
    status: {
        type: String,
        enum: ["ACTIVE", "NOT_ACTIVE", "REJECTED"],
        default: "NOT_ACTIVE"
    },
    role: {
        type: String,
        enum: ['USER', 'ADMIN', 'VOLUNTEER'],
        default: "USER"
    },
}, { timestamps: true });


userSchema.pre("save", async function (next) {
    if (this.isModified("password")) {
        console.log("Original password:", this.password);
        if (!passwordRegex.test(this.password)) {
            return next(new Error('Password must be at least 8 characters long, include at least one letter, one digit, and one special character.'));
        }
        const saltRounds = 12;
        try {
            this.password = await bcrypt.hash(this.password, saltRounds);
        } catch (error) {
            return next(error);
        }
    }
    if (this.isModified("email")) {
        try {
            const hash = crypto.createHash('sha256');
            hash.update(this.email);
            this.email_hash = hash.digest('hex');
            // console.log("Hashed email:", this.email_hash);
        } catch (error) {
            console.log("Error in saving email hash:", error);
            return next(error);
        }
    }
    next();
})


userSchema.methods.isPasswordCorrect = async function (password) {
    return await bcrypt.compare(password, this.password);
}

userSchema.methods.generateAccessToken = function () {
    const payload = {
        email_hash: this.email_hash,
        role: "user",
        date: this.createdAt
    }

    return jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET_KEY, { expiresIn: process.env.ACCESS_TOKEN_EXPIRY })
}

userSchema.methods.generateRefreshToken = function () {
    const payload = {
        email_hash: this.email_hash,
        role: "user",
        date: this.createdAt
    }

    return jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET_KEY, { expiresIn: process.env.REFRESH_TOKEN_EXPIRY })

}

userSchema.statics.countTotalUsers = function () {
    return this.countDocuments({});
}

userSchema.statics.getAllUserCampaignDetails = async function () {
    try {
        const campaignDetails = await User.find({}, ["campaigndetails", "-_id"]);
        return campaignDetails;
    } catch (error) {
        console.log("problem in fetching campaigndetails", error);

    }

}

userSchema.statics.getTotalCampaignCount = async function () {
    const campaigns = await User.find({}, ["campaigndetails", "-_id"]);
    // Assuming campaignDetails is an array, flatten it and count
    const totalCampaignCount = campaigns.reduce((total, item) => {
        // Assuming campaignDetails is an array in each user document
        if (Array.isArray(item.campaigndetails)) {
            return total + item.campaigndetails.length; // Count campaigns in each user document
        }
        return total; // If not an array, just return the total
    }, 0);

    return totalCampaignCount


}

userSchema.methods.getUserCampaignCount = async function () {
    const campaigns = await User.find({}, ["campaigndetails", "-_id"]);
    // Assuming campaignDetails is an array, flatten it and count
    const totalCampaignCount = campaigns.reduce((total, item) => {
        // Assuming campaignDetails is an array in each user document
        if (Array.isArray(item.campaignDetails)) {
            return total + item.campaignDetails.length; // Count campaigns in each user document
        }
        return total; // If not an array, just return the total
    }, 0);
    return totalCampaignCount;

}

const User = mongoose.model("User", userSchema);

module.exports = { User }










