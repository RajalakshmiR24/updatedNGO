const { Admin } = require("../../Model/admin");
const { Campaign } = require("../../Model/campaign");

//admin
const saveAdminCampaignDetails = async (req, res) => {
    const { title, type, description, start_date, end_date, banner, admin_email, address, budget } = req.body;

    try {
        const missingFields = [];

        if (!title) missingFields.push('title');
        if (!type) missingFields.push('type');
        if (!description) missingFields.push('description');
        if (!start_date) missingFields.push('start_date');
        if (!end_date) missingFields.push('end_date');
        if (!banner) missingFields.push('banner');
        if (!admin_email) missingFields.push('admin_email');
        if (!address) missingFields.push('address');
        if (!budget) missingFields.push('budget');

        if (missingFields.length > 0) {
            return res.status(400).json({ code: 400, message: "Bad request", missingFields });
        }
        const campaign = await Campaign.create({
            campaign_title: title,
            campaign_address: address,
            estimated_budget: budget,
            banner: banner,
            campaign_type: type,
            campaign_description: description,
            campaign_start_date: start_date,
            campaign_end_date: end_date,
            admin_email: admin_email,
            status: "APPROVED"
        });
        const admin = await Admin.findOne({ email_hash: admin_email });
        if (!admin) {
            return res.status(200).json({ code: 404, message: "Admin not found" });
        }
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Campaign not saved" })
        }
        admin.campaigns.push(campaign._id);
        await admin.save();

        campaign.admin.push(admin._id);
        await campaign.save();

        return res.status(200).json({ code: 200, message: "Admin Campaign data created successfully" });

    } catch (error) {

        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getAdminCampaignByCampaignId = async (req, res) => {
    try {
        const { campaign_id } = req.body;
        if (!campaign_id) {
            return res.status(200).json({ code: 400, message: "campaign_id is missing" })
        }
        const campaigns = await Campaign.findOne({ campaign_id: campaign_id })
            .populate({
                path: "admin",
                select: "-_id fullname email mobile_number"
            })
            .exec();

        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getAdminCampaignDetailsById = async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(200).json({ code: 400, message: "Email is missing" });
        }
        const adminCampaigns = await Admin.findOne({ admin_email: email });
        if (!adminCampaigns) {
            return res.status(200).json({ code: 400, message: "No admin campaigns found" })
        }
        return res.status(200).json({ code: 200, data: adminCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getAllAdminCampaignDetails = async (req, res) => {
    try {
        const adminCampaigns = await Campaign.find({ admin_email: { $exists: true } }, { _id: 0, admin_email: 0 })
            .populate({
                path: "admin",
                select: "-_id fullname email mobile_number"
            })
            .exec();
        if (!adminCampaigns) {
            return res.status(200).json({ code: 400, message: "No admin campaigns found" })
        }
        return res.status(200).json({ code: 200, count: adminCampaigns.length, data: adminCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}

const updateAdminCampaignDetails = async (req, res) => {
    try {
        const { title, type, description, start_date, end_date, banner, admin_email, address, budget } = req.body;

        const missingFields = [];

        if (!title) missingFields.push('title');
        if (!type) missingFields.push('type');
        if (!description) missingFields.push('description');
        if (!start_date) missingFields.push('start_date');
        if (!end_date) missingFields.push('end_date');
        if (!banner) missingFields.push('banner');
        if (!admin_email) missingFields.push('admin_email');
        if (!address) missingFields.push('address');
        if (!budget) missingFields.push('budget');

        if (missingFields.length > 0) {
            return res.status(400).json({ code: 400, message: "Bad request", missingFields });
        }
        const checkCampaign = await Campaign.findOne({ admin_email: admin_email });
        if (!checkCampaign) {
            return res.status(200).json({ code: 400, message: "No campaign found to update" })
        }
        const campaign = await Campaign.findOneAndUpdate(
            { admin_email: admin_email },
            {
                $set: {
                    campaign_title: title,
                    campaign_address: address,
                    banner: banner,
                    estimated_budget: budget,
                    campaign_type: type,
                    campaign_description: description,
                    campaign_start_date: start_date,
                    campaign_end_date: end_date,
                    status: "APPROVED"
                }
            },
            { new: true }
        );
        // const admin = await Admin.findOne({ email_hash: admin_email });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Update unsuccessfull" })
        }
        return res.status(200).json({ code: 200, message: "Admin Campaign data updated successfully" });
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}


const deleteAdminCampaignDetails = async (req, res) => {
    try {
        const { email, campaign_id } = req.body;
        if (!campaign_id) {
            return res.status(200).josn({ code: 400, message: "Campaign ID is missing" })
        }
        if (!email) return res.status(200).json({ code: 400, message: "Email is missing" })

        const campaign = await Campaign.findOne({ campaign_id: campaign_id });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "No campaign found" })
        }
        const admin = await Admin.findOne({ email_hash: email });
        if (!admin) {
            return res.status(200).json({ code: 400, message: "cannot find admin" })
        }
        const updateAdmin = await Admin.updateOne(
            { email_hash: email },
            { $pull: { campaign: { _id: campaign._id } } }
        );
        if (!updateAdmin) {
            return res.status(200).json({ code: 400, message: "Error updating admin" })
        }

        const deleteCampaign = await Campaign.deleteOne({ campaign_id: campId });
        if (deleteCampaign.deletedCount === 0) {
            return res.status(200).json({ code: 400, message: "Deletion unsuccessfull" })
        }
        const bill = await BillModel.deleteMany({ campaign_id: campId });
        if (bill.deletedCount === 0) {
            return res.status(200).json({ code: 400, message: "Bill deletion unsuccessfull for campaign" })
        }
        return res.status(200).json({ code: 200, message: "Campaign deleted successfully", data: campaign })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getAllCampaingsStatusCount = async (req, res) => {
    try {
        const currentDate = new Date();

        const updateCampaignStatus = await Campaign.updateMany(
            {
                $or: [
                    {
                        "campaign_start_date": { $gte: currentDate }, // For "UPCOMING"
                        "status": "APPROVED"
                    },
                    {
                        "campaign_start_date": { $lte: currentDate }, // For "LIVE"
                        "campaign_end_date": { $gte: currentDate },
                        "status": "APPROVED"
                    },
                    {
                        "campaign_end_date": { $lt: currentDate }, // For "COMPLETED"
                        "status": "APPROVED"
                    }
                ]
            },
            [
                {
                    $set: {
                        status: {
                            $switch: {
                                branches: [
                                    {
                                        // Condition for "UPCOMING"
                                        case: { $gte: ["$campaign_start_date", currentDate] },
                                        then: "UPCOMING"
                                    },
                                    {
                                        // Condition for "LIVE"
                                        case: {
                                            $and: [
                                                { $lte: ["$campaign_start_date", currentDate] },
                                                { $gte: ["$campaign_end_date", currentDate] }
                                            ]
                                        },
                                        then: "LIVE"
                                    },
                                    {
                                        // Condition for "COMPLETED"
                                        case: { $lt: ["$campaign_end_date", currentDate] },
                                        then: "COMPLETED"
                                    }
                                ],
                                default: "$status" // Keep existing status if none match
                            }
                        }
                    }
                }
            ]
        );

        if (!updateCampaignStatus) {
            return res.status(200).json({ code: 400, message: "Updating campaign status failed" })
        }

        const [liveCount, upcomingCount, completedCount, cancelledCount, rejectedCount, notApprovedCount, approvedCount] = await Promise.all([
            Campaign.countDocuments({ status: "LIVE" }),
            Campaign.countDocuments({ status: "UPCOMING" }),
            Campaign.countDocuments({ status: "COMPLETED" }),
            Campaign.countDocuments({ status: "CANCELLED" }),
            Campaign.countDocuments({ status: "REJECTED" }),
            Campaign.countDocuments({ status: "NOT_APPROVED" }),
            Campaign.countDocuments({ status: "APPROVED" })
        ]);

        const countData = {
            liveCount: liveCount,
            upcomingCount: upcomingCount,
            completedCount: completedCount,
            cancelledCount: cancelledCount,
            rejectedCount: rejectedCount,
            notApprovedCount: notApprovedCount,
            approvedCount: approvedCount,
        }

        return res.status(200).json({ code: 200, data: countData });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }

}

const getCampaignCountByDWMY = async (req, res) => {
    try {
        const counts = await Campaign.aggregate([
            {
                $group: {
                    _id: {
                        day: { $dateToString: { format: "%Y-%m-%d", date: "$campaign_start_date" } },
                        week: { $week: "$campaign_start_date" },
                        month: { $dateToString: { format: "%Y-%m", date: "$campaign_start_date" } },
                        year: { $year: "$campaign_start_date" }
                    },
                    count: { $sum: 1 }
                }
            },
            {
                $group: {
                    _id: "$_id.year",
                    dailyCounts: {
                        $push: {
                            day: "$_id.day",
                            count: "$count"
                        }
                    },
                    weeklyCounts: {
                        $push: {
                            week: "$_id.week",
                            count: "$count"
                        }
                    },
                    monthlyCounts: {
                        $push: {
                            month: "$_id.month",
                            count: "$count"
                        }
                    },
                    totalCount: { $sum: "$count" } // Total count for the year
                }
            },
            {
                $sort: { _id: 1 } // Sort by year
            }
        ]);

        const resultData = {
            counts: counts.map(yearData => ({
                year: yearData._id,
                dailyCounts: yearData.dailyCounts,
                weeklyCounts: yearData.weeklyCounts,
                monthlyCounts: yearData.monthlyCounts,
                totalCount: yearData.totalCount
            }))
        };

        return res.status(200).json({ code: 200, data: resultData });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }

}


const getCancelledCampaings = async (req, res) => {
    try {
        const cancel = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },

            {
                $match: {
                    "campaigndetails.status": "CANCELLED"
                },

            },
            {
                $project: {
                    _id: 0,
                    "campaign_title": "$campaigndetails.campaign_title",
                    "campaigndetails": "$campaigndetails.campaigndetails    ",
                    "campaign_description": "$campaigndetails.campaign_description",
                    "start_date": "$campaigndetails.start_date",
                    "end_date": "$campaigndetails.end_date",
                    "campaign_address": "$campaigndetails.campaign_address",
                    "budget": "$campaigndetails.budget",
                    "status": "$campaigndetails.status",
                    "reason_for_cancellation": "$campaigndetails.reason_for_cancellation"
                }
            }


        ]);

        if (cancel.length > 0) {
            return res.status(200).json({ code: 200, data: cancel.length })
        } else {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }

    } catch (error) {
        console.log(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }
}

const getCompletedCampaings = async (req, res) => {
    try {
        const currentDate = new Date();

        await User.updateMany(
            {
                "campaigndetails.end_date": { $lte: currentDate },
                "campaigndetails.status": "APPROVED"
            },
            {
                $set: {
                    "campaigndetails.$[elem].status": "COMPLETED"
                }
            },
            {
                arrayFilters: [{ "elem.status": "APPROVED" }]
            }
        );

        const completedCampaigns = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $match: {
                    "campaigndetails.start_date": { $lte: currentDate },
                    "campaigndetails.status": "COMPLETED"
                }
            },
            {
                $project: {
                    _id: 0,
                    campaign_title: "$campaigndetails.campaign_title",
                    campaign_description: "$campaigndetails.campaign_description",
                    start_date: "$campaigndetails.start_date",
                    end_date: "$campaigndetails.end_date",
                    campaign_address: "$campaigndetails.campaign_address",
                    budget: "$campaigndetails.budget",
                    status: "$campaigndetails.status",
                    reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                }
            }
        ]);

        if (completedCampaigns.length > 0) {
            return res.status(200).json({ code: 200, data: completedCampaigns.length });
        } else {
            return res.status(200).json({ code: 404, message: "No campaigns found" });
        }

    } catch (error) {
        console.error("Error processing campaigns:", error.message);
        return res.status(200).json({ code: 500, message: "Internal Server Error" });
    }


}

const getUpcomingCampaings = async (req, res) => {
    try {
        const currentDate = new Date();

        await User.updateMany(
            {
                "campaigndetails.start_date": { $gte: currentDate },
                "campaigndetails.status": "APPROVED"
            },
            {
                $set: {
                    "campaigndetails.$[elem].status": "UPCOMING"
                }
            },
            {
                arrayFilters: [{ "elem.status": "APPROVED" }]
            }
        );

        const upcoming = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $match: {
                    "campaigndetails.start_date": { $gte: currentDate },
                    "campaigndetails.status": "UPCOMING"
                }
            },
            {
                $project: {
                    _id: 0,
                    campaign_title: "$campaigndetails.campaign_title",
                    campaign_description: "$campaigndetails.campaign_description",
                    start_date: "$campaigndetails.start_date",
                    end_date: "$campaigndetails.end_date",
                    campaign_address: "$campaigndetails.campaign_address",
                    budget: "$campaigndetails.budget",
                    status: "$campaigndetails.status",
                    reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                }
            }
        ]);

        if (upcoming.length > 0) {
            return res.status(200).json({ code: 200, data: upcoming.length });
        } else {
            return res.status(200).json({ code: 404, message: "No campaigns found" }); // Changed to 404
        }

    } catch (error) {
        console.error(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }

}

module.exports = {
    saveAdminCampaignDetails, getAllCampaingsStatusCount,
    getAdminCampaignDetailsById, getAllAdminCampaignDetails,
    updateAdminCampaignDetails, deleteAdminCampaignDetails,
    getAdminCampaignByCampaignId, getCampaignCountByDWMY
}
