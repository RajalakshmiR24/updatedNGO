const dotenv = require("dotenv")
dotenv.config();
const express = require("express")
const connectDB = require("./Database/Db");
const cors = require("cors")
const adminRouter = require("./Routes/adminroutes");
const userRouter = require("./Routes/userroutes");
const { transactionRouter } = require("./Routes/transactionroutes");
const { router } = require("./Routes/routes");
const bodyParser = require("body-parser");
const app = express();

app.use(express.json({ limit: "10mb" }));
app.use(cors());

app.use(express.urlencoded({ extended: true }));


const PORT = process.env.PORT || 5000;

// app.set("view engine", 'ejs');
// app.set("views", join(__dirname, 'views'))

app.use("/api/admin", adminRouter);
app.use("/api/user", userRouter);
app.use("/api/transaction", transactionRouter)
app.use("/api/general", router);

// app.post('/logout', );

app.get("/some", (req, res) => {
    console.log("line 30")
    return res.status(200).json({ msg: "fjdsjfsflksfsafjsaklfsak" })
})


connectDB().then(() => {

    const server = app.listen(PORT, () => {
        console.log(`Listening on port ${PORT}`);
    })

    server.on("request", (req, res) => {
        console.log(`${req.method}-----${req.url}`)
    })

}).catch((err) => {
    console.log(err)
})
