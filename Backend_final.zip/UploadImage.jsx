import React, { useState } from "react";
import axios from "axios";

const UploadImage = () => {
  const [file, setFile] = useState(null);
  const [imageSrcs, setImageSrcs] = useState([]);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64Image = reader.result.split(",")[1];
      await axios.post("http://localhost:5000/general/bannerimage", {
        campId: "7837385f-32e4-42f9-89ce-6f91347532b9",
        email_hash:
          "02ee7bdc4ccf5c94808a0118eb531822f13e7e38e3810ab29ebefb2c2feb8e58",
        base64Image,
      });
      alert("Image uploaded successfully");
    };
    reader.readAsDataURL(file);
  };

  /*
  import axios from 'axios';

// Create an Axios instance
const axiosInstance = axios.create({
  baseURL: 'https://your-api-url.com', // replace with your API URL
});

// Add a request interceptor
axiosInstance.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token'); // or however you store your token
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

// Now you can use axiosInstance for your requests
axiosInstance.get('/endpoint')
  .then(response => {
    console.log(response.data);
  })
  .catch(error => {
    console.error(error);
  });

  */

  /*
  // Example using fetch
fetch('/api/logout', {
    method: 'POST',
    headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
    }
}).then(response => {
    if (response.ok) {
        // Remove token from client storage
        localStorage.removeItem('token');
        // Redirect to login page or show a logout success message
        window.location.href = '/login';
    }
});

  */

  const fetchImages = async () => {
    try {
      const res = await axios.post(
        `http://localhost:5000/api/user/usercampaigndata`,
        {
          campId: "a5ba3d99-bbf8-404c-b681-c796be863ddb",
        }
      );

      console.log(res.data.data.banner);
      if (res.data.code === 200) {
        const banner = res.data.data.banner; // Access the banner string

        // Create the image source
        if (banner) {
          setImageSrcs(banner);
        }
      }
    } catch (error) {
      console.error("Error fetching images:", error);
    }
  };

  return (
    <div>
      <h1>Upload Image</h1>
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} accept="image/*" />
        <button type="submit">Upload</button>
      </form>
      <button onClick={fetchImages}>Download</button>

      <div>
        {/* {imageSrcs.map((src, index) => (
          <img key={index} src={src} alt={`Image ${index}`} />
        ))} */}
        <img src={imageSrcs} alt="Campaign Banner" />
      </div>
    </div>
  );
};

export default UploadImage;
