import { createBrowserRouter, Navigate } from "react-router-dom";

// Admin Components
import AdminLayout from "../Components/Admin/Layout/AdminLayout";
import AdminDashboard from "../Components/Admin/Pages/1.Dashboard/Dashboard";
import RegisteredUserList from "../Components/Admin/Pages/3.UserManagement/2.Registered/List/RegisteredUserList";
import GeneralUserList from "../Components/Admin/Pages/3.UserManagement/3.General/List/GeneralUserList";
import Request from "../Components/Admin/Pages/4.Request/Request";
import Queries from "../Components/Admin/Pages/5.Queries/Queries";
import AdminSignIn from "../Components/Admin/auth/AdminSignIn";
import Campaigns from "../Components/Admin/Pages/2.Campaigns/CampaignList/Campaigns";

// Landing
import NotFound from "../Components/Admin/Common/NotFound/notFound";

const adminRoutes = [
  { index: true, element: <AdminDashboard /> },
  { path: "campaigns", element: <Campaigns /> },
  { path: "registered-users", element: <RegisteredUserList /> },
  { path: "general-users", element: <GeneralUserList /> },
  { path: "requests", element: <Request /> },
  { path: "queries", element: <Queries /> },
];

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/admin/signin" />,
  },
  {
    path: "/admin",
    element: <AdminLayout />,
    children: adminRoutes,
  },

  {
    path: "/admin/signin",
    element: <AdminSignIn />,
  },

  {
    path: "*",
    element: <NotFound />,
  },
]);
