// RequestContext.js
import React, { createContext, useContext, useState } from "react";

// Create the context
const RequestContext = createContext();

// Custom hook to access context easily
export const useRequestContext = () => useContext(RequestContext);

// RequestProvider component to wrap the application and provide state management
export const RequestProvider = ({ children }) => {
  const [users, setUsers] = useState([]);
  const [camp, setCamps] = useState([]);
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [activeTab, setActiveTab] = useState("users");
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedBill, setSelectedBill] = useState(null);
  const [userCampaignDetailModalOpen, setUserCampaignDetailModalOpen] = useState(false);
  const [userDetailModalOpen, setUserDetailModalOpen] = useState(false);
  const [billDetailModalOpen, setBillDetailModalOpen] = useState(false);

  // Functions to open/close modals
  const openUserDetailModal = (user) => {
    setSelectedUser(user);
    setUserDetailModalOpen(true);
  };

  const closeUserDetailModal = () => {
    setUserDetailModalOpen(false);
    setSelectedUser(null);
  };

  const openCampaignDetailModal = (campaign) => {
    setSelectedCampaign(campaign);
    setUserCampaignDetailModalOpen(true);
  };

  const closeCampaignDetailModal = () => {
    setUserCampaignDetailModalOpen(false);
    setSelectedCampaign(null);
  };

  const openBillDetailModal = (bill) => {
    setSelectedBill(bill);
    setBillDetailModalOpen(true);
  };

  const closeBillDetailModal = () => {
    setBillDetailModalOpen(false);
    setSelectedBill(null);
  };

  // Handle user approval
  const handleUserApproval = (status) => {
    setUsers((prevUsers) =>
      prevUsers.map((user) =>
        user.email_hash === selectedUser?.email_hash
          ? { ...user, status: status === "ACTIVE" ? "ACTIVE" : "REJECTED" }
          : user
      )
    );
  };

  // Handle campaign approval
  const handleCampaignApproval = (status) => {
    setCamps((prevCamp) =>
      prevCamp.map((campaign) =>
        campaign.campaign_id === selectedCampaign?.campaign_id
          ? { ...campaign, status: status === "APPROVED" ? "APPROVED" : "REJECTED" }
          : campaign
      )
    );
  };

  // Handle bill approval
  const handleBillApproval = (status) => {
    setBills((prevBills) =>
      prevBills.map((bill) =>
        bill.id === selectedBill?.id
          ? { ...bill, status: status === "APPROVED" ? "APPROVED" : "REJECTED" }
          : bill
      )
    );
  };

  return (
    <RequestContext.Provider
      value={{
        users,
        setUsers,
        camp,
        setCamps,
        bills,
        setBills,
        loading,
        setLoading,
        error,
        setError,
        successMessage,
        setSuccessMessage,
        activeTab,
        setActiveTab,
        selectedCampaign,
        setSelectedCampaign,
        selectedUser,
        setSelectedUser,
        selectedBill,
        setSelectedBill,
        userCampaignDetailModalOpen,
        userDetailModalOpen,
        billDetailModalOpen,
        openUserDetailModal,
        closeUserDetailModal,
        openCampaignDetailModal,
        closeCampaignDetailModal,
        openBillDetailModal,
        closeBillDetailModal,
        handleUserApproval,
        handleCampaignApproval,
        handleBillApproval,
      }}
    >
      {children}
    </RequestContext.Provider>
  );
};
