import React from 'react';
import { RouterProvider } from 'react-router-dom';
import { router } from './Routes/routes';
import { CampaignProvider } from './Context/CampaignContext';
import { RequestsProvider } from './Context/RequestsContext'; 

const App = () => {
  return (
    <CampaignProvider>
      <RequestsProvider>
        <RouterProvider router={router} />
      </RequestsProvider>
    </CampaignProvider>
  );
}

export default App;
