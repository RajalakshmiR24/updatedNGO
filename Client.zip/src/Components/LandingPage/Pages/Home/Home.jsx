export const Home =()=>{
    return(
        <>
            <h1>
                home
            </h1>
        </>
    )
}