import React, { useState } from 'react';
import axiosInstance from '../../../Utils/axiosInstance';
import { useNavigate } from 'react-router-dom';
import AuthInput from './Form/AuthInput';
import AuthForm from './Form/AuthForm';
import './SignIn.css';

const AdminSignUp = () => {
    const [info, setInfo] = useState({});
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setInfo((prevState) => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        axiosInstance.post('/admin/register', info)
            .then((res) => {
                if (res.data.code === 200) {
                    setInfo({});
                    navigate("/admin/signin");
                }
            })
            .catch((error) => {
                console.log("error", error);
            });
    };

    return (
        <AuthForm title="Admin Register" onSubmit={handleSubmit}>
            <AuthInput label="Email" name="email" type="text" value={info.email || ""} onChange={handleChange} />
            <AuthInput label="Mobile Number" name="mobilenumber" type="text" value={info.mobilenumber || ""} onChange={handleChange} />
            <AuthInput label="Password" name="password" type="password" value={info.password || ""} onChange={handleChange} />
            <p>
                Already have an account? <span onClick={() => navigate("/admin/signin")} style={{ cursor: 'pointer', color: 'blue' }}>Sign In</span>
            </p>
        </AuthForm>
    );
};

export default AdminSignUp;
