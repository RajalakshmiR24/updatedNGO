import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../Utils/axiosInstance";

const Requests = () => {
  const [users, setUsers] = useState([]);
  const [fundRequests, setFundRequests] = useState([]);
  const [camp, setCamp] = useState([]);
  const [bills, setBills] = useState([]); // Adding bills state
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("users");

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Updated URLs based on the new endpoints
        const userResponse = await axiosInstance.get(
          "/admin/verifyuserdetails"
        );
        const fundResponse = await axiosInstance.get("/admin/fundrequest");
        const campResponse = await axiosInstance.get(
          "/admin/campaignstatustoverify"
        );
        const billsResponse = await axiosInstance.get("/admin/getbills"); // Fetching bills

        if (userResponse.data?.data) setUsers(userResponse.data.data);
        if (fundResponse.data?.data) setFundRequests(fundResponse.data.data);
        if (campResponse.data?.data) setCamp(campResponse.data.data);
        if (billsResponse.data?.data) setBills(billsResponse.data.data); // Setting bills data
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Update user status
  const updateUserStatus = async (emailHash, status) => {
    try {
      await axiosInstance.post(`/admin/updateUser/${emailHash}`, { status });
      fetchData(); // Refresh data after update
    } catch (err) {
      setError(err.message);
    }
  };

  // Handling user actions
  const handleUserAction = (emailHash, action) => {
    if (action === "verify") updateUserStatus(emailHash, "verified");
    if (action === "reject") updateUserStatus(emailHash, "rejected");
  };

  // Verify/Reject Campaign
  const verifyCamp = async (emailHash) => {
    await updateCampaignStatus(emailHash, "verified");
  };

  const rejectCamp = async (emailHash) => {
    await updateCampaignStatus(emailHash, "rejected");
  };

  const updateCampaignStatus = async (emailHash, status) => {
    try {
      await axiosInstance.post(`/admin/updateCampaign/${emailHash}`, {
        status,
      });
      fetchData();
    } catch (err) {
      setError(err.message);
    }
  };

  // Verify/Reject Fund Requests
  const verifyFundRequest = async (fundId) => {
    await updateFundRequestStatus(fundId, "verified");
  };

  const rejectFundRequest = async (fundId) => {
    await updateFundRequestStatus(fundId, "rejected");
  };

  const updateFundRequestStatus = async (fundId, status) => {
    try {
      await axiosInstance.post(`/admin/updateFundRequest/${fundId}`, {
        status,
      });
      fetchData();
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h2>Management Dashboard</h2>
      <div>
        <button onClick={() => setActiveTab("users")}>Users</button>
        <button onClick={() => setActiveTab("funds")}>Funds</button>
        <button onClick={() => setActiveTab("camp")}>Campaigns</button>
        <button onClick={() => setActiveTab("bills")}>Bills</button>{" "}
        {/* Added Bills tab */}
      </div>

      {activeTab === "users" && (
        <>
          <h2>Users to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {users.length > 0 ? (
                users.map((user, i) => (
                  <tr key={user.email_hash}>
                    <td>{i + 1}</td>
                    <td>{user.fullname}</td>
                    <td>{user.email}</td>
                    <td>{user.status}</td>
                    <td>
                      <button
                        onClick={() =>
                          handleUserAction(user.email_hash, "verify")
                        }
                      >
                        Verify
                      </button>
                      <button
                        onClick={() =>
                          handleUserAction(user.email_hash, "reject")
                        }
                      >
                        Reject
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4">No user data found</td>
                </tr>
              )}
            </tbody>
          </table>
        </>
      )}

      {activeTab === "camp" && (
        <>
          <h2>Campaigns to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Campaign Name</th>
                <th>Campaign Type</th>
                <th>Campaign Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {camp.length > 0 ? (
                camp.map((campaign, i) => (
                  <tr key={campaign.email_hash}>
                    <td>{i + 1}</td>
                    <td>{campaign.campaign_title}</td>
                    <td>{campaign.campaign_type}</td>
                    <td>{campaign.status}</td>
                    <td>
                      <button onClick={() => verifyCamp(campaign.email_hash)}>
                        Verify
                      </button>
                      <button onClick={() => rejectCamp(campaign.email_hash)}>
                        Reject
                      </button>
                      <button onClick={() => viewCamp(campaign.email_hash)}>
                        View
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4">No campaign data found</td>
                </tr>
              )}
            </tbody>
          </table>
        </>
      )}

      {activeTab === "funds" && (
        <>
          <h2>Fund Requests to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Campaign Name</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {fundRequests.length > 0 ? (
                fundRequests.map((fund, i) => (
                  <tr key={fund.fund_id}>
                    <td>{i + 1}</td>
                    <td>{fund.title}</td>
                    <td>{fund.description}</td>
                    <td>{fund.amount}</td>
                    <td>
                      <button onClick={() => verifyFundRequest(fund.fund_id)}>
                        Verify
                      </button>
                      <button onClick={() => rejectFundRequest(fund.fund_id)}>
                        Reject
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4">No fund requests available</td>
                </tr>
              )}
            </tbody>
          </table>
        </>
      )}

      {activeTab === "bills" && (
        <>
          <h2>Bills to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>User</th>
                <th>Bill Amount</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {bills.length > 0 ? (
                bills.map((bill, i) => (
                  <tr key={bill.user_id}>
                    <td>{i + 1}</td>
                    <td>{bill.username}</td>
                    <td>{bill.amount}</td>
                    <td>{bill.status}</td>
                    <td>
                      <button onClick={() => verifyBill(bill.user_id)}>
                        Verify
                      </button>
                      <button onClick={() => rejectBill(bill.user_id)}>
                        Reject
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4">No bills available</td>
                </tr>
              )}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
};

export default Requests;
