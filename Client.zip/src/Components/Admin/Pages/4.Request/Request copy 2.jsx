import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../Utils/axiosInstance";

const Requests = () => {
  const [users, setUsers] = useState([]);
  const [camp, setCamps] = useState([]);
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [activeTab, setActiveTab] = useState("users");
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedBill, setSelectedBill] = useState(null);
  const [userCampaignDetailModalOpen, setUserCampaignDetailModalOpen] = useState(false);
  const [userDetailModalOpen, setUserDetailModalOpen] = useState(false);
  const [billDetailModalOpen, setBillDetailModalOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const userResponse = await axiosInstance.get("/admin/verifyuserdetails");
        const campResponse = await axiosInstance.get("/admin/campaignstatustoverify");
        const billsResponse = await axiosInstance.get("/admin/verifybills");

        if (userResponse.data?.data) setUsers(userResponse.data.data);
        if (campResponse.data?.data) setCamps(campResponse.data.data);
        if (billsResponse.data?.data) setBills(billsResponse.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const fetchUserDetails = async (email_hash) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/finduserbyemail", {
        hash: email_hash,
      });
      setSelectedUser(response.data.data);
      setUserDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching user details:", error);
      setError("Failed to fetch user details");
    } finally {
      setLoading(false);
    }
  };

  const fetchUserCampDetails = async (campaignId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/campaignperuser", {
        campaign_id: campaignId,
      });
      setSelectedCampaign(response.data.data[0]);
      setUserCampaignDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching campaign details:", error);
      setError("Failed to fetch campaign details");
    } finally {
      setLoading(false);
    }
  };

  const fetchBillDetails = async (billId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/findbillbyid", {
        id: billId, // Change `_id` to `id`
      });
      setSelectedBill(response.data.data);
      setBillDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching bill details:", error);
      setError("Failed to fetch bill details");
    } finally {
      setLoading(false);
    }
  };


  const closeUserDetailModal = () => {
    setUserDetailModalOpen(false);
    setSelectedUser(null);
  };

  const closeCampaignDetailModal = () => {
    setUserCampaignDetailModalOpen(false);
    setSelectedCampaign(null);
  };

  const closeBillDetailModal = () => {
    setBillDetailModalOpen(false);
    setSelectedBill(null);
  };

  console.log(users.email_hash, "-------------------");

  const handleUserApproval = async (status) => {
    if (!selectedUser) return;

    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/rejectuser", {
        email: 'b822f99a7142e909d1b0df5b7f73270e083a1900bc11003d8e4dfcf5f53f7f5e',
        // email: users.email_hash,
        status,
      });

      if (response.data.code === 200) {
        setSuccessMessage(response.data.message);
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user.email_hash === selectedUser.email_hash
              ? { ...user, status: status === "ACTIVE" ? "ACTIVE" : "REJECTED" }
              : user
          )
        );
      } else {
        setError(response.data.message || "Failed to update user status");
      }
    } catch (error) {
      console.error("Error approving/rejecting user:", error);
      setError("Failed to update user status");
    } finally {
      setLoading(false);
      closeUserDetailModal();
    }
  };

  const handleCampaignApproval = async (status) => {
    if (!selectedCampaign) return;
    campaign_id = '5e73f062-7885-4d5a-bd4d-c6898c059707';
    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/rejectcampreq", {
        campaign_id: selectedCampaign.campaign_id, // Corrected line
        status,
      });

      if (response.data.code === 200) {
        setSuccessMessage(response.data.message);
        setCamps((prevCamp) =>
          prevCamp.map((campaign) =>
            campaign.campaign_id === selectedCampaign.campaign_id
              ? { ...campaign, status: status === "APPROVED" ? "APPROVED" : "REJECTED" }
              : campaign
          )
        );
      } else {
        setError("Failed to update campaign status");
      }
    } catch (error) {
      console.error("Error approving/rejecting campaign:", error);
      setError("Failed to update campaign status");
    } finally {
      setLoading(false);
      closeCampaignDetailModal();
    }
  };


  const handleBillApproval = async (status) => {
    if (!selectedBill) return;

    setLoading(true);
    try {
      const response = await axiosInstance.put("/admin/verifyrejectbills", {
        // billID: selectedBill.id,
        billID: '66fbf1dbd610bb25a65a38d7',
        status,
      });
      if (response.data.code === 200) {
        setSuccessMessage(response.data.message);
        setBills((prevBills) =>
          prevBills.map((bill) =>
            bill.id === selectedBill.id
              ? { ...bill, status: status === "APPROVED" ? "APPROVED" : "REJECTED" }
              : bill
          )
        );
      } else {
        setError("Failed to update bill status");
      }
    } catch (error) {
      console.error("Error approving/rejecting bill:", error);
      setError("Failed to update bill status");
    } finally {
      setLoading(false);
      closeBillDetailModal();
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h2>Management Dashboard</h2>
      {successMessage && <div className="success-message">{successMessage}</div>}
      <div>
        <button onClick={() => setActiveTab("users")}>Users</button>
        <button onClick={() => setActiveTab("camp")}>Campaigns</button>
        <button onClick={() => setActiveTab("bills")}>Bills</button>
      </div>

      {activeTab === "users" && (
        <>
          <h2>Users to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile number</th>
                <th>Created date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {users.length > 0 ? (
                users.map((user, i) => (
                  <tr key={user.email_hash}>
                    <td>{i + 1}</td>
                    <td>{user.fullname}</td>
                    <td>{user.email}</td>
                    <td>{user.mobile_number}</td>
                    <td>{new Date(user.account_created_date).toLocaleDateString()}</td>
                    <td>{user.status}</td>
                    <td>
                      <button onClick={() => fetchUserDetails(user.email_hash)}>
                        View
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7">No user data found</td>
                </tr>
              )}
            </tbody>
          </table>
        </>
      )}

      {activeTab === "camp" && (
        <>
          <h2>Campaigns to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Campaign Name</th>
                <th>Campaign Type</th>
                <th>Campaign Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {camp.length > 0 ? (
                camp.map((campaign, i) => (
                  <tr key={campaign._id}>
                    <td>{i + 1}</td>
                    <td>{campaign.campaign_title}</td>
                    <td>{campaign.campaign_type}</td>
                    <td>{campaign.status}</td>
                    <td>
                      <button onClick={() => fetchUserCampDetails(campaign.campaign_id)}>
                        View
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5">No campaign data found</td>
                </tr>
              )}
            </tbody>
          </table>
        </>
      )}

      {activeTab === "bills" && (
        <>
          <h2>Bills to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>User</th>
                <th>Email</th>
                <th>Campaign Name</th>
                <th>Bill Amount</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {bills.length > 0 ? (
                bills.map((bill, i) => (
                  <tr key={bill._id}>
                    <td>{i + 1}</td>
                    <td>{bill.user ? bill.user[0]?.fullname : "Unknown User"}</td>
                    <td>{bill.user ? bill.user[0]?.email : "Unknown email"}</td>
                    <td>{bill.campaign ? bill.campaign[0]?.campaign_title : "Unknown campaign"}</td>
                    <td>{bill.claiming_amount}</td>
                    <td>{bill.status}</td>
                    <td>
                      <button onClick={() => fetchBillDetails(bill._id)}>View</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7">No bills available</td>
                </tr>
              )}
            </tbody>
          </table>
        </>
      )}

      {/* User Detail Modal */}
      {userDetailModalOpen && selectedUser && (
        <div className="modal">
          <div className="modal-content">
            <h2>User Details</h2>
            <div
              className="modal-background"
              style={{
                backgroundImage: `url(${selectedUser.id_proof})`,
              }}
            />
            <h3>User Information</h3>
            <p><strong>Full Name:</strong> {selectedUser.fullname}</p>
            <p><strong>Email:</strong> {selectedUser.email}</p>
            <p><strong>Current Address:</strong> {selectedUser.current_address}</p>
            <p><strong>Mobile Number:</strong> {selectedUser.mobile_number}</p>
            <p><strong>Account Created:</strong> {new Date(selectedUser.account_created_date).toLocaleDateString()}</p>
            <p><strong>Status:</strong> {selectedUser.status}</p>
            <h4>Bank Account Details</h4>
            {selectedUser.bank_account_details.map((account, index) => (
              <div key={index}>
                <p><strong>Account Number:</strong> {account.account_number}</p>
                <p><strong>IFSC Code:</strong> {account.IFSC_Code}</p>
              </div>
            ))}
            <button onClick={() => handleUserApproval("ACTIVE")}>Verify</button>
            <button onClick={() => handleUserApproval("REJECTED")}>Reject</button>
            <button onClick={closeUserDetailModal}>Close</button>
          </div>
        </div>
      )}

      {/* Campaign Detail Modal */}
      {userCampaignDetailModalOpen && selectedCampaign && (
        <div className="modal">
          <div className="modal-content">
            <h2>Campaign Details</h2>
            <div
              className="modal-background"
              style={{
                backgroundImage: `url(${selectedCampaign.banner})`,
              }}
            />
            <p><strong>Title:</strong> {selectedCampaign.campaign_title}</p>
            <p><strong>Type:</strong> {selectedCampaign.campaign_type}</p>
            <p><strong>Description:</strong> {selectedCampaign.campaign_description}</p>
            <p><strong>Start Date:</strong> {new Date(selectedCampaign.campaign_start_date).toLocaleDateString()}</p>
            <p><strong>End Date:</strong> {new Date(selectedCampaign.campaign_end_date).toLocaleDateString()}</p>
            <p><strong>Address:</strong> {selectedCampaign.campaign_address}</p>
            <p><strong>Budget:</strong> {selectedCampaign.estimated_budget}</p>
            <p><strong>Collected Amount:</strong> {selectedCampaign.collected_amount}</p>
            <button onClick={() => handleCampaignApproval("APPROVED")}>Verify</button>
            <button onClick={() => handleCampaignApproval("REJECTED")}>Reject</button>
            <button onClick={closeCampaignDetailModal}>Close</button>
          </div>
        </div>
      )}

      {/* Bill Detail Modal */}
      {billDetailModalOpen && selectedBill && (
        <div className="modal">
          <div className="modal-content">
            <h2>Bill Details</h2>
            <p><strong>User:</strong> {selectedBill.user[0]?.fullname || "Unknown User"}</p>
            <p><strong>Email:</strong> {selectedBill.user[0]?.email || "Unknown email"}</p>
            <p><strong>Campaign:</strong> {selectedBill.campaign[0]?.campaign_title || "Unknown campaign"}</p>
            <p><strong>Claiming Amount:</strong> {selectedBill.claiming_amount}</p>
            <p><strong>Status:</strong> {selectedBill.status}</p>
            <button onClick={() => handleBillApproval("APPROVED")}>Verify</button>
            <button onClick={() => handleBillApproval("REJECTED")}>Reject</button>
            <button onClick={closeBillDetailModal}>Close</button>
          </div>
        </div>
      )}

    </div>
  );
};

export default Requests;
