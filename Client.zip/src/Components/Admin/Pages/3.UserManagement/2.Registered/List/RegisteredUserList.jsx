import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../../../Utils/axiosInstance";
import CampaignDetails from "../CampaignDetails/CampaignDetails";
import UserDetails from "../UserDetails/UserDetails"; // Import UserDetails component
import "./RegisteredUserList.css";

const RegisteredUserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCampaigns, setSelectedCampaigns] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [showCampaignDetails, setShowCampaignDetails] = useState(false);
  const [showUserDetails, setShowUserDetails] = useState(false); // State to control UserDetails modal
  const [noCampaignMessage, setNoCampaignMessage] = useState("");
  const [noUserMessage, setNoUserMessage] = useState(""); // State for no user message

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get("/admin/allusers");
        setUsers(response.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleViewCampDetails = async (email) => {
    setNoCampaignMessage("");
    try {
      const response = await axiosInstance.post("/admin/campaignperuser", { email });
      const campaignsData = response.data.data;

      if (campaignsData && campaignsData.length > 0) {
        setSelectedCampaigns(campaignsData);
        setShowCampaignDetails(true);
      } else {
        setNoCampaignMessage("No campaigns found for this user.");
        setShowCampaignDetails(true);
      }
    } catch (err) {
      console.error("Error fetching campaigns:", err);
      setNoCampaignMessage("Failed to fetch campaigns: " + err.message);
      setShowCampaignDetails(true);
    }
  };

  const handleViewUserDetails = async (email) => {
    setNoUserMessage(""); // Resetting the message
    try {
      const response = await axiosInstance.get("/admin/allusers", { email }); // Assume a correct endpoint
      const userData = response.data.data;

      if (userData && userData.length > 0) {
        setSelectedUsers(userData);
        setShowUserDetails(true); // Show UserDetails modal
      } else {
        setNoUserMessage("No users found for this user.");
        setShowUserDetails(true);
      }
    } catch (err) {
      console.error("Error fetching users:", err);
      setNoUserMessage("Failed to fetch users: " + err.message);
      setShowUserDetails(true);
    }
  };

  const closeDetails = () => {
    setShowCampaignDetails(false);
    setShowUserDetails(false); // Close UserDetails modal
    setSelectedCampaigns([]);
    setSelectedUsers([]); // Reset selected users
    setNoCampaignMessage("");
    setNoUserMessage(""); // Reset no user message
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      {showCampaignDetails ? (
        <CampaignDetails
          campaigns={selectedCampaigns}
          noCampaignMessage={noCampaignMessage}
          onClose={closeDetails}
        />
      ) : showUserDetails ? ( // Check if UserDetails modal should be shown
        <UserDetails
          users={selectedUsers}
          noUserMessage={noUserMessage}
          onClose={closeDetails}
        />
      ) : (
        <div>
          <h2>Registered User List</h2>
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Mobile Number</th>
                <th>No. of Camp</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user, index) => (
                <tr key={user._id}>
                  <td>{index + 1}</td>
                  <td>
                    <button onClick={() => handleViewUserDetails(user.email_hash)}>
                      {user.fullname}
                    </button>
                  </td>
                  <td>{user.email}</td>
                  <td>{user.mobile_number}</td>
                  <td>
                    <button onClick={() => handleViewCampDetails(user.email_hash)}>
                      {user.campaigns ? user.campaigns.length : 0}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RegisteredUserList;
