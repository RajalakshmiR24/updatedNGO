import React, { useState } from 'react';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import './CampaignDetails.css';

const CampaignDetails = ({ campaigns = [], noCampaignMessage, onClose }) => {
  const [bannerImage, setBannerImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleCardClick = async (campaign) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post('/admin/fetchbannerimage', {
        campId: campaign.id,
        hash: campaign.email_hash,
      });
      if (response.data && response.data.data) {
        setBannerImage(`data:${response.data.data[0].contentType};base64,${response.data.data[0].data}`);
      }
    } catch (error) {
      console.error('Error fetching banner image:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusClass = (status) => {
    switch (status.toLowerCase()) {
      case 'live':
        return 'status-red'; // CSS class for live status
      case 'upcoming':
        return 'status-yellow'; // CSS class for upcoming status
      case 'completed':
        return 'status-green'; // CSS class for completed status
      default:
        return ''; // No class for undefined statuses
    }
  };

  return (
    <div className="campaign-details-modal">
      <button className="close-button" onClick={onClose}>X</button>
      <h3>Campaigns for User</h3>
      <div className="campaign-list">
        {noCampaignMessage ? (
          <p className="no-campaign-message">{noCampaignMessage}</p>
        ) : (
          campaigns.length > 0 ? (
            campaigns.map(campaign => (
              <div className="campaign-card" key={campaign.id} onClick={() => handleCardClick(campaign)}>
                {campaign.campaign_image && (
                  <img src={campaign.campaign_image} alt={campaign.campaign_title} className="campaign-image" />
                )}
                <div className="campaign-info">
                  <h4>{campaign.campaign_title}</h4>
                  <p>{campaign.campaign_description}</p>
                  <p><strong>Start Date:</strong> {new Date(campaign.start_date).toLocaleDateString()}</p>
                  <p><strong>End Date:</strong> {new Date(campaign.end_date).toLocaleDateString()}</p>
                  <p><strong>Budget:</strong> {campaign.budget ? campaign.budget : 'Not specified'}</p>
                  <p><strong>Address:</strong> {campaign.campaign_address}</p>
                  <p className={`status ${getStatusClass(campaign.status)}`}>
                    <strong>Status:</strong> {campaign.status}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p>No campaigns available.</p>
          )
        )}
      </div>

      {loading && <p>Loading image...</p>} {/* Loading indicator */}

      {bannerImage && ( // Display the fetched banner image
        <div className="banner-image-modal">
          <button className="close-image-button" onClick={() => setBannerImage(null)}>X</button>
          <img src={bannerImage} alt="Banner" className="full-banner-image" />
        </div>
      )}
    </div>
  );
};

export default CampaignDetails;
