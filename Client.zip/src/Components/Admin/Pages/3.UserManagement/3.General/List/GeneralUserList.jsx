import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import './GeneralUserList.css';

const GeneralUserList = () => {
  const [users, setUsers] = useState([]); 
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get('/admin/alltransactions');
        
        if (response.data && Array.isArray(response.data.data)) {
          setUsers(response.data.data);
        } else {
          throw new Error('Invalid response structure');
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleAction = (userId) => {
    const user = users.find((u) => u._id === userId);
    setSelectedUser(user);
  };

  const closeModal = () => {
    setSelectedUser(null);
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h2>General User List</h2>
      <table>
        <thead>
          <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>No. of Campaigns</th>
            <th>Total Amount</th>
            <th>Action</th> 
          </tr>
        </thead>
        <tbody>
          {Array.isArray(users) && users.length > 0 ? (
            users.map((user, index) => (
              <tr key={index}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.mobilenumber}</td>
                <td>{user.campaigndetails ? user.campaigndetails.length : 0}</td>
                <td>{user.amount}</td>
                <td>
                  <button onClick={() => handleAction(user._id)}>View</button> 
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6">No users found</td> 
            </tr>
          )}
        </tbody>
      </table>
      <UserModal user={selectedUser} onClose={closeModal} />
    </div>
  );
};

const UserModal = ({ user, onClose }) => {
  if (!user) return null; 

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>User Details</h2>
        <table>
          <tbody>
            <tr>
              <td><strong>Total Amount:</strong></td>
              <td>{user.amount}</td>
            </tr>
            <tr>
              <td><strong>No. of Campaigns:</strong></td>
              <td>{user.campaigndetails.length}</td>
            </tr>
            <tr>
              <td><strong>Transaction ID:</strong></td>
              <td>{user.transactionid || 'N/A'}</td>
            </tr>
          </tbody>
        </table>
        <h3>Campaign Details</h3>
        <table>
          <thead>
            <tr>
              <th>Campaign Name</th>
              <th>Campaign Type</th>
              <th>Budget</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {user.campaigndetails.length > 0 ? (
              user.campaigndetails.map((campaign, index) => (
                <tr key={index}>
                  <td>{campaign.campaign_title || 'N/A'}</td>
                  <td>{campaign.campaign_type || 'N/A'}</td>
                  <td>{campaign.budget || 'N/A'}</td>
                  <td>{campaign.status || 'N/A'}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No campaign details available</td>
              </tr>
            )}
          </tbody>
        </table>

        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default GeneralUserList;
