import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../../../Utils/axiosInstance'; 
import './GeneralUserList.css';

const GeneralUserList = () => {
  const [users, setUsers] = useState([]); // Initialize as an empty array
  const [loading, setLoading] = useState(true); 
  const [error, setError] = useState(null); 
  const [selectedUser, setSelectedUser] = useState(null); 

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get('/user/gettr');
        // Ensure response data exists
        if (response.data && Array.isArray(response.data.data)) {
          setUsers(response.data.data);
        } else {
          throw new Error('Invalid response structure');
        }
      } catch (err) {
        setError(err.message); 
      } finally {
        setLoading(false); 
      }
    };
    fetchUsers();
  }, []);

  const handleAction = (userId) => {
    const user = users.find((u) => u._id === userId);
    setSelectedUser(user);
  };

  const closeModal = () => {
    setSelectedUser(null); 
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>; 

  return (
    <div>
      <h2>General User List</h2>
      <table>
        <thead>
          <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
            <th>No. of Campaigns</th>
            <th>Total Amount</th>
            <th>Action</th> {/* Add Action Column */}
          </tr>
        </thead>
        <tbody>
          {Array.isArray(users) && users.length > 0 ? (
            users.map((user) => (
              <tr key={user._id}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.mobilenumber}</td>
                <td>{user.campaigndetails ? user.campaigndetails.length : 0}</td>
                <td>{user.amount}</td>
                <td>
                  <button onClick={() => handleAction(user._id)}>View</button> {/* View Button */}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6">No users found</td> {/* Update colspan to 6 */}
            </tr>
          )}
        </tbody>
      </table>
      <UserModal user={selectedUser} onClose={closeModal} />
    </div>
  );
};

const UserModal = ({ user, onClose }) => {
  if (!user) return null; // If there's no user, don't render the modal

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>User Details</h2>
        <table>
          <tbody>
            <tr>
              <td><strong>Name:</strong></td>
              <td>{user.name}</td>
            </tr>
            <tr>
              <td><strong>Email:</strong></td>
              <td>{user.email}</td>
            </tr>
            <tr>
              <td><strong>Mobile Number:</strong></td>
              <td>{user.mobilenumber}</td>
            </tr>
            <tr>
              <td><strong>Total Amount:</strong></td>
              <td>{user.amount}</td>
            </tr>
            <tr>
              <td><strong>No. of Campaigns:</strong></td>
              <td>{user.campaigndetails.length}</td>
            </tr>
            <tr>
              <td><strong>Transaction ID:</strong></td>
              <td>{user.transactionid}</td>
            </tr>
          </tbody>
        </table>
        <h3>Campaign Details</h3>
        <table>
          <thead>
            <tr>
              <th>Campaign Name</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            {user.campaigndetails.length > 0 ? (
              user.campaigndetails.map((campaign, index) => (
                <tr key={index}>
                  <td>{campaign.name || 'N/A'}</td>
                  <td>{JSON.stringify(campaign.details) || 'N/A'}</td> {/* Adjust as necessary */}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="2">No campaign details available</td>
              </tr>
            )}
          </tbody>
        </table>
        <h3>PG Response</h3>
        <table>
          <thead>
            <tr>
              <th>Response</th>
            </tr>
          </thead>
          <tbody>
            {user.pg_response.length > 0 ? (
              user.pg_response.map((response, index) => (
                <tr key={index}>
                  <td>{JSON.stringify(response) || 'N/A'}</td> {/* Adjust as necessary */}
                </tr>
              ))
            ) : (
              <tr>
                <td>No payment gateway responses available</td>
              </tr>
            )}
          </tbody>
        </table>
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default GeneralUserList;
