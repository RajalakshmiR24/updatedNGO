import React, { useContext, useEffect, useState } from 'react';
import { CampaignContext } from '../../../../../Context/CampaignContext';
import axiosInstance from '../../../../../Utils/axiosInstance';
import './Campaigns.css';

const Campaigns = () => {
  const {
    adminCampaigns,
    userCampaigns,
    loading,
    newCampaign,
    handleChange,
    openModal,
    closeModal,
    handleToggleCampaignType,
    activeCampaignType,
    isModalOpen,
    setAdminCampaigns,
    setUserCampaigns,
    setLoading,
  } = useContext(CampaignContext);

  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    const fetchCampaigns = async () => {
      setLoading(true);
      try {
        const endpoint = activeCampaignType === 'user'
          ? '/admin/allusers'
          : '/admin/admincampaigndetails';

        const response = await axiosInstance.get(endpoint);
        const allCampaigns = response.data.data.flatMap(item => item.campaigndetails);

        if (activeCampaignType === 'user') {
          setUserCampaigns(allCampaigns);
          setAdminCampaigns([]);
        } else {
          setAdminCampaigns(allCampaigns);
          setUserCampaigns([]);
        }
      } catch (error) {
        console.error('Error fetching campaign data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCampaigns();
  }, [activeCampaignType, setLoading, setUserCampaigns, setAdminCampaigns]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const emailHash = localStorage.getItem('hash');

    if (!emailHash) {
      alert("Email hash not found in local storage.");
      return;
    }

    const campaignData = {
      hash: emailHash,
      info: newCampaign,
    };

    try {
      await axiosInstance.post('/admin/campaigndata', campaignData);
      if (newCampaign.isAdmin) {
        setAdminCampaigns((prev) => [...prev, campaignData.info]);
      } else {
        setUserCampaigns((prev) => [...prev, campaignData.info]);
      }
    } catch (error) {
      console.error('Error creating campaign:', error);
      alert("Failed to create campaign: " + error.response?.data.message || error.message);
    } finally {
      closeModal();
    }
  };

  const getCampaignStatus = (startDate, endDate) => {
    const now = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);

    if (now < start) return 'Upcoming';
    if (now >= start && now <= end) return 'Live';
    return 'Completed';
  };

  const filteredCampaigns = (campaigns) => {
    if (statusFilter === 'all') return campaigns;
    return campaigns.filter(campaign => getCampaignStatus(campaign.start_date, campaign.end_date).toLowerCase() === statusFilter);
  };

  return (
    <div>
      <h1>Campaigns</h1>
      <button onClick={() => handleToggleCampaignType('admin')}>Admin Campaign</button>
      <button onClick={() => handleToggleCampaignType('user')}>User Campaign</button>

      {activeCampaignType === 'admin' && (
        <>
          <button onClick={openModal}>Create Admin Campaign</button>
          {isModalOpen && (
            <div className="modal">
              <div className="modal-content">
                <h2>Create New Campaign</h2>
                <form onSubmit={handleSubmit}>
                  <input
                    type="text"
                    name="campaign_title"
                    value={newCampaign.campaign_title}
                    onChange={handleChange}
                    placeholder="Campaign Title"
                    required
                  />
                  <textarea
                    name="campaign_description"
                    value={newCampaign.campaign_description}
                    onChange={handleChange}
                    placeholder="Campaign Description"
                    required
                  />
                  <input
                    type="date"
                    name="start_date"
                    value={newCampaign.start_date}
                    onChange={handleChange}
                    required
                  />
                  <input
                    type="date"
                    name="end_date"
                    value={newCampaign.end_date}
                    onChange={handleChange}
                    required
                  />
                  <input
                    type="text"
                    name="campaign_address"
                    value={newCampaign.campaign_address}
                    onChange={handleChange}
                    placeholder="Location"
                    required
                  />
                  <input
                    type="number"
                    name="budget"
                    value={newCampaign.budget}
                    onChange={handleChange}
                    placeholder="Budget"
                    required
                  />
                  <input
                    type="text"
                    name="campaign_type"
                    value={newCampaign.campaign_type}
                    onChange={handleChange}
                    placeholder="Campaign Type"
                    required
                  />
                  
                  <button type="submit">Create Campaign</button>
                  <button type="button" onClick={closeModal}>Cancel</button>
                </form>
              </div>
            </div>
          )}

          <section>
            <h2>Admin Campaign Overview</h2>
            <div>
              <button onClick={() => setStatusFilter('upcoming')}>Upcoming</button>
              <button onClick={() => setStatusFilter('live')}>Live</button>
              <button onClick={() => setStatusFilter('completed')}>Completed</button>
              <button onClick={() => setStatusFilter('all')}>All</button>
            </div>
            {loading ? (
              <p>Loading...</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>Campaign Name</th>
                    <th>Type</th>
                    <th>Budget</th>
                    <th>Location</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns(adminCampaigns).map((campaign) => (
                    <tr key={campaign._id}>
                      <td>{campaign.campaign_title}</td>
                      <td>{campaign.campaign_type}</td>
                      <td>{campaign.budget || 'N/A'}</td>
                      <td>{campaign.campaign_address || 'N/A'}</td>
                      <td>
                        <button>View</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </>
      )}

{activeCampaignType === 'user' && (
  <section>
    <h2>User Campaign Overview</h2>
    <div>
      <button onClick={() => setStatusFilter('upcoming')}>Upcoming</button>
      <button onClick={() => setStatusFilter('live')}>Live</button>
      <button onClick={() => setStatusFilter('completed')}>Completed</button>
      <button onClick={() => setStatusFilter('all')}>All</button>
    </div>
    {loading ? (
      <p>Loading...</p>
    ) : (
      <table>
        <thead>
          <tr>
            <th>User Name</th>
            <th>Email</th>
            <th>Campaign Name</th>
            <th>Type</th>
            <th>Budget</th>
            <th>Location</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {userCampaigns.map((campaign) => (
            <tr key={campaign._id}>
              <td>{user.fullname || 'N/A'}</td>
              <td>{user.email || 'N/A'}</td>
              <td>{campaign.campaign_title}</td>
              <td>{campaign.campaign_type}</td>
              <td>{campaign.budget || 'N/A'}</td>
              <td>{campaign.campaign_address || 'N/A'}</td>
              <td>
                <button>View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    )}
  </section>
)}

    </div>
  );
};

export default Campaigns;
