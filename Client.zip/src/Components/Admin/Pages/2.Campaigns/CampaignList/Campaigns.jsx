import React, { useContext, useEffect, useState } from "react";
import { CampaignContext } from "../../../../../Context/CampaignContext";
import axiosInstance from "../../../../../Utils/axiosInstance";
import "./Campaigns.css";

const Campaigns = () => {
  const {
    adminCampaigns,
    userCampaigns,
    loading,
    setAdminCampaigns,
    setUserCampaigns,
    setLoading,
    handleToggleCampaignType,
    activeCampaignType,
  } = useContext(CampaignContext);

  const [statusFilter, setStatusFilter] = useState("all");
  const [isCampaignFormModalOpen, setCampaignFormModalOpen] = useState(false);
  const [isAdminCampaignDetailModalOpen, setAdminCampaignDetailModalOpen] =
    useState(false);
  const [isUserCampaignDetailModalOpen, setUserCampaignDetailModalOpen] =
    useState(false);
  const [campaign, setCampaign] = useState({
    campaign_title: "",
    campaign_type: "",
    campaign_description: "",
    start_date: "",
    end_date: "",
    campaign_address: "",
    estimated_budget: "",
    collected_amount: "",
    banner: "",
  });
  const [selectedCampaign, setSelectedCampaign] = useState(null);

  const openCampaignFormModal = () => setCampaignFormModalOpen(true);
  const closeCampaignFormModal = () => {
    setCampaignFormModalOpen(false);
    setCampaign({
      campaign_title: "",
      campaign_type: "",
      campaign_description: "",
      start_date: "",
      end_date: "",
      campaign_address: "",
      estimated_budget: "",
      collected_amount: "",
      banner: "",
    });
  };

  const closeCampaignDetailModal = () => {
    setAdminCampaignDetailModalOpen(false);
    setUserCampaignDetailModalOpen(false);
    setSelectedCampaign(null);
  };

  useEffect(() => {
    const fetchCampaigns = async () => {
      setLoading(true);
      try {
        const endpoint =
          activeCampaignType === "user"
            ? "/admin/allusercampaigns"
            : "/admin/alladmincampaigns";

        const response = await axiosInstance.get(endpoint);

        const allCampaigns = response.data.data.map((item) => ({
          campaign_title: item.campaign_title,
          campaign_type: item.campaign_type,
          campaign_description: item.campaign_description,
          start_date: item.campaign_start_date,
          end_date: item.campaign_end_date,
          campaign_address: item.campaign_address,
          estimated_budget: item.estimated_budget,
          banner: campaign.banner || "default_banner.png",
          collected_amount: item.collected_amount || 0,
          reason_for_cancellation: item.reason_for_cancellation,
          _id: item.campaign_id,
          user: item.user,
        }));

        if (activeCampaignType === "user") {
          setUserCampaigns(allCampaigns);
          setAdminCampaigns([]);
        } else {
          setAdminCampaigns(allCampaigns);
          setUserCampaigns([]);
        }
      } catch (error) {
        console.error("Error fetching campaign data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCampaigns();
  }, [activeCampaignType, setLoading, setUserCampaigns, setAdminCampaigns]);

  const getCampaignStatus = (startDate, endDate) => {
    const now = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);

    if (now < start) return "Upcoming";
    if (now >= start && now <= end) return "Live";
    return "Completed";
  };

  const filteredCampaigns = (campaigns) => {
    if (statusFilter === "all") return campaigns;
    return campaigns.filter(
      (campaign) =>
        getCampaignStatus(
          campaign.start_date,
          campaign.end_date
        ).toLowerCase() === statusFilter
    );
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCampaign((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const convertIntoBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);
      fileReader.onload = () => {
        resolve(fileReader.result);
      };
      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const base64 = await convertIntoBase64(file);
      setCampaign((prevState) => ({
        ...prevState,
        banner: base64,
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const emailHash = localStorage.getItem("hash");

    const campaignData = {
      title: campaign.campaign_title,
      type: campaign.campaign_type,
      description: campaign.campaign_description,
      start_date: campaign.start_date,
      end_date: campaign.end_date,
      banner: campaign.banner || "default_banner.png",
      admin_email: emailHash,
      address: campaign.campaign_address,
      budget: campaign.estimated_budget,
    };

    try {
      const response = await axiosInstance.post(
        "/admin/savecampaigndata",
        campaignData
      );

      if (response.data.code === 200) {
        setAdminCampaigns((prev) => [
          ...prev,
          { ...campaign, _id: Date.now() },
        ]);
        closeCampaignFormModal();
        console.log("Campaign created successfully");
      } else {
        console.error("Error:", response.data.message);
      }
    } catch (error) {
      console.error("Error submitting campaign data:", error.message);
    }
  };

  const fetchAdminCampDetails = async (campaignId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/getadmincampaignbyid", {
        campaign_id: campaignId,
      });
      setSelectedCampaign(response.data.data);
      setAdminCampaignDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching campaign details:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserCampDetails = async (campaignId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/getusercampaigns", {
        campaign_id: campaignId,
      });
      setSelectedCampaign(response.data.data[0]);
      setUserCampaignDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching campaign details:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="camp">
      <h1>Campaigns</h1>
      <button onClick={() => handleToggleCampaignType("admin")}>
        Admin Campaign
      </button>
      <button onClick={() => handleToggleCampaignType("user")}>
        User Campaign
      </button>

      {activeCampaignType === "admin" && (
        <>
          {/* Modal for Campaign Form */}
          {isCampaignFormModalOpen && (
            <div className="modal">
              <div className="modal-content">
                <form onSubmit={handleSubmit}>
                  <h2>Create Campaign</h2>

                  <input
                    type="text"
                    name="campaign_title"
                    value={campaign.campaign_title}
                    onChange={handleChange}
                    placeholder="Campaign Title"
                  />
                  <input
                    type="text"
                    name="campaign_type"
                    value={campaign.campaign_type}
                    onChange={handleChange}
                    placeholder="Campaign Type"
                  />
                  <textarea
                    name="campaign_description"
                    value={campaign.campaign_description}
                    onChange={handleChange}
                    placeholder="Description"
                  />
                  <input
                    type="date"
                    name="start_date"
                    value={campaign.start_date}
                    onChange={handleChange}
                  />
                  <input
                    type="date"
                    name="end_date"
                    value={campaign.end_date}
                    onChange={handleChange}
                  />
                  <input
                    type="text"
                    name="campaign_address"
                    value={campaign.campaign_address}
                    onChange={handleChange}
                    placeholder="Address"
                  />
                  <input
                    type="number"
                    name="estimated_budget"
                    value={campaign.estimated_budget}
                    onChange={handleChange}
                    placeholder="Estimated Budget"
                  />
                  <input
                    type="file"
                    name="bannerimage"
                    onChange={handleFileUpload}
                  />
                  <button type="submit">Submit Campaign</button>
                  <button type="button" onClick={closeCampaignFormModal}>
                    Close
                  </button>
                </form>
              </div>
            </div>
          )}

          {isAdminCampaignDetailModalOpen && selectedCampaign && (
            <div className="modal">
              <div className="modal-content">
                <div className="modal-container">
                  <div className="modal-text-content">
                    <h2>Campaign Details</h2>
                    <p>
                      <strong>Title:</strong> {selectedCampaign.campaign_title}
                    </p>
                    <p>
                      <strong>Type:</strong> {selectedCampaign.campaign_type}
                    </p>
                    <p>
                      <strong>Description:</strong>{" "}
                      {selectedCampaign.campaign_description}
                    </p>
                    <p>
                      <strong>Start Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_start_date
                      ).toLocaleDateString()}
                    </p>
                    <p>
                      <strong>End Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_end_date
                      ).toLocaleDateString()}
                    </p>
                    <p>
                      <strong>Address:</strong>{" "}
                      {selectedCampaign.campaign_address}
                    </p>
                    <p>
                      <strong>Budget:</strong>{" "}
                      {selectedCampaign.estimated_budget}
                    </p>
                    <p>
                      <strong>Collected Amount:</strong>{" "}
                      {selectedCampaign.collected_amount}
                    </p>
                    <button onClick={closeCampaignDetailModal}>Close</button>
                  </div>
                  <div className="modal-banner">
                    <img src={selectedCampaign.banner} alt="Campaign Banner" />
                  </div>
                </div>
              </div>
            </div>
          )}

          <section>
            <h2>Admin Campaign Overview</h2>
            <div className="status-buttons">
              <button onClick={() => setStatusFilter("upcoming")}>
                Upcoming
              </button>
              <button onClick={() => setStatusFilter("live")}>Live</button>
              <button onClick={() => setStatusFilter("completed")}>
                Completed
              </button>
              <button onClick={() => setStatusFilter("all")}>All</button>

              <div className="create-campaign-button">
              <button onClick={openCampaignFormModal}>Create Campaign</button>
            </div>
            </div>

            

            {loading ? (
              <p>Loading...</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Campaign Title</th>
                    <th>Campaign Type</th>
                    <th>Estimated Budget</th>
                    <th>Collected Amount</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns(adminCampaigns).map((campaign, index) => (
                    <tr key={campaign._id}>
                      <td>{index + 1}</td>
                      <td>{campaign.campaign_title}</td>
                      <td>{campaign.campaign_type}</td>
                      <td>{campaign.estimated_budget}</td>
                      <td>{campaign.collected_amount}</td>

                      <td>
                        <button
                          onClick={() => fetchAdminCampDetails(campaign._id)}
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </>
      )}

      {activeCampaignType === "user" && (
        <section>
          {/* Campaign Detail Modal */}
          {isUserCampaignDetailModalOpen && selectedCampaign && (
            <div className="modal">
              <div className="modal-content">
                <div className="modal-container">
                  <div className="modal-text-content">
                    <h2>Campaign Details</h2>
                    <p>
                      <strong>Title:</strong> {selectedCampaign.campaign_title}
                    </p>
                    <p>
                      <strong>Type:</strong> {selectedCampaign.campaign_type}
                    </p>
                    <p>
                      <strong>Description:</strong>{" "}
                      {selectedCampaign.campaign_description}
                    </p>
                    <p>
                      <strong>Start Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_start_date
                      ).toLocaleDateString()}
                    </p>
                    <p>
                      <strong>End Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_end_date
                      ).toLocaleDateString()}
                    </p>
                    <p>
                      <strong>Address:</strong>{" "}
                      {selectedCampaign.campaign_address}
                    </p>
                    <p>
                      <strong>Budget:</strong>{" "}
                      {selectedCampaign.estimated_budget}
                    </p>
                    <p>
                      <strong>Collected Amount:</strong>{" "}
                      {selectedCampaign.collected_amount}
                    </p>
                    <p>
                      <strong>Status</strong>{" "}
                      {selectedCampaign.status}
                    </p>
                    <button onClick={closeCampaignDetailModal}>Close</button>
                  </div>
                  <div className="modal-banner">
                    <img src={selectedCampaign.banner} alt="Campaign Banner" />
                  </div>
                </div>
              </div>
            </div>
          )}

          <h2>User Campaign Overview</h2>
          <div className="status-buttons">
              <button onClick={() => setStatusFilter("upcoming")}>
                Upcoming
              </button>
              <button onClick={() => setStatusFilter("live")}>Live</button>
              <button onClick={() => setStatusFilter("completed")}>
                Completed
              </button>
              <button onClick={() => setStatusFilter("all")}>All</button>

              
            </div>

          {loading ? (
            <p>Loading...</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>User Name</th>
                  <th>User Email</th>
                  {/* <th>User Phone Number</th> */}
                  <th>Campaign Title</th>
                  <th>Campaign Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              {filteredCampaigns(userCampaigns).map((campaign, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{campaign.user[0]?.fullname}</td>
                    <td>{campaign.user[0]?.email}</td>
                    {/* <td>{campaign.user[0]?.mobile_number}</td> */}
                    <td>{campaign.campaign_title}</td>
                    <td>{campaign.campaign_type}</td>

                    <td>
                      <button
                        onClick={() => fetchUserCampDetails(campaign._id)}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      )}
    </div>
  );
};

export default Campaigns;
