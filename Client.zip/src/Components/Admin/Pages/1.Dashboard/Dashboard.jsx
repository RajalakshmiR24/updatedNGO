import React from "react";
import "./Dashboard.css";
import LineChart from "./CHARTS/LineChart/LineCharts";
import { PieChart } from "./CHARTS/PieCharts/PieCharts";
import BarChart from "./CHARTS/BARCHART/Barchart";

const CampaignDashboard = () => {
  return (
    <div className="chart-container">
      <h1>Dashboard</h1>
      <div className="chart">
        <div className="linechart">
          <LineChart />
        </div>
     
      </div>
      <div className="chart">
        <div className="piechart">
          <PieChart />
        </div>
        <div className="barchart">
          <BarChart />
        </div>
      </div>
    </div>
  );
};

export default CampaignDashboard;
