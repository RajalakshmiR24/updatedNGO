import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';
import axiosInstance from '../../../../../Utils/axiosInstance';
import { Chart as ChartJS, LineElement, PointElement, LinearScale, CategoryScale, Title, Tooltip, Legend } from 'chart.js';
import dayjs from 'dayjs'; // For formatting dates

ChartJS.register(LineElement, PointElement, LinearScale, CategoryScale, Title, Tooltip, Legend);

const LineChart = () => {
    const [chartData, setChartData] = useState({
        labels: [],
        datasets: [
            {
                label: 'Contributions',
                data: [],
                borderColor: 'blue',
                backgroundColor: 'rgba(173, 216, 230, 0.2)',
                fill: true,
            },
            {
                label: 'Approved Expenses',
                data: [],
                borderColor: 'lightgreen',
                backgroundColor: 'rgba(144, 238, 144, 0.2)',
                fill: true,
            },
            {
                label: 'Pending Expenses',
                data: [],
                borderColor: 'orange',
                backgroundColor: 'rgba(255, 165, 0, 0.2)',
                fill: true,
            }
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Contributions and Expenses Over Time',
            },
        },
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Months'
                }
            },
            y: {
                title: {
                    display: true,
                    text: 'Amount (in currency)'
                }
            }
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const contributionResponse = await axiosInstance.get('/admin/totalcontribution');
                const approvedExpenseResponse = await axiosInstance.get('/admin/totalapprovedexpense');
                const pendingExpenseResponse = await axiosInstance.get('/admin/totalpendingexpense');

                if (
                    contributionResponse.data.code === 200 &&
                    approvedExpenseResponse.data.code === 200 &&
                    pendingExpenseResponse.data.code === 200
                ) {
                    const contributionData = contributionResponse.data.users; // Use users for contributions
                    const approvedExpenseData = approvedExpenseResponse.data.data;
                    const pendingExpenseData = pendingExpenseResponse.data.data;

                    // Create a set of unique labels (Months)
                    const labels = Array.from(new Set([
                        ...contributionData.map(contribution => dayjs(contribution.createdAt).format('MMM')),
                        ...approvedExpenseData.map(expense => dayjs(expense.uploadedAt).format('MMM')),
                        ...pendingExpenseData.map(expense => dayjs(expense.uploadedAt).format('MMM'))
                    ]));

                    // Calculate contributions per Months
                    const contributions = labels.map(label => {
                        const total = contributionData
                            .filter(contribution => dayjs(contribution.createdAt).format('MMM') === label)
                            .reduce((acc, contribution) => acc + parseFloat(contribution.amount), 0);
                        return total;
                    });

                    // Calculate approved expenses per Months
                    const approvedExpenses = labels.map(label => {
                        const total = approvedExpenseData
                            .filter(expense => dayjs(expense.uploadedAt).format('MMM') === label)
                            .reduce((acc, expense) => acc + parseFloat(expense.claiming_amount), 0);
                        return total;
                    });

                    // Calculate pending expenses per Months
                    const pendingExpenses = labels.map(label => {
                        const total = pendingExpenseData
                            .filter(expense => dayjs(expense.uploadedAt).format('MMM') === label)
                            .reduce((acc, expense) => acc + parseFloat(expense.claiming_amount), 0);
                        return total;
                    });

                    // Update the chart data state
                    setChartData({
                        labels: labels,
                        datasets: [
                            {
                                label: 'Contributions',
                                data: contributions,
                                borderColor: 'blue',
                                backgroundColor: 'rgba(173, 216, 230, 0.2)',
                                fill: true,
                            },
                            {
                                label: 'Approved Expenses',
                                data: approvedExpenses,
                                borderColor: 'lightgreen',
                                backgroundColor: 'rgba(144, 238, 144, 0.2)',
                                fill: true,
                            },
                            {
                                label: 'Pending Expenses',
                                data: pendingExpenses,
                                borderColor: 'orange',
                                backgroundColor: 'rgba(255, 165, 0, 0.2)',
                                fill: true,
                            }
                        ],
                    });
                } else {
                    console.error('No data received from one or more APIs');
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div style={{ height: "40vh", width: "800px" }} className='line_chart'>
            <Line data={chartData} options={options} />
        </div>
    );
};

export default LineChart;
