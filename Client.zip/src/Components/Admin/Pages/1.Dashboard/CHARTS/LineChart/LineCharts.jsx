import React, { useEffect, useState } from 'react';
import './LineCharts.css';
import { Line } from 'react-chartjs-2';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import { Chart as ChartJS, LineElement, PointElement, LinearScale, CategoryScale, Title, Tooltip, Legend } from 'chart.js';
import dayjs from 'dayjs'; // For formatting dates

ChartJS.register(LineElement, PointElement, LinearScale, CategoryScale, Title, Tooltip, Legend);

const LineChart = () => {
    const [chartData, setChartData] = useState({
        labels: [], 
        datasets: [
            {
                label: 'Total Contributions',
                data: [], 
                borderColor: 'lightgreen',
                backgroundColor: 'rgba(144, 238, 144, 0.2)',
                fill: true,
            },
            {
                label: 'Transaction Amounts',
                data: [],
                borderColor: 'blue',
                backgroundColor: 'rgba(173, 216, 230, 0.2)',
                fill: true,
            },
            {
                label: 'Fund Requests',
                data: [],
                borderColor: 'red',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                fill: true,
            }
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Total Contributions, Transactions, and Fund Requests Over Time',
            },
        },
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Months'
                }
            },
            y: {
                title: {
                    display: true,
                    text: 'Amount (in currency)'
                }
            }
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                // Fetch total contributions, transactions, and fund requests
                const contributionResponse = await axiosInstance.get('/admin/totaldonation');
                const transactionResponse = await axiosInstance.get('/admin/alltransactions');
                const fundRequestResponse = await axiosInstance.get('/admin/fundrequest');
                
                const contributionsResult = contributionResponse.data;
                const transactionsResult = transactionResponse.data;
                const fundRequestResult = fundRequestResponse.data;

                if (contributionsResult.code === 200 && transactionsResult.code === 200 && fundRequestResult.code === 200) {
                    const totalAmount = contributionsResult.data[0].totalAmount; 
                    const transactionData = transactionsResult.data;
                    const fundRequestData = fundRequestResult.data;

                    // Format dates to display as months (assuming transactions have a `date` field)
                    const labels = transactionData.map(transaction => dayjs(transaction.date).format('MMM')); 
                    
                    // Total contributions (constant over all transactions)
                    const contributions = Array(transactionData.length).fill(totalAmount); 
                    
                    // Transaction amounts
                    const transactions = transactionData.map(transaction => transaction.amount); 

                    // Fund request amounts
                    const fundRequests = fundRequestData.map(request => request.amount); 

                    setChartData({
                        labels: labels, // X-axis: Month labels
                        datasets: [
                            {
                                label: 'Total Contributions',
                                data: contributions, // Y-axis: Total contributions
                                borderColor: 'lightgreen',
                                backgroundColor: 'rgba(144, 238, 144, 0.2)',
                                fill: true,
                            },
                            {
                                label: 'Transaction Amounts',
                                data: transactions, // Y-axis: Transaction amounts
                                borderColor: 'blue',
                                backgroundColor: 'rgba(173, 216, 230, 0.2)',
                                fill: true,
                            },
                            {
                                label: 'Total Funds',
                                data: fundRequests, // Y-axis: Fund request amounts
                                borderColor: 'red',
                                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                                fill: true,
                            }
                        ],
                    });
                } else {
                    console.error('No data received from one or more APIs');
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div style={{ height: "40vh", width: "800px" }} className='line_chart'>
            <Line data={chartData} options={options} />
        </div>
    );
};

export default LineChart;
