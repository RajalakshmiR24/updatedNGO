import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Sidebar.css';
import { FaTachometerAlt, FaFlag, FaUsers, FaEnvelope, FaClipboardList } from 'react-icons/fa';

const Sidebar = () => {
  const [isManagementOpen, setManagementOpen] = useState(false);
  const navigate = useNavigate(); // Use useNavigate hook

  const toggleManagementMenu = () => {
    setManagementOpen(!isManagementOpen);
  };

  const handleLogout = () => {
    // Remove token and hash from localStorage
    localStorage.removeItem('token');
    localStorage.removeItem('hash');

    // Redirect to login or home page
    navigate('/admin/signin'); // Adjust the path as necessary
  };

  return (
    <div className="sidebar">
      <h2>NGO Admin Panel</h2>
      <ul>
        <li><Link to="/admin"><FaTachometerAlt /> Dashboard</Link></li>
        <li><Link to="/admin/campaigns"><FaFlag /> Campaign</Link></li>
        <li>
          <button onClick={toggleManagementMenu} className="submenu-toggle">
            <FaUsers /> User Management
          </button>
          {isManagementOpen && (
            <ul className="submenu">
              <li><Link to="/admin/registered-users">Registered Users</Link></li>
              <li><Link to="/admin/general-users">General Users</Link></li>
            </ul>
          )}
        </li>
        <li><Link to="/admin/requests"><FaClipboardList /> Requests</Link></li>
        <li><Link to="/admin/queries"><FaEnvelope /> Queries</Link></li>
        <li>
          <button onClick={handleLogout} className="logout-button">Logout</button>
        </li>
      </ul>
    </div>
  );
}

export default Sidebar;
