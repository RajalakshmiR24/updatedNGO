import React, { useState } from 'react';
import axiosInstance from '../../../Utils/axiosInstance';
import { useNavigate, Link } from 'react-router-dom';
import Notification from '../../Common/Notification/Notification';
import Form from '../../Common/Form/Form';
import Input from '../../Common/Form/Input';
import { validateForm } from '../../../Utils/Validation';
import './style.css';

const UserSignUp = () => {
    const [info, setInfo] = useState({});
    const [errorMessage, setErrorMessage] = useState('');
    const [showNotification, setShowNotification] = useState(false);
    const [formErrors, setFormErrors] = useState({});
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        setInfo((prevState) => ({
            ...prevState,
            [name]: value,
        }));
        if (files) {
            setInfo((prevState) => ({
                ...prevState,
                idproof: files[0],
            }));
        }
        setErrorMessage('');
        setFormErrors((prev) => ({ ...prev, [name]: undefined }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const errors = validateForm(info);

        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            return;
        }

        const formUserData = new FormData();
        formUserData.append('fullname', info.fullname);
        formUserData.append('email', info.email);
        formUserData.append('mobilenumber', info.mobilenumber);
        formUserData.append('dob', info.dob);
        formUserData.append('idproof', info.idproof);
        formUserData.append('password', info.password);

        axiosInstance.post('/user/register', formUserData)
            .then((res) => {
                if (res.data.code === 200) {
                    setInfo({});
                    setTimeout(() => {
                        navigate("/signin");
                    }, 1000);
                }
            })
            .catch((error) => {
                const { response } = error;
                setErrorMessage(response?.data?.message || 'An error occurred. Please try again.');
                setShowNotification(true);
            });
    };

    const handleCloseNotification = () => {
        setShowNotification(false);
    };

    return (
        <>
            {showNotification && (
                <Notification message={errorMessage} onClose={handleCloseNotification} />
            )}
            <Form onSubmit={handleSubmit} title="Register" linkPath="/admin/signin" linkText="Admin">
                <Input type="text" name="fullname" placeholder="Full Name" value={info.fullname || ""} onChange={handleChange} />
                <Input type="email" name="email" placeholder="Email" value={info.email || ""} onChange={handleChange} />
                {formErrors.email && <p className="error-message">{formErrors.email}</p>}
                <Input type="text" name="mobilenumber" placeholder="Mobile Number" value={info.mobilenumber || ""} onChange={handleChange} />
                {formErrors.mobilenumber && <p className="error-message">{formErrors.mobilenumber}</p>}
                <Input type="file" name="idproof" onChange={handleChange} />
                <Input type="password" name="password" placeholder="Password" value={info.password || ""} onChange={handleChange} />
                {formErrors.password && <p className="error-message">{formErrors.password}</p>}
                <button type="submit">Sign up</button>
                <p>
                    Already have an account? <Link to="/signin">Login here</Link>
                </p>
            </Form>
        </>
    );
};

export default UserSignUp;
