import React from 'react';
import { Link } from 'react-router-dom';

const Form = ({ onSubmit, children, title, linkPath, linkText }) => {
    return (
        <div className="form-container">
            <form onSubmit={onSubmit} className="login-form">
                <h2>{title}</h2>
                <Link to={linkPath}><i>{linkText}</i></Link>
                {children}
            </form>
        </div>
    );
};

export default Form;
