import React, { useState } from 'react';
import axiosInstance from '../../../Utils/axiosInstance';
import { useNavigate, Link } from 'react-router-dom';
import Form from '../../Common/Form/Form';
import Input from '../../Common/Form/Input';
import { validateForm } from '../../../Utils/Validation';
import './Style.css';

const UserSignIn = () => {
    const [info, setInfo] = useState({ email: '', password: '' });
    const [errorMessage, setErrorMessage] = useState('');
    const [formErrors, setFormErrors] = useState({});
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setInfo((prevState) => ({
            ...prevState,
            [name]: value,
        }));
        setErrorMessage('');
        setFormErrors((prev) => ({ ...prev, [name]: undefined }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const errors = validateForm(info);

        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            return;
        }

        axiosInstance.post('/user/login', info)
            .then((res) => {
                if (res.data.code === 200) {
                    setInfo({ email: '', password: '' });
                    localStorage.setItem("token", res.data.accessToken);
                    navigate("/register-user");
                }
            })
            .catch((error) => {
                const { response } = error;
                setErrorMessage(response?.data?.message || 'An error occurred. Please try again.');
            });
    };

    return (
        <Form onSubmit={handleSubmit} title="Login" >
            <Input type="text" name="email" placeholder="Email" value={info.email} onChange={handleChange} />
            {formErrors.email && <p className="error-message">{formErrors.email}</p>}
            <Input type="password" name="password" placeholder="Password" value={info.password} onChange={handleChange} />
            {formErrors.password && <p className="error-message">{formErrors.password}</p>}
            <button type="submit">Login</button>
            {errorMessage && <p className="error-message">{errorMessage}</p>}
            <p>
                Don't have an account? <Link to="/signup">Create an account</Link>
            </p>
        </Form>
    );
};

export default UserSignIn;
