import React from 'react';
import { Line } from 'react-chartjs-2';

import { Chart as ChartJS, CategoryScale, PointElement, LineElement, Title, Tooltip, Legend, LinearScale } from 'chart.js';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend
);
const data = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    datasets: [
        {
            label: 'Total Income',
            data: [76, 9, 85, 9, 88, 110, 12, 130, 140, 150, 160, 1], // Fill in all months
            fill: true,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 3,
            tension: 0, // Adjust tension for curve
        },
    ],
};

const options = {
    responsive: true,
    plugins: {
        legend: {
            display: true,
            position: 'top',
        },
        tooltip: {
            mode: 'index',
            intersect: false,
        },
    },
    scales: {
        x: {
            grid: {
                color: 'rgba(0, 0, 0, 0.3)', // X-axis grid line color
                lineWidth: 3, // X-axis grid line width
            },
        },
        y: {
            grid: {
                color: 'rgba(0, 0, 0, 0.3)', // Y-axis grid line color
                lineWidth: 2, // Y-axis grid line width
            },
        },
    },
    animation: {
        // Animation options
        tension: {
            duration: 2000, // Animation duration for tension
            easing: 'linear', // Easing function
        },
        borderColor: {
            duration: 1000, // Animation duration for border color
            easing: 'linear', // Easing function
        },
        scale: {
            y: {
                duration: 1000, // Animation duration for scale
                easing: 'linear', // Easing function
            },
        },
    },
};

export const LineChart = () => {
    return (
        <div className='linechart'>
            <div style={{ height: "40vh", width: "800px" }}>
                <h2>Total Income</h2>
                <Line data={data} options={options} />
            </div>
        </div>
    );
}
