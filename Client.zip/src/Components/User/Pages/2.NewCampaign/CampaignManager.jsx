import React from 'react';
import { useNavigate } from 'react-router-dom';
import UserDetailsForm from './UserDetailsForm';

const CampaignManager = () => {
    const navigate = useNavigate();

    const handleUserDetailsSubmit = () => {
        // Navigate to the campaign form route after successful submission
        navigate('/register-user/new-campaign/campaign');
    }

    return (
        <div>
            <UserDetailsForm onSubmitSuccess={handleUserDetailsSubmit} />
        </div>
    );
}

export default CampaignManager;
