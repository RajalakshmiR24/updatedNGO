const { Admin } = require("../Model/admin.js");
const { BillModel } = require("../Model/bills.js");
const { Campaign } = require("../Model/campaign");
const { User } = require("../Model/user");

//admin
const saveAdminCampaignDetails = async (req, res) => {
    const { title, type, description, start_date, end_date, banner, admin_email, address, budget } = req.body;

    try {
        const campaign = await Campaign.create({
            campaign_title: title,
            campaign_address: address,
            estimated_budget: budget,
            banner: banner,
            campaign_type: type,
            campaign_description: description,
            campaign_start_date: start_date,
            campaign_end_date: end_date,
            admin_email: admin_email,
            status: "APPROVED"
        });
        const admin = await Admin.findOne({ email_hash: admin_email });
        if (!admin) {
            return res.status(200).json({ code: 404, message: "Admin not found" });
        }
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Campaign not saved" })
        }
        admin.campaigns.push(campaign._id);
        await admin.save();

        return res.status(200).json({ code: 200, message: "Admin Campaign data created successfully" });

    } catch (error) {

        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
};
const getAdminsByCampaignId = async (req, res) => {
    try {
        const { campId } = req.body;
        if (!campId) {
            return res.status(200).json({ code: 400, message: "campId is missing" })
        }
        const campaigns = await Campaign.findOne({ campaign_id: campId })
            .populate('Admin')
            .exec();

        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}
const getAdminCampaignDetailsById = async (req, res) => {
    try {
        const { email } = req.body;
        const adminCampaigns = await Admin.findOne({ admin_email: email });
        if (!adminCampaigns) {
            return res.status(200).json({ code: 400, message: "No admin campaigns found" })
        }
        return res.status(200).json({ code: 200, data: adminCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}
const getAllAdminCampaignDetails = async (req, res) => {
    try {
        const adminCampaigns = await Campaign.find({ admin_email: { $exists: true } }, { _id: 0, admin_email: 0 });
        if (!adminCampaigns) {
            return res.status(200).json({ code: 400, message: "No admin campaigns found" })
        }
        return res.status(200).json({ code: 200, count: adminCampaigns.length, data: adminCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}
const updateAdminCampaignDetails = async (req, res) => {
    try {
        const { title, type, description, start_date, end_date, banner, admin_email, address, budget } = req.body;

        const checkCampaign = await Campaign.findOne({ admin_email: admin_email });
        if (!checkCampaign) {
            return res.status(200).json({ code: 400, message: "No campaign found to update" })
        }
        const campaign = await Campaign.findOneAndUpdate(
            { admin_email: admin_email },
            {
                $set: {
                    campaign_title: title,
                    campaign_address: address,
                    banner: banner,
                    estimated_budget: budget,
                    campaign_type: type,
                    campaign_description: description,
                    campaign_start_date: start_date,
                    campaign_end_date: end_date,
                    status: "APPROVED"
                }
            },
            { new: true }
        );
        const admin = await Admin.findOne({ email_hash: admin_email });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Update unsuccessfull" })
        }
        return res.status(200).json({ code: 200, message: "Admin Campaign data updated successfully" });
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const deleteAdminCampaignDetails = async (req, res) => {
    try {
        const { email, campId } = req.body;
        const campaign = await Campaign.findOne({ campaign_id: campId });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "No campaign found" })
        }
        const deleteCampaign = await Campaign.deleteOne({ campaign_id: campId });
        if (deleteCampaign.deletedCount === 0) {
            return res.status(200).json({ code: 400, message: "Deletion unsuccessfull" })
        }
        const bill = await BillModel.deleteMany({ campaign_id: campId });
        if (bill.deletedCount === 0) {
            return res.status(200).json({ code: 400, message: "Bill deletion unsuccessfull for campaign" })
        }
        return res.status(200).json({ code: 200, message: "Campaign deleted successfully", data: campaign })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}


//user
const saveUserCampaignDetails = async (req, res) => {
    const { title, type, description, start_date, end_date, banner, user_email, address, budget } = req.body;
    try {
        const campaign = await Campaign.create({
            campaign_title: title,
            campaign_address: address,
            estimated_budget: budget,
            banner: banner,
            campaign_type: type,
            campaign_description: description,
            campaign_start_date: start_date,
            campaign_end_date: end_date,
            user_email: user_email,
        });

        // Find the user
        const user = await User.findOne({ email_hash: user_email });
        if (!user) {
            return res.status(404).json({ code: 404, message: "User not found" });
        }
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Campaign not saved" })
        }
        user.campaigns.push(campaign._id);
        await user.save();

        return res.status(200).json({ code: 200, message: "Campaign data created successfully" });

    } catch (error) {
        console.error("Error saving campaign:", error); // Log the error for debugging
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};


const findUsersByCampaignId = async (req, res) => {
    try {
        const { campId } = req.body;
        if (!campId) {
            return res.status(200).json({ code: 400, message: "campId is missing" })
        }
        const campaigns = await Campaign.findOne({ campaign_id: campId })
            .populate('User')
            .exec();

        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getAllUserCampaignDetails = async (req, res) => {
    try {
        const userCampaigns = await Campaign.find({ user_email: { $exists: true } }, { _id: 0, user_email: 0 });
        if (!userCampaigns) {
            return res.status(200).json({ code: 400, message: "No admin campaigns found" })
        }
        return res.status(200).json({ code: 200, count: userCampaigns.length, data: userCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}


const getAllCampaignDetails = async (req, res) => {
    try {
        const campaignDetails = await Campaign.find({});
        if (!campaignDetails) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaignDetails })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getUserCampaignDetailsById = async (req, res) => {
    const { email } = req.body;
    try {
        const campaignData = await Campaign.find({ user_email: email });
        if (!campaignData) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, count: campaignData.length, data: campaignData })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const gettotalCampaignCount = async (req, res) => {
    try {
        const count = await Campaign.countDocuments();
        if (count === 0) {
            return res.status(200).json({ code: 400, message: "No campaign found" })
        }
        return res.status(200).json({ code: 200, data: count })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}


//count live upcoming rejected cancelled 
const campaignCountPerUserByEmail = async (req, res) => {
    const { email } = req.body;
    try {
        const campaignCountPerUser = (await Campaign.find({ user_email: email })).length;
        if (campaignCountPerUser === 0) {
            return res.status(200).json({ code: 200, data: "NA" })
        }
        return res.status(200).json({ code: 200, data: campaignCountPerUser })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }


}

const getAllUpcomingCampaigns = async (req, res) => {
    try {
        const campaigns = await User.find(
            {
                "campaigndetails.status": "UPCOMING"
            },
            {
                campaigndetails: 1,
                _id: 0
            }
        )
        console.log(campaigns);


        // const images = await ImageModel.findOne({ campaign_id: campaigns.campaign_id })
        // const data = { campaigns, images }
        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}


module.exports = {
    getUserCampaignDetailsById,
    getAllUpcomingCampaigns,
    getAllCampaignDetails,
    saveAdminCampaignDetails,
    saveUserCampaignDetails,
    findUsersByCampaignId,
    getAdminsByCampaignId,
    getAllAdminCampaignDetails,
    getAdminCampaignDetailsById,
    getAllUserCampaignDetails,
    gettotalCampaignCount,
    campaignCountPerUserByEmail,
    updateAdminCampaignDetails,
    updateAdminCampaignDetails,
    deleteAdminCampaignDetails
}
