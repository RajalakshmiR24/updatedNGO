const { default: axios } = require("axios");
const { Transaction } = require("../Model/transaction");
const { User } = require("../Model/user");

const saveGeneralTransaction = async (req, res) => {
    try {
        const { name, email, amount, mobilenumber } = req.body;
        const transaction = await Transaction.create({
            name: name,
            email: email,
            amount: amount,
            mobilenumber: mobilenumber,
        });
        if (!transaction) {
            return res.status(200).json({ code: 400, message: "Transaction not saved" })
        }
        return res.status(200).json({ code: 200, message: "Transaction saved successfully" });

    } catch (error) {
        console.error("Error saving transaction:", error);
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};

const saveCampaignTransactionData = async (req, res) => {
    try {
        const { name, email, amount, mobilenumber, campId } = req.body;
        const transaction = await Transaction.create({
            name: name,
            email: email,
            amount: amount,
            mobilenumber: mobilenumber,
            campaign_id: campId,
        });
        if (!transaction) {
            return res.status(200).json({ code: 400, message: "Transaction not saved" })
        }
        return res.status(200).json({ code: 200, message: "Transaction saved successfully" });

    } catch (error) {
        console.error("Error saving transaction:", error);
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};



const getTotalContributionInAmount = async (req, res) => {

    try {
        const total = await Transaction.aggregate([
            {
                $group: {
                    _id: null,
                    totalAmount: { $sum: { $toDouble: "$amount" } }
                }
            }
        ]);
        if (!total) {
            return res.status(200).json({ code: 400, message: "No transactions found" })
        }
        return res.status(200).json({ code: 200, data: total })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }


}
const getTransactionDocumentCount = async (req, res) => {
    const totalTransactionDocuments = await Transaction.countDocuments();
    if (totalTransactionDocuments === 0) {

        return res.status(200).json({ code: 400, message: "No transactions found" })
    }
    return res.status(200).json({ code: 200, data: totalTransactionDocuments });
}
const getTotalGeneralUsersCount = async (req, res) => {
    try {
        const total = await Transaction.countDocuments();
        return res.status(200).json({ code: 200, data: total })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}
const getAllTransactionDetails = async (req, res) => {
    const totalTransactionDocuments = await Transaction.countDocuments();
    if (totalTransactionDocuments === 0) {
        return res.status(200).json({ code: 400, message: "No transactions found" })
    }
    const transactionDocuments = await Transaction.find({}, { _id: 0 });
    return res.status(200).json({ code: 200, data: transactionDocuments });
}

const getTransactionUsingHash = async (req, res) => {

    // console.log(req.body);
    try {
        const { hash } = req.body;
        if (!hash) {
            return res.status(200).json({ code: 400, message: "email is required" });
        }
        const transaction = await Transaction.findOne({ hash: hash });
        if (!transaction) {
            return res.status(200).json({ code: 400, message: "No transactions found" })
        }
        return res.status(200).json({ code: 200, data: transaction })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })


    }
}


const getTransactionByCampaignId = async (req, res) => {
    try {
        const { campId } = req.body;
        const transaction = await Transaction.findOne({ campaign_id: campId });
        if (!transaction) {
            return res.status(200).json({ code: 400, message: "No transactions found" })
        }
        return res.status(200).json({ code: 200, data: transaction })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}


const getTransactionResponse = async (req, res) => {
    // const { merchantName, platform, billerName, category, merchantNumber, last4Digits, mobileNumber } = req.body;

    console.log('Payment Request Received:', req.body);
    const customerParams = { "Last 4 digits of Credit Card Number": req.body.creditcardnumber, "Registered Mobile Number": req.body.registeredmobilenumber }

    const obj = {
        "MerchantName": req.body.name,
        "Platform": req.body.platform,
        "amount": req.body.amount,
        "billerName": process.env.biller_name,
        "category": process.env.category,
        "MerchantNumber": req.body.mobilenumber,
        customerParams
    }
    console.log(obj, "Line 79");

    await axios.post(`http://192.168.1.28:6012/api/pg/billfetch`, obj)
        .then((response) => {
            console.log(response, 'LIne kjsdfksflksdflksjflksajflksjflksjflksjfsalkjfsalkjfsalkj')
            console.log(response.data.code, "line 8555555555555555555555555");
            console.log(response.data, "Liuerfijsdfjsdlfjdlskjfksdjfsjfslkfjslk");
            if (response.data.code === 200) {
                return res.status(200).json({ code: 200, value: response.data.value })
            } else {
                return res.status(200).json({ code: 400, msg: "Try Again" })
            }
        })
}


const getTransResponse = async (req, res) => {
    try {
        console.log(req.body);
        const transaction = await Transaction.create(req.body);
        transaction.save();
        if (transaction)
            return res.status(301).redirect("http://192.168.1.34:4173/")
        // return res.status(200).json({ code: 200 })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getTranseData = async (req, res) => {
    try {
        const { id } = req.body
        if (!id) {
            return res.status(200).json({ code: 400, message: "no id found" })
        }
        const transData = await Transaction.findOne({
            transactionid: id
        })
        return res.status(200).json({ code: 200, data: transData });

    } catch (err) {
        return res.status(200).json({ code: 500, errorMessage: err.message })

    }
}


module.exports = {
    getTransactionUsingHash, saveCampaignTransactionData,
    saveGeneralTransaction, getTotalGeneralUsersCount, getTotalContributionInAmount,
    getTransactionByCampaignId, getTransResponse, getTransactionResponse,
    getAllTransactionDetails
};