const express = require("express");
const { userLogin, userData, registerUser, getUsersCount, insertCampaignDataByEmailHash, userLogout, getCampaignCountByMonth, getCampaignCountByYear, getLiveCampaings, getCancelledCampaings, getUpcomingCampaings, getApprovedCampaings, getNotApprovedCampaings, getLiveWithDetails, getCompleteCampaignWithDetails, getLiveCampaignWithDetails, getAllCampaignDetails, getCampaignDetailsPerUserByEmailHash, getUserCampaignImages, totalCampaignCount, getCampaignCountPerDay, getCampaignCountByweek, getTotalTransactionAmount, getTotalExpense, getCompletedCampaings, updateUser } = require("../Controller/usercontroller");
const { verifyJWT } = require("../Middlewares/auth");
const { saveTransaction, getAllTransactionDetails, payForCampaign, getTransactionUsingHash } = require("../Controller/transactioncontroller");
const { insertBillDetailsIntoCampaign, uploadImage, fetchImage } = require("../Controller/admincontroller");
const { FundRequest, fundRequest } = require("../Controller/fundcontroller");
const { saveUserCampaignDetails, fetchCampaignsWithUsers, findUsersByCampaignId, getCampaignDetailsByEmailhash } = require("../Controller/campaigncontroller.js");
const userRouter = express.Router();


//user control
userRouter.post("/register", registerUser);
userRouter.post("/login", userLogin)
userRouter.post("/logout", userLogout);
userRouter.put("/update", updateUser);

userRouter.get("/total", totalCampaignCount)

userRouter.get("/count", getUsersCount);
userRouter.get("/monthcount", getCampaignCountByMonth)
userRouter.get("/daycount", getCampaignCountPerDay)
userRouter.get("/weekcount", getCampaignCountByweek)
userRouter.get("/complete", getCompletedCampaings)
userRouter.get("/contribution", getTotalTransactionAmount)
userRouter.get("/expense", getTotalExpense)
userRouter.get("/yearcount", getCampaignCountByYear)
userRouter.get("/live", getLiveCampaings)
userRouter.get("/cancel", getCancelledCampaings)
userRouter.get("/upcoming", getUpcomingCampaings)
userRouter.get("/approve", getApprovedCampaings)
userRouter.get("/notapprove", getNotApprovedCampaings)
userRouter.get("/livedetails", getLiveCampaignWithDetails)
userRouter.get("/completecampaigndetails", getCompleteCampaignWithDetails)


//campaign
userRouter.post("/savecampaigndata", saveUserCampaignDetails);
userRouter.post("/usercampaigndata", findUsersByCampaignId)
// userRouter.post("/campaigndataperuser", getCampaignDetailsByEmailhash);

userRouter.post("/getbannerpercampaign", getUserCampaignImages);


//campaign
userRouter.post('/campaigndata', insertCampaignDataByEmailHash);
userRouter.post("/funds", fundRequest);


//transaction
// userRouter.post("/savetr", saveTransaction);
userRouter.get("/gettr", getAllTransactionDetails);
userRouter.post("/gettransbyha", getTransactionUsingHash);




userRouter.post("/savebills", insertBillDetailsIntoCampaign);


userRouter.post("/image", uploadImage);
userRouter.post("/fetchimage", fetchImage);


module.exports = userRouter;